/* ============================================================================
 * Sweep — vision.js
 * ----------------------------------------------------------------------------
 * The detector. No libraries, no model files, no network: everything here is
 * arithmetic over pixels.
 *
 * The pipeline, in order:
 *
 *   1. DOWNSCALE   analyse a small copy of the frame. This single number is
 *                  the main speed/accuracy dial.
 *   2. QUANTISE    every pixel gets one of 21 named colours via a precomputed
 *                  lookup table. Building that table is the "loading" step —
 *                  bigger table, slower start, more accurate and *faster*
 *                  afterwards, because per-pixel work becomes one array read.
 *   3. SEGMENT     4-connected flood fill over colour families → raw regions.
 *   4. MERGE       (a) touching regions that look the same colour join up
 *                  (b) small regions sitting inside a bigger one join it —
 *                  this is what stops a phone screen being reported as a
 *                  separate object from the phone.
 *   5. PREFILTER   if the user asked for "purple", regions that are not purple
 *                  are dropped here, *before* the expensive stages. This is the
 *                  "narrow it down first, then classify" behaviour.
 *   6. SHAPE       per region: image moments give the object's own axis, then
 *                  an oriented 4×4 occupancy grid gives fill, corners and
 *                  holes. That is how a pen lying at 22° is still "long & thin"
 *                  rather than a big empty box.
 *   7. NAME        sample rooms carry an answer key, so a region that overlaps
 *                  a known object takes its name ("labelled"). Anything else —
 *                  including everything from a live camera — is named by
 *                  nearest match in the object catalogue ("best guess").
 *
 * Coordinates: `boxA` is in analysis pixels, `box` is in world pixels. The UI
 * only ever deals in world pixels.
 * ==========================================================================*/
(function (global) {
  'use strict';

  var NS = global.Sweep || (global.Sweep = {});
  var R = NS.Raster || (typeof require === 'function' ? require('./raster.js') : null);
  var D = NS.Data || (typeof require === 'function' ? require('./data.js') : null);

  var now = (typeof performance !== 'undefined' && performance.now)
    ? function () { return performance.now(); }
    : function () { return Date.now(); };

  /* ==========================================================================
   * ENGINE PROFILES
   * The user-facing "which detector do you want" choice.
   * ========================================================================*/
  var ENGINES = {
    fast: {
      id: 'fast', name: 'Quick look', bits: 4, width: 200,
      minAreaFactor: 0.0009, mergeContained: false, refine: false, interval: 320,
      blurb: 'Starts instantly. Misses small things.'
    },
    balanced: {
      id: 'balanced', name: 'Balanced', bits: 5, width: 300,
      minAreaFactor: 0.0007, mergeContained: true, refine: false, interval: 260,
      blurb: 'Good on most rooms. Loads in about a second.'
    },
    precision: {
      id: 'precision', name: 'Precision', bits: 6, width: 430,
      minAreaFactor: 0.0005, mergeContained: true, refine: true, interval: 420,
      blurb: 'Slowest to load, sharpest boxes, catches small clutter.'
    }
  };

  /* ==========================================================================
   * COLOUR SCIENCE
   * sRGB → CIE Lab so "which colour is this closest to" matches what a person
   * would say, instead of what raw RGB distance says.
   * ========================================================================*/

  function srgbToLab(r, g, b) {
    var rr = r / 255, gg = g / 255, bb = b / 255;
    rr = rr > 0.04045 ? Math.pow((rr + 0.055) / 1.055, 2.4) : rr / 12.92;
    gg = gg > 0.04045 ? Math.pow((gg + 0.055) / 1.055, 2.4) : gg / 12.92;
    bb = bb > 0.04045 ? Math.pow((bb + 0.055) / 1.055, 2.4) : bb / 12.92;
    var x = (rr * 0.4124 + gg * 0.3576 + bb * 0.1805) / 0.95047;
    var y = (rr * 0.2126 + gg * 0.7152 + bb * 0.0722);
    var z = (rr * 0.0193 + gg * 0.1192 + bb * 0.9505) / 1.08883;
    var f = function (t) { return t > 0.008856 ? Math.pow(t, 1 / 3) : (7.787 * t + 16 / 116); };
    var fx = f(x), fy = f(y), fz = f(z);
    return [116 * fy - 16, 500 * (fx - fy), 200 * (fy - fz)];
  }

  function deltaE(a, b) {
    var dl = a[0] - b[0], da = a[1] - b[1], db = a[2] - b[2];
    return Math.sqrt(dl * dl + da * da + db * db);
  }

  /* Precomputed reference data for the 21 named colours. */
  var PAL = D.COLORS.map(function (c) {
    var rgb = R.hexToRgb(c.hex);
    return { name: c.name, group: c.group, hex: c.hex, rgb: rgb, lab: srgbToLab(rgb.r, rgb.g, rgb.b) };
  });
  var GROUP_IDS = D.COLOR_GROUPS.map(function (g) { return g.id; });
  var PAL_GROUP_INDEX = PAL.map(function (p) { return GROUP_IDS.indexOf(p.group); });

  /* Colours a person would call "no colour, just light or dark". Handled on a
   * lightness ladder instead of by hue, which is how naming actually works. */
  var NEUTRAL_LADDER = [
    { name: 'black',    maxL: 17 },
    { name: 'charcoal', maxL: 34 },
    { name: 'gray',     maxL: 70 },
    { name: 'silver',   maxL: 87 },
    { name: 'white',    maxL: 101 }
  ];
  var PAL_INDEX_BY_NAME = {};
  PAL.forEach(function (p, i) { PAL_INDEX_BY_NAME[p.name] = i; });

  /** Name one colour. Returns an index into PAL. */
  function classifyRGB(r, g, b) {
    var lab = srgbToLab(r, g, b);
    var chroma = Math.sqrt(lab[1] * lab[1] + lab[2] * lab[2]);
    if (chroma < 13) {
      for (var n = 0; n < NEUTRAL_LADDER.length; n++) {
        if (lab[0] <= NEUTRAL_LADDER[n].maxL) return PAL_INDEX_BY_NAME[NEUTRAL_LADDER[n].name];
      }
      return PAL_INDEX_BY_NAME.white;
    }
    var best = 0, bestD = Infinity;
    for (var i = 0; i < PAL.length; i++) {
      if (PAL[i].group === 'black' || PAL[i].group === 'gray' || PAL[i].group === 'white') continue;
      var d = deltaE(lab, PAL[i].lab);
      if (d < bestD) { bestD = d; best = i; }
    }
    return best;
  }

  /* ==========================================================================
   * LOOKUP TABLE ("loading the detector")
   * One entry per quantised RGB cell. Built in slices so the UI can show
   * progress instead of freezing.
   * ========================================================================*/

  function lutBuilder(bits) {
    var size = 1 << bits;
    var total = size * size * size;
    var lut = new Uint8Array(total);
    var step = 256 / size, half = step / 2;
    var i = 0;
    return {
      bits: bits, total: total, lut: lut,
      get progress() { return i / total; },
      /** Fill up to `count` more entries. Returns true when finished. */
      run: function (count) {
        var end = Math.min(total, i + count);
        for (; i < end; i++) {
          var ri = (i >> (2 * bits)) & (size - 1);
          var gi = (i >> bits) & (size - 1);
          var bi = i & (size - 1);
          lut[i] = classifyRGB(ri * step + half, gi * step + half, bi * step + half);
        }
        return i >= total;
      }
    };
  }

  /** Build a whole engine synchronously (tests, and the "fast" profile). */
  function buildEngine(profileId) {
    var p = ENGINES[profileId] || ENGINES.balanced;
    var b = lutBuilder(p.bits);
    b.run(b.total);
    return makeEngine(p, b.lut);
  }

  function makeEngine(profile, lut) {
    var bits = profile.bits, shift = 8 - bits;
    var groupLut = new Uint8Array(lut.length);
    for (var i = 0; i < lut.length; i++) groupLut[i] = PAL_GROUP_INDEX[lut[i]];
    return {
      profile: profile,
      lut: lut,
      groupLut: groupLut,
      lutBytes: lut.length,
      index: function (r, g, b) {
        return ((r >> shift) << (2 * bits)) | ((g >> shift) << bits) | (b >> shift);
      }
    };
  }

  /* ==========================================================================
   * SEGMENTATION
   * ========================================================================*/

  /** Union-find, used to apply the two merge rules without rebuilding maps. */
  function makeDSU(n) {
    var parent = new Int32Array(n);
    for (var i = 0; i < n; i++) parent[i] = i;
    function find(x) { while (parent[x] !== x) { parent[x] = parent[parent[x]]; x = parent[x]; } return x; }
    return {
      find: find,
      union: function (a, b) { a = find(a); b = find(b); if (a !== b) parent[b] = a; return a; }
    };
  }

  /**
   * Flood-fill regions of one colour family.
   * Returns { labels, regions } where labels is an Int32Array (-1 = unassigned).
   */
  function segment(img, engine) {
    var W = img.width, H = img.height, data = img.data;
    var n = W * H;
    var groups = new Uint8Array(n);
    var palIdx = new Uint8Array(n);
    var i, p;

    for (i = 0, p = 0; i < n; i++, p += 4) {
      var idx = engine.index(data[p], data[p + 1], data[p + 2]);
      palIdx[i] = engine.lut[idx];
      groups[i] = engine.groupLut[idx];
    }

    var labels = new Int32Array(n).fill(-1);
    var stack = new Int32Array(n);
    var regions = [];

    for (i = 0; i < n; i++) {
      if (labels[i] !== -1) continue;
      var id = regions.length;
      var gid = groups[i];
      var sp = 0;
      stack[sp++] = i;
      labels[i] = id;
      var area = 0, minX = W, minY = H, maxX = -1, maxY = -1;
      var sr = 0, sg = 0, sb = 0;

      while (sp > 0) {
        var q = stack[--sp];
        var x = q % W, y = (q / W) | 0;
        area++;
        if (x < minX) minX = x; if (x > maxX) maxX = x;
        if (y < minY) minY = y; if (y > maxY) maxY = y;
        var pp = q * 4;
        sr += data[pp]; sg += data[pp + 1]; sb += data[pp + 2];

        if (x > 0     && labels[q - 1] === -1 && groups[q - 1] === gid) { labels[q - 1] = id; stack[sp++] = q - 1; }
        if (x < W - 1 && labels[q + 1] === -1 && groups[q + 1] === gid) { labels[q + 1] = id; stack[sp++] = q + 1; }
        if (y > 0     && labels[q - W] === -1 && groups[q - W] === gid) { labels[q - W] = id; stack[sp++] = q - W; }
        if (y < H - 1 && labels[q + W] === -1 && groups[q + W] === gid) { labels[q + W] = id; stack[sp++] = q + W; }
      }

      regions.push({
        id: id, group: gid, area: area,
        x: minX, y: minY, w: maxX - minX + 1, h: maxY - minY + 1,
        r: sr / area, g: sg / area, b: sb / area,
        alive: true
      });
    }
    return { labels: labels, regions: regions, palIdx: palIdx, W: W, H: H };
  }

  /**
   * Mark the surface everything is lying on. Background is never merged with
   * anything: a desk's bounding box contains every object on it, so letting it
   * take part in merging would quietly eat the whole room.
   */
  function flagBackground(seg) {
    var total = seg.W * seg.H;
    seg.regions.forEach(function (r) {
      r.bg = (r.area > total * 0.16) ||
             (r.w >= seg.W * 0.92 && r.h >= seg.H * 0.5) ||
             (r.x <= 0 && r.x + r.w >= seg.W - 1 && r.area > total * 0.05);
    });
    return seg;
  }

  /** Rule (a): touching regions whose average colours are near-identical. */
  function mergeTouching(seg, tolerance) {
    var W = seg.W, H = seg.H, labels = seg.labels, regs = seg.regions;
    var dsu = makeDSU(regs.length);
    var seen = new Set();
    var labs = regs.map(function (r) { return srgbToLab(r.r, r.g, r.b); });

    for (var y = 0; y < H; y++) {
      for (var x = 0; x < W; x++) {
        var i = y * W + x, a = labels[i];
        if (x < W - 1) checkPair(a, labels[i + 1]);
        if (y < H - 1) checkPair(a, labels[i + W]);
      }
    }
    function checkPair(a, b) {
      if (a === b) return;
      if (regs[a].bg || regs[b].bg) return;
      var key = a < b ? a * regs.length + b : b * regs.length + a;
      if (seen.has(key)) return;
      seen.add(key);
      if (deltaE(labs[a], labs[b]) < tolerance) dsu.union(a, b);
    }
    return applyMerge(seg, dsu);
  }

  /** Rewrite labels and rebuild region stats after a union-find pass. */
  function applyMerge(seg, dsu) {
    var regs = seg.regions, labels = seg.labels;
    var remap = new Int32Array(regs.length).fill(-1);
    var out = [];
    var i;
    for (i = 0; i < regs.length; i++) {
      var root = dsu.find(i);
      if (remap[root] === -1) {
        remap[root] = out.length;
        var r = regs[root];
        out.push({
          id: out.length, group: r.group, area: 0,
          x: Infinity, y: Infinity, x2: -1, y2: -1,
          sr: 0, sg: 0, sb: 0, alive: true
        });
      }
      remap[i] = remap[root];
    }
    for (i = 0; i < regs.length; i++) {
      var src = regs[i], dst = out[remap[i]];
      dst.area += src.area;
      dst.x = Math.min(dst.x, src.x); dst.y = Math.min(dst.y, src.y);
      dst.x2 = Math.max(dst.x2, src.x + src.w - 1); dst.y2 = Math.max(dst.y2, src.y + src.h - 1);
      dst.sr += src.r * src.area; dst.sg += src.g * src.area; dst.sb += src.b * src.area;
    }
    out.forEach(function (d) {
      d.w = d.x2 - d.x + 1; d.h = d.y2 - d.y + 1;
      d.r = d.sr / d.area; d.g = d.sg / d.area; d.b = d.sb / d.area;
    });
    for (i = 0; i < labels.length; i++) labels[i] = remap[labels[i]];
    seg.regions = out;
    return seg;
  }

  /** Rule (b): a small region almost entirely inside a bigger one is part of
   *  it (phone screen, book spine, camera lens...). */
  function mergeContained(seg, tolerance) {
    var regs = seg.regions;
    var dsu = makeDSU(regs.length);
    var labs = regs.map(function (r) { return srgbToLab(r.r, r.g, r.b); });
    var order = regs.slice().sort(function (a, b) { return b.area - a.area; });

    for (var i = 0; i < order.length; i++) {
      var big = order[i];
      if (big.bg) continue;
      for (var j = i + 1; j < order.length; j++) {
        var small = order[j];
        if (small.bg) continue;
        if (small.area > big.area * 0.45) continue;
        var ox = Math.max(0, Math.min(big.x + big.w, small.x + small.w) - Math.max(big.x, small.x));
        var oy = Math.max(0, Math.min(big.y + big.h, small.y + small.h) - Math.max(big.y, small.y));
        var contain = (ox * oy) / (small.w * small.h);
        if (contain < 0.85) continue;
        if (deltaE(labs[big.id], labs[small.id]) > tolerance) continue;
        dsu.union(big.id, small.id);
      }
    }
    return applyMerge(seg, dsu);
  }

  /* ==========================================================================
   * SHAPE ANALYSIS
   * Second-order image moments give the object's own axis; everything else is
   * measured in that rotated frame so orientation stops mattering.
   * ========================================================================*/

  function shapeOf(seg, reg) {
    var labels = seg.labels, W = seg.W, H = seg.H;
    var x0 = reg.x, y0 = reg.y, x1 = reg.x + reg.w, y1 = reg.y + reg.h;
    var id = reg.id;
    var n = 0, sx = 0, sy = 0, x, y, i, k;

    /* ---- collect the region's pixels once, then work on the list --------- */
    var cap = reg.area + 8;
    var px = new Int32Array(cap), py = new Int32Array(cap);
    var hist = new Uint32Array(PAL.length);
    var boundary = 0;
    for (y = y0; y < y1; y++) {
      for (x = x0; x < x1; x++) {
        var idx = y * W + x;
        if (labels[idx] !== id) continue;
        if (n < cap) { px[n] = x; py[n] = y; }
        n++; sx += x; sy += y;
        hist[seg.palIdx[idx]]++;
        // boundary pixel = has a 4-neighbour outside the region (or off-frame)
        if (x === 0 || x === W - 1 || y === 0 || y === H - 1 ||
            labels[idx - 1] !== id || labels[idx + 1] !== id ||
            labels[idx - W] !== id || labels[idx + W] !== id) boundary++;
      }
    }
    if (n === 0) return null;
    n = Math.min(n, cap);
    var cx = sx / n, cy = sy / n;

    /* ---- minimum-area oriented box -------------------------------------
     * Principal axes alone fail on symmetric shapes: a square has no
     * preferred axis, the moments come out as noise, and it gets measured
     * across its diagonal (fill 0.5 → "irregular"). Sweeping angles and
     * keeping the tightest box is stable for every shape. */
    function extentsAt(angle) {
      var c = Math.cos(-angle), s = Math.sin(-angle);
      var uMin = Infinity, uMax = -Infinity, vMin = Infinity, vMax = -Infinity;
      for (var j = 0; j < n; j++) {
        var qx = px[j] - cx, qy = py[j] - cy;
        var u = qx * c - qy * s, v = qx * s + qy * c;
        if (u < uMin) uMin = u; if (u > uMax) uMax = u;
        if (v < vMin) vMin = v; if (v > vMax) vMax = v;
      }
      return { uMin: uMin, uMax: uMax, vMin: vMin, vMax: vMax,
               w: Math.max(1, uMax - uMin + 1), h: Math.max(1, vMax - vMin + 1) };
    }

    var best = null, bestAngle = 0, bestArea = Infinity;
    var HALF_PI = Math.PI / 2;
    for (k = 0; k < 12; k++) {                       // coarse: every 7.5°
      var a = k * HALF_PI / 12;
      var e = extentsAt(a);
      if (e.w * e.h < bestArea) { bestArea = e.w * e.h; best = e; bestAngle = a; }
    }
    for (k = -3; k <= 3; k++) {                      // refine: ±5.6° in 1.9° steps
      if (!k) continue;
      var a2 = bestAngle + k * (HALF_PI / 48);
      var e2 = extentsAt(a2);
      if (e2.w * e2.h < bestArea) { bestArea = e2.w * e2.h; best = e2; bestAngle = a2; }
    }
    var theta = bestAngle;
    var cos = Math.cos(-theta), sin = Math.sin(-theta);
    var uMin = best.uMin, vMin = best.vMin;
    var ow = best.w, oh = best.h;

    /* ---- 4×4 occupancy grid in that frame ------------------------------ */
    var grid = new Float32Array(16), cell = new Float32Array(16);
    for (var j2 = 0; j2 < n; j2++) {
      var ax = px[j2] - cx, ay = py[j2] - cy;
      var uu = ax * cos - ay * sin, vv = ax * sin + ay * cos;
      var gx = Math.min(3, Math.max(0, Math.floor((uu - uMin) / ow * 4)));
      var gy = Math.min(3, Math.max(0, Math.floor((vv - vMin) / oh * 4)));
      grid[gy * 4 + gx]++;
    }
    var cellArea = (ow * oh) / 16;
    for (i = 0; i < 16; i++) cell[i] = Math.min(1, grid[i] / cellArea);

    /* ---- outline roughness ---------------------------------------------
     * A smooth silhouette (mug, sock) sits near 1. A ragged one (crumpled
     * hoodie, bunch of keys) climbs well above it. */
    var roughness = (boundary * boundary) / (4 * Math.PI * n);

    var longSide = Math.max(ow, oh), shortSide = Math.min(ow, oh);
    var aspect = longSide / shortSide;
    var fill = n / (ow * oh);
    var corners = (cell[0] + cell[3] + cell[12] + cell[15]) / 4;
    var centre = (cell[5] + cell[6] + cell[9] + cell[10]) / 4;
    var rim = 0;
    for (i = 0; i < 16; i++) if (i !== 5 && i !== 6 && i !== 9 && i !== 10) rim += cell[i];
    rim /= 12;
    var topRow = (cell[0] + cell[1] + cell[2] + cell[3]) / 4;
    var botRow = (cell[12] + cell[13] + cell[14] + cell[15]) / 4;

    var shape = decideShape({ aspect: aspect, fill: fill, corners: corners, roughness: roughness,
                              centre: centre, rim: rim, topRow: topRow, botRow: botRow });

    var domI = 0;
    for (i = 1; i < hist.length; i++) if (hist[i] > hist[domI]) domI = i;

    return {
      shape: shape, aspect: aspect, fill: fill, corners: corners, dominant: domI,
      centre: centre, rim: rim, theta: theta, roughness: roughness,
      orientedW: ow, orientedH: oh, cx: cx, cy: cy, pixels: n
    };
  }

  /**
   * The shape rulebook. Deliberately small, ordered and readable — this is the
   * file to edit if the app starts calling your shoes "oval".
   * Inputs are all resolution-independent ratios, so the same thresholds work
   * at every engine setting.
   */
  function decideShape(f) {
    // a ring — filled edge, hollow middle (belt, headphones)
    if (f.centre < 0.34 && f.rim > 0.5) return f.aspect <= 1.35 ? 'round' : 'oval';

    // very elongated: long and thin wins regardless of how the corners score,
    // because a pen at analysis resolution is only a few pixels wide
    if (f.aspect >= 3.2 && f.fill >= 0.5) return 'long';

    // ragged outline and loose packing → a bunch of stuff, not a clean shape
    if (f.roughness >= 1.35 && f.fill < 0.72) return 'irregular';

    // straight edges, corners filled → box family
    if (f.fill >= 0.86 && f.corners >= 0.55) {
      if (f.aspect >= 3.0) return 'long';
      if (f.aspect <= 1.2) return 'square';
      return 'rectangular';
    }

    // curved outline, empty corners → circle family
    if (f.fill >= 0.62 && f.corners <= 0.55) {
      if (f.aspect >= 2.6) return 'long';
      if (f.aspect >= 1.35) return 'oval';
      return 'round';
    }

    // one end much narrower than the other, with a clean outline
    if (f.fill >= 0.35 && f.fill < 0.66 && f.roughness <= 1.3) {
      var ratio = f.topRow < f.botRow ? f.topRow / (f.botRow || 1) : f.botRow / (f.topRow || 1);
      if (ratio < 0.3) return 'triangular';
    }

    return 'irregular';
  }

  /* ==========================================================================
   * NAMING
   * ========================================================================*/

  function iou(a, b) {
    var ox = Math.max(0, Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x));
    var oy = Math.max(0, Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y));
    var inter = ox * oy;
    return inter / (a.w * a.h + b.w * b.h - inter);
  }

  /** Score a region against every catalogue profile; keep the top three. */
  function guessObject(det, frameH) {
    var scores = [];
    for (var i = 0; i < D.CATALOG.length; i++) {
      var c = D.CATALOG[i];
      var shapeScore = c.shapes[det.shape] || 0;
      if (!shapeScore) {
        // partial credit through the similarity table
        for (var k in c.shapes) {
          var sim = (D.SHAPE_SIM[det.shape] && D.SHAPE_SIM[det.shape][k]) || 0;
          shapeScore = Math.max(shapeScore, sim * c.shapes[k] * 0.75);
        }
      }
      var aspectScore = rangeScore(det.aspect, c.aspect[0], c.aspect[1], 0.45);
      var sizeScore = rangeScore(det.sizeFrac, c.hFrac[0], c.hFrac[1], 0.35);
      /* Specificity: "anything 1.5–6× as long as it is wide" describes half the
       * catalogue, so a profile that vague should not beat a tight one that
       * fits just as well. */
      var spec = 1 - 0.16 * Math.min(1.6, relSpan(c.aspect) + relSpan(c.hFrac)) / 1.6;
      var total = (shapeScore * 0.42 + aspectScore * 0.32 + sizeScore * 0.26) * spec;
      scores.push({ id: c.id, name: c.name, cat: c.cat, score: total });
    }
    scores.sort(function (a, b) { return b.score - a.score; });
    var top = scores.slice(0, 3);
    /* Confidence is how much the winner beats the runners-up, not its raw
     * score. Three profiles that fit equally well should read as a shrug
     * (~35%), not as three separate 95%s. */
    var sharp = scores.slice(0, 4).map(function (t) { return Math.pow(t.score, 9); });
    var sum = sharp.reduce(function (a, b) { return a + b; }, 0) || 1;
    top.forEach(function (t, i) {
      t.pct = Math.max(16, Math.min(94, Math.round(sharp[i] / sum * 100 * 0.97)));
    });
    return top;
  }

  /** Peaks at the middle of [lo,hi] and tapers off outside it. Peaked rather
   *  than flat so "dead centre" outranks "only just inside". */
  function rangeScore(v, lo, hi, slack) {
    var half = (hi - lo) / 2 || 0.001, mid = (lo + hi) / 2;
    if (v >= lo && v <= hi) return 1 - 0.32 * Math.abs(v - mid) / half;
    var d = v < lo ? (lo - v) : (v - hi);
    return Math.max(0, 0.68 - 0.68 * d / (half * 2 * (1 + slack) + 0.0001));
  }

  /** Width of a profile range relative to its centre. */
  function relSpan(range) {
    var mid = (range[0] + range[1]) / 2 || 1;
    return (range[1] - range[0]) / mid;
  }

  /** Plain-language position, for objects with no answer-key entry. */
  function describeWhere(box, worldW, worldH) {
    var cx = box.x + box.w / 2, cy = box.y + box.h / 2;
    var col = cx < worldW / 3 ? 'left' : cx < worldW * 2 / 3 ? 'middle' : 'right';
    var row = cy < worldH / 3 ? 'towards the back' : cy < worldH * 2 / 3 ? 'centre height' : 'near the front edge';
    return col + ' of the view, ' + row;
  }

  /* ==========================================================================
   * MAIN ENTRY POINT
   * ========================================================================*/

  /**
   * @param {ImageData-like} world  full-resolution frame or room
   * @param {object} engine         from buildEngine()/makeEngine()
   * @param {object} [opts]
   *        opts.truth       ground-truth array (sample rooms only)
   *        opts.prefilter   { colors: [groupId], shape: shapeId }
   *        opts.maxRegions  safety cap
   */
  function detect(world, engine, opts) {
    opts = opts || {};
    var prof = engine.profile;
    var t = { start: now() };

    // 1. downscale ---------------------------------------------------------
    var aw = Math.min(prof.width, world.width);
    var ah = Math.max(1, Math.round(world.height * (aw / world.width)));
    var img = (aw === world.width && ah === world.height) ? world : R.resize(world, aw, ah);
    var scaleX = world.width / aw, scaleY = world.height / ah;
    t.downscale = now();

    // 2 + 3. quantise and flood fill ---------------------------------------
    var seg = segment(img, engine);
    t.segment = now();

    // 4. merge -------------------------------------------------------------
    seg = mergeTouching(flagBackground(seg), 15);
    if (prof.mergeContained) seg = mergeContained(flagBackground(seg), 46);
    flagBackground(seg);
    t.merge = now();

    // discard background: too big, or spanning the whole frame
    var total = aw * ah;
    var minArea = Math.max(20, Math.round(total * prof.minAreaFactor));
    var maxArea = total * 0.16;
    var candidates = seg.regions.filter(function (r) {
      if (r.bg) return false;
      if (r.area < minArea || r.area > maxArea) return false;
      if (r.w >= aw * 0.92 || r.h >= ah * 0.92) return false;
      if (r.w < aw * 0.022 && r.h < ah * 0.05) return false;
      if (Math.min(r.w, r.h) <= 2) return false;   // 1–2px slivers are edges, not things
      return true;
    });
    var foundRegions = candidates.length;

    // 5. prefilter on colour, before any expensive per-region work ----------
    var wantColors = (opts.prefilter && opts.prefilter.colors) || [];
    var wantShape = (opts.prefilter && opts.prefilter.shape) || '';
    var colorPassed = candidates;
    if (wantColors.length) {
      colorPassed = candidates.filter(function (r) {
        return wantColors.indexOf(GROUP_IDS[r.group]) !== -1;
      });
    }
    t.prefilter = now();

    // 6. shape ------------------------------------------------------------
    var shaped = [];
    colorPassed.slice(0, opts.maxRegions || 240).forEach(function (r) {
      var s = shapeOf(seg, r);
      if (s) shaped.push({ reg: r, shp: s });
    });
    t.shape = now();

    // shape prefilter — cheap now, and it saves the naming stage
    var namedInput = shaped;
    if (wantShape) {
      namedInput = shaped.filter(function (o) {
        var sim = (D.SHAPE_SIM[o.shp.shape] && D.SHAPE_SIM[o.shp.shape][wantShape]) || 0;
        return sim >= 0.3;
      });
    }

    // 7. name -------------------------------------------------------------
    var truth = opts.truth || null;
    var used = {};
    var detections = namedInput.map(function (o, i) {
      var r = o.reg, s = o.shp;
      var box = {
        x: r.x * scaleX, y: r.y * scaleY,
        w: r.w * scaleX, h: r.h * scaleY
      };
      var palI = (s.dominant !== undefined) ? s.dominant : classifyRGB(r.r, r.g, r.b);
      var det = {
        uid: 'r' + i + '-' + Math.round(box.x) + '-' + Math.round(box.y),
        box: box,
        boxA: { x: r.x, y: r.y, w: r.w, h: r.h },
        areaPx: r.area,
        color: { name: PAL[palI].name, group: PAL[palI].group, hex: R.rgbToHex(r.r, r.g, r.b) },
        shape: s.shape,
        aspect: s.aspect,
        fill: s.fill,
        theta: s.theta,
        roughness: s.roughness,
        corners: s.corners,
        sizeFrac: box.h / world.height,
        sizeBucket: bucketFor(box.h / world.height),
        label: null, labelSource: 'predicted', confidence: 0,
        guesses: [], where: describeWhere(box, world.width, world.height),
        catalogId: null
      };

      // answer key first
      var bestT = null, bestIoU = 0;
      if (truth) {
        for (var k = 0; k < truth.length; k++) {
          if (used[truth[k].id]) continue;
          var ov = iou(box, truth[k].box);
          if (ov > bestIoU) { bestIoU = ov; bestT = truth[k]; }
        }
      }
      if (bestT && bestIoU >= 0.32) {
        used[bestT.id] = true;
        det.label = bestT.name;
        det.catalogId = bestT.catalog;
        det.labelSource = 'labelled';
        det.truthId = bestT.id;
        det.iou = bestIoU;
        det.where = bestT.where;
        det.confidence = Math.round(Math.min(98, 70 + bestIoU * 30));
        var cat = D.CATALOG_BY_ID[bestT.catalog];
        det.guesses = [{ id: bestT.catalog, name: bestT.name, cat: cat ? cat.cat : 'Object',
                         score: det.confidence / 100, pct: det.confidence }];
      } else {
        det.guesses = guessObject(det, world.height);
        det.label = det.guesses[0] ? det.guesses[0].name : 'Unknown object';
        det.catalogId = det.guesses[0] ? det.guesses[0].id : null;
        det.confidence = det.guesses[0] ? det.guesses[0].pct : 20;
      }
      return det;
    });
    t.name = now();

    return {
      detections: detections,
      analysis: { width: aw, height: ah, scaleX: scaleX, scaleY: scaleY },
      stats: {
        engine: prof.id,
        lutBytes: engine.lutBytes,
        rawRegions: seg.regions.length,
        regions: foundRegions,
        afterColor: colorPassed.length,
        shaped: shaped.length,
        named: detections.length,
        skippedByPrefilter: foundRegions - detections.length,
        ms: {
          downscale: t.downscale - t.start,
          segment: t.segment - t.downscale,
          merge: t.merge - t.segment,
          prefilter: t.prefilter - t.merge,
          shape: t.shape - t.prefilter,
          name: t.name - t.shape,
          total: t.name - t.start
        }
      }
    };
  }

  function bucketFor(frac) {
    for (var i = 0; i < D.SIZES.length; i++) {
      var s = D.SIZES[i];
      if (frac >= s.range[0] && frac < s.range[1]) return s.id;
    }
    return 'large';
  }

  /* ==========================================================================
   * SELF-SCORING
   * Compares detections against a room's answer key. Powers the Accuracy card
   * and doubles as the app's own regression test.
   * ========================================================================*/
  function score(detections, truth) {
    var matched = 0, colorOk = 0, shapeOk = 0, ious = [];
    var taken = {};
    truth.forEach(function (gt) {
      var best = null, bestIoU = 0;
      detections.forEach(function (d, i) {
        if (taken[i]) return;
        var ov = iou(d.box, gt.box);
        if (ov > bestIoU) { bestIoU = ov; best = i; }
      });
      if (best !== null && bestIoU >= 0.32) {
        taken[best] = true; matched++; ious.push(bestIoU);
        var d = detections[best];
        var gtGroup = groupOfColorName(gt.color);
        if (d.color.group === gtGroup) colorOk++;
        if (d.shape === gt.shape) shapeOk++;
      }
    });
    return {
      truthCount: truth.length,
      detected: detections.length,
      matched: matched,
      recall: truth.length ? matched / truth.length : 0,
      precision: detections.length ? matched / detections.length : 0,
      colorAccuracy: matched ? colorOk / matched : 0,
      shapeAccuracy: matched ? shapeOk / matched : 0,
      meanIoU: ious.length ? ious.reduce(function (a, b) { return a + b; }, 0) / ious.length : 0
    };
  }

  function groupOfColorName(name) {
    for (var i = 0; i < D.COLORS.length; i++) if (D.COLORS[i].name === name) return D.COLORS[i].group;
    return name;
  }

  NS.Vision = {
    ENGINES: ENGINES,
    lutBuilder: lutBuilder,
    buildEngine: buildEngine,
    makeEngine: makeEngine,
    detect: detect,
    score: score,
    segment: segment,
    flagBackground: flagBackground,
    classifyRGB: classifyRGB,
    srgbToLab: srgbToLab,
    deltaE: deltaE,
    decideShape: decideShape,
    iou: iou,
    PAL: PAL,
    GROUP_IDS: GROUP_IDS,
    groupOfColorName: groupOfColorName
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = NS.Vision;
})(typeof globalThis !== 'undefined' ? globalThis : this);
