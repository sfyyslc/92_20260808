/* ============================================================================
 * Sweep — ui.js
 * ----------------------------------------------------------------------------
 * Everything that draws. app.js owns the state; this file only reads it.
 *
 * Three canvases:
 *   #view     the room, cropped to the current viewport
 *   #overlay  boxes, labels and the highlighter marks (redrawn every frame)
 *   #ribbon   the whole room as a thin strip, with a tick for every object
 *
 * The highlighter mark is the app's one piece of visual personality: a match
 * gets swiped in marker yellow, in the picture and again behind its name in the
 * results list. Same gesture in both places, so the connection reads instantly.
 * ==========================================================================*/
(function (global) {
  'use strict';

  var NS = global.Sweep || (global.Sweep = {});
  var D = NS.Data;

  var HL = '#ffe14d';        // highlighter
  var INK = '#14171f';
  var PAPER = '#edeee9';
  var SLATE = '#8992a3';
  var FLAG = '#ff4d3d';

  /* -- small DOM helpers --------------------------------------------------- */
  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined && text !== null) n.textContent = text;
    return n;
  }
  function clear(node) { while (node.firstChild) node.removeChild(node.firstChild); }

  /** Surface (plain object) → real ImageData the canvas will accept. */
  function toImageData(ctx, surface) {
    var img;
    try {
      img = new ImageData(new Uint8ClampedArray(surface.data), surface.width, surface.height);
    } catch (e) {
      img = ctx.createImageData(surface.width, surface.height);
      img.data.set(surface.data);
    }
    return img;
  }

  function roundRectPath(ctx, x, y, w, h, r) {
    r = Math.min(r, Math.abs(w) / 2, Math.abs(h) / 2);
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  /* ==========================================================================
   * VIEW — the room itself
   * ========================================================================*/

  function View(viewCanvas, overlayCanvas) {
    this.view = viewCanvas;
    this.overlay = overlayCanvas;
    this.vctx = viewCanvas.getContext('2d');
    this.octx = overlayCanvas.getContext('2d');
    this.worldCanvas = document.createElement('canvas');
    this.worldCtx = this.worldCanvas.getContext('2d');
    this.worldKey = null;
    this.transform = null;
  }

  /** Push a world image into the offscreen canvas (only when it changes). */
  View.prototype.setWorld = function (world, key) {
    if (this.worldKey === key) return;
    this.worldKey = key;
    this.worldCanvas.width = world.width;
    this.worldCanvas.height = world.height;
    this.worldCtx.putImageData(toImageData(this.worldCtx, world.surface), 0, 0);
  };

  /** Match the backing store to the CSS size, accounting for screen density. */
  View.prototype.resize = function () {
    var dpr = Math.min(2.5, global.devicePixelRatio || 1);
    var r = this.view.getBoundingClientRect();
    var w = Math.max(1, Math.round(r.width * dpr));
    var h = Math.max(1, Math.round(r.height * dpr));
    var changed = false;
    [this.view, this.overlay].forEach(function (c) {
      if (c.width !== w || c.height !== h) { c.width = w; c.height = h; changed = true; }
    });
    this.dpr = dpr;
    return changed;
  };

  /**
   * Work out which slice of the world is on screen.
   * Close-up: fill the canvas with the full height of the room and pan sideways.
   * Whole room: fit everything, letterboxed.
   */
  View.prototype.computeTransform = function (world, panX, fitRoom) {
    var cw = this.view.width, ch = this.view.height;
    var t;
    if (fitRoom) {
      var scale = Math.min(cw / world.width, ch / world.height);
      t = {
        scale: scale,
        offX: (cw - world.width * scale) / 2,
        offY: (ch - world.height * scale) / 2,
        srcX: 0, srcW: world.width, fit: true
      };
    } else {
      var s = ch / world.height;
      var srcW = Math.min(world.width, cw / s);
      var maxPan = Math.max(0, world.width - srcW);
      var x = Math.max(0, Math.min(maxPan, panX));
      t = { scale: s, offX: -x * s, offY: 0, srcX: x, srcW: srcW, fit: false, maxPan: maxPan };
    }
    this.transform = t;
    return t;
  };

  View.prototype.toScreen = function (box) {
    var t = this.transform;
    return {
      x: t.offX + box.x * t.scale,
      y: t.offY + box.y * t.scale,
      w: box.w * t.scale,
      h: box.h * t.scale
    };
  };

  /** Draw the room. */
  View.prototype.drawWorld = function (world) {
    var ctx = this.vctx, t = this.transform;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.fillStyle = '#0b0d12';
    ctx.fillRect(0, 0, this.view.width, this.view.height);
    ctx.imageSmoothingEnabled = true;
    ctx.drawImage(this.worldCanvas, t.offX, t.offY,
                  world.width * t.scale, world.height * t.scale);
  };

  /**
   * Draw boxes, labels and highlighter marks.
   * @param opts { results, toggles, time, focusUid, reduceMotion }
   */
  View.prototype.drawOverlay = function (opts) {
    var ctx = this.octx, W = this.overlay.width, H = this.overlay.height;
    var tg = opts.toggles, results = opts.results || [];
    var self = this;
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, W, H);
    if (!results.length) return;

    var matches = results.filter(function (r) { return r.match; });
    var scale = Math.max(0.75, Math.min(1.8, W / 900));
    var fontSize = Math.round(13 * scale);

    /* --- spotlight: dim everything that is not a match ------------------ */
    if (tg.dim && matches.length) {
      ctx.save();
      ctx.fillStyle = 'rgba(11,13,18,0.72)';
      ctx.fillRect(0, 0, W, H);
      ctx.globalCompositeOperation = 'destination-out';
      matches.forEach(function (r) {
        var b = self.toScreen(r.det.box);
        var pad = 10 * scale;
        var grad = ctx.createRadialGradient(
          b.x + b.w / 2, b.y + b.h / 2, Math.max(b.w, b.h) * 0.35,
          b.x + b.w / 2, b.y + b.h / 2, Math.max(b.w, b.h) * 0.95 + pad);
        grad.addColorStop(0, 'rgba(0,0,0,1)');
        grad.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = grad;
        ctx.fillRect(b.x - b.w, b.y - b.h, b.w * 3, b.h * 3);
      });
      ctx.restore();
    }

    /* --- non-matching detections ---------------------------------------- */
    if (tg.boxes && !tg.matchesOnly) {
      results.forEach(function (r) {
        if (r.match) return;
        var b = self.toScreen(r.det.box);
        if (b.x + b.w < 0 || b.x > W) return;
        ctx.save();
        ctx.strokeStyle = 'rgba(237,238,233,0.42)';
        ctx.lineWidth = Math.max(1, 1.1 * scale);
        ctx.setLineDash([5 * scale, 4 * scale]);
        roundRectPath(ctx, b.x, b.y, b.w, b.h, 4 * scale);
        ctx.stroke();
        ctx.restore();
        if (tg.labels) drawTag(ctx, self, r, b, scale, fontSize, false, tg);
      });
    }

    /* --- matches: the highlighter ---------------------------------------- */
    matches.forEach(function (r, i) {
      var b = self.toScreen(r.det.box);
      if (b.x + b.w < -40 || b.x > W + 40) return;
      var isFocus = (i === 0) || r.det.uid === opts.focusUid;
      drawHighlight(ctx, b, scale, opts.time, isFocus && !opts.reduceMotion);
      if (tg.labels) drawTag(ctx, self, r, b, scale, fontSize, true, tg);
    });
  };

  /** The signature mark: marker swipe, outline, corner ticks, soft pulse. */
  function drawHighlight(ctx, b, scale, time, animate) {
    var pad = 6 * scale;
    var x = b.x - pad, y = b.y - pad, w = b.w + pad * 2, h = b.h + pad * 2;

    ctx.save();
    // translucent marker body, laid down in two passes like a real highlighter
    ctx.globalAlpha = 0.2;
    ctx.fillStyle = HL;
    roundRectPath(ctx, x, y, w, h, 6 * scale);
    ctx.fill();
    ctx.globalAlpha = 0.16;
    roundRectPath(ctx, x + 2 * scale, y + 3 * scale, w - 4 * scale, h - 6 * scale, 5 * scale);
    ctx.fill();
    ctx.globalAlpha = 1;

    // glow + outline
    ctx.shadowColor = 'rgba(255,225,77,0.55)';
    ctx.shadowBlur = 16 * scale;
    ctx.strokeStyle = HL;
    ctx.lineWidth = 2.4 * scale;
    roundRectPath(ctx, x, y, w, h, 6 * scale);
    ctx.stroke();
    ctx.shadowBlur = 0;

    // ink corner ticks, so the mark still reads on top of a yellow object
    var c = Math.min(16 * scale, Math.min(w, h) * 0.3);
    ctx.strokeStyle = INK;
    ctx.lineWidth = 2.2 * scale;
    ctx.lineCap = 'round';
    [[x, y, 1, 1], [x + w, y, -1, 1], [x, y + h, 1, -1], [x + w, y + h, -1, -1]]
      .forEach(function (p) {
        ctx.beginPath();
        ctx.moveTo(p[0] + p[2] * c, p[1]);
        ctx.lineTo(p[0], p[1]);
        ctx.lineTo(p[0], p[1] + p[3] * c);
        ctx.stroke();
      });

    // one slow pulse ring on the best match
    if (animate) {
      var t = (time % 1800) / 1800;
      var grow = t * 22 * scale;
      ctx.globalAlpha = Math.max(0, 0.55 * (1 - t));
      ctx.strokeStyle = HL;
      ctx.lineWidth = 2 * scale;
      roundRectPath(ctx, x - grow, y - grow, w + grow * 2, h + grow * 2, (6 + grow) * scale);
      ctx.stroke();
      ctx.globalAlpha = 1;
    }
    ctx.restore();
  }

  /** Luggage-tag label with an optional confidence number. */
  function drawTag(ctx, view, r, b, scale, fontSize, isMatch, tg) {
    var det = r.det;
    var name = det.label || 'Object';
    var pct = tg.percent ? '  ' + det.confidence + '%' : '';
    var text = name + pct;

    ctx.save();
    ctx.font = '600 ' + fontSize + 'px ' + FONT_UI;
    var tw = ctx.measureText(text).width;
    var padX = 7 * scale, padY = 5 * scale;
    var th = fontSize + padY * 2;
    var tx = b.x, ty = b.y - th - 7 * scale;
    if (ty < 2) ty = b.y + b.h + 7 * scale;                 // flip below if clipped
    if (tx + tw + padX * 2 > view.overlay.width) tx = view.overlay.width - tw - padX * 2 - 2;
    if (tx < 2) tx = 2;

    // tag string, back to the object
    ctx.strokeStyle = isMatch ? HL : 'rgba(237,238,233,0.5)';
    ctx.lineWidth = Math.max(1, scale);
    ctx.beginPath();
    ctx.moveTo(tx + 8 * scale, ty + th);
    ctx.lineTo(b.x + Math.min(14 * scale, b.w / 2), b.y);
    ctx.stroke();

    roundRectPath(ctx, tx, ty, tw + padX * 2, th, 3 * scale);
    ctx.fillStyle = isMatch ? HL : 'rgba(20,23,31,0.86)';
    ctx.fill();
    if (!isMatch) {
      ctx.strokeStyle = 'rgba(237,238,233,0.28)';
      ctx.lineWidth = 1;
      ctx.stroke();
    }
    ctx.fillStyle = isMatch ? INK : PAPER;
    ctx.textBaseline = 'middle';
    ctx.fillText(text, tx + padX, ty + th / 2 + 0.5);
    ctx.restore();
  }

  var FONT_UI = 'system-ui, -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif';
  var FONT_MONO = 'ui-monospace, SFMono-Regular, Menlo, Consolas, monospace';

  /* ==========================================================================
   * RIBBON — the whole room as a strip, with a tick per object
   * ========================================================================*/

  function drawRibbon(canvas, view, world, results, transform, sweepX) {
    var ctx = canvas.getContext('2d');
    var dpr = Math.min(2.5, global.devicePixelRatio || 1);
    var rect = canvas.getBoundingClientRect();
    var W = Math.max(1, Math.round(rect.width * dpr));
    var H = Math.max(1, Math.round(rect.height * dpr));
    if (canvas.width !== W || canvas.height !== H) { canvas.width = W; canvas.height = H; }

    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.fillStyle = '#0b0d12';
    ctx.fillRect(0, 0, W, H);
    if (!world) return;

    var s = W / world.width;
    ctx.globalAlpha = 0.55;
    ctx.drawImage(view.worldCanvas, 0, (H - world.height * s) / 2, W, world.height * s);
    ctx.globalAlpha = 1;

    // ticks: every object found, matches in marker yellow
    (results || []).forEach(function (r) {
      var cx = (r.det.box.x + r.det.box.w / 2) * s;
      if (r.match) {
        ctx.fillStyle = HL;
        ctx.fillRect(cx - 1.5 * dpr, 0, 3 * dpr, H);
        ctx.beginPath();
        ctx.arc(cx, H / 2, 4.5 * dpr, 0, Math.PI * 2);
        ctx.fillStyle = HL; ctx.fill();
        ctx.strokeStyle = INK; ctx.lineWidth = 1.5 * dpr; ctx.stroke();
      } else {
        ctx.fillStyle = 'rgba(237,238,233,0.55)';
        ctx.fillRect(cx - 0.5 * dpr, H * 0.34, 1.5 * dpr, H * 0.32);
      }
    });

    // where the camera is looking
    if (transform && !transform.fit) {
      var vx = transform.srcX * s, vw = transform.srcW * s;
      ctx.fillStyle = 'rgba(11,13,18,0.55)';
      ctx.fillRect(0, 0, vx, H);
      ctx.fillRect(vx + vw, 0, W - vx - vw, H);
      ctx.strokeStyle = PAPER;
      ctx.lineWidth = 1.5 * dpr;
      ctx.strokeRect(vx + 0.75 * dpr, 0.75 * dpr, vw - 1.5 * dpr, H - 1.5 * dpr);
    }

    // sweep head, while a sweep is running
    if (typeof sweepX === 'number') {
      ctx.fillStyle = HL;
      ctx.fillRect(sweepX * s - dpr, 0, 2 * dpr, H);
    }
  }

  /* ==========================================================================
   * RESULTS LIST
   * ========================================================================*/

  function confBar(pct, match) {
    var wrap = el('div', 'bar');
    var fill = el('span', 'bar-fill' + (match ? ' is-match' : ''));
    fill.style.width = Math.max(3, Math.min(100, pct)) + '%';
    wrap.appendChild(fill);
    return wrap;
  }

  function renderResults(container, out, state, handlers) {
    clear(container);
    var results = out.results || [];
    var shown = state.toggles.matchesOnly ? results.filter(function (r) { return r.match; }) : results;

    if (!results.length) {
      container.appendChild(emptyState(
        'Nothing scanned yet',
        'Pick a room or start the camera, then sweep it.'));
      return;
    }
    if (out.searched && !out.matches.length) {
      var miss = el('div', 'miss');
      miss.appendChild(el('strong', null, 'No match in this room'));

      /* If the colour/shape filters threw work away before anything was even
       * named, say so plainly — otherwise "nothing scored high enough" is a
       * misleading answer to a question the app never actually asked. */
      var crit = out.criteria || {};
      var hidden = state.stats ? state.stats.skippedByPrefilter : 0;
      var active = [];
      if (crit.colors && crit.colors.length) active.push(crit.colors.join(' or '));
      if (crit.shape) active.push(crit.shape);

      if (hidden > 0 && active.length) {
        miss.appendChild(el('p', null,
          'Your filters (' + active.join(' + ') + ') skipped ' + hidden +
          ' of the ' + state.stats.regions + ' things in view, so they were never named. ' +
          'Turn a filter off if the thing you want might not look the way you expect.'));
      } else {
        miss.appendChild(el('p', null,
          'Nothing scored above ' + Math.round(out.threshold * 100) + '%. Try a shorter word, ' +
          'drop a filter, or sweep further along the room.'));
      }
      container.appendChild(miss);
    }
    if (!shown.length && state.toggles.matchesOnly) {
      container.appendChild(emptyState('Matches only is on',
        'Turn it off to see the other ' + results.length + ' objects found.'));
      return;
    }

    shown.forEach(function (r) {
      container.appendChild(resultRow(r, out, handlers));
    });
  }

  function resultRow(r, out, handlers) {
    var det = r.det;
    var row = el('button', 'result' + (r.match ? ' is-match' : ''));
    row.type = 'button';
    row.setAttribute('aria-label', 'Show ' + det.label + ' in the room');

    var sw = el('span', 'swatch');
    sw.style.background = det.color.hex;
    row.appendChild(sw);

    var main = el('div', 'result-main');
    var head = el('div', 'result-head');
    var nm = el('span', 'result-name', det.label || 'Object');
    if (r.match) nm.classList.add('marked');
    head.appendChild(nm);
    head.appendChild(el('span', 'result-pct', det.confidence + '%'));
    main.appendChild(head);

    var meta = el('div', 'result-meta');
    meta.textContent = det.color.group + ' · ' + det.shape + ' · ' + det.sizeBucket;
    main.appendChild(meta);

    main.appendChild(el('div', 'result-where', det.where));

    if (out.searched && r.reasons.length) {
      var rs = el('div', 'reasons');
      r.reasons.forEach(function (x) {
        var chip = el('span', 'reason ' + (x.ok ? 'ok' : 'no'), x.kind + ': ' + x.text);
        rs.appendChild(chip);
      });
      main.appendChild(rs);
    }

    main.appendChild(confBar(det.confidence, r.match));

    var src = el('div', 'result-src');
    src.appendChild(el('span', 'tagline', det.labelSource === 'labelled'
      ? 'known object' : 'best guess'));
    if (det.labelSource === 'predicted' && det.guesses.length > 1) {
      src.appendChild(el('span', 'alts', 'or ' + det.guesses.slice(1).map(function (g) {
        return g.name.toLowerCase() + ' ' + g.pct + '%';
      }).join(', ')));
    }
    main.appendChild(src);

    row.appendChild(main);
    row.addEventListener('click', function () { handlers.focus(det); });
    return row;
  }

  function emptyState(title, body) {
    var w = el('div', 'empty');
    w.appendChild(el('strong', null, title));
    w.appendChild(el('p', null, body));
    return w;
  }

  /* ==========================================================================
   * INVENTORY + LOG
   * ========================================================================*/

  function renderInventory(container, results, world) {
    clear(container);
    if (!results.length) {
      container.appendChild(emptyState('Nothing catalogued yet', 'Scan a room to build a list.'));
      return;
    }
    var groups = {};
    results.forEach(function (r) {
      var cat = (r.det.guesses[0] && r.det.guesses[0].cat) || 'Other';
      (groups[cat] = groups[cat] || []).push(r.det);
    });
    var head = el('p', 'panel-note',
      results.length + ' objects in ' + (world ? world.name : 'this view') + '.');
    container.appendChild(head);

    Object.keys(groups).sort().forEach(function (cat) {
      container.appendChild(el('h3', 'eyebrow', cat));
      var list = el('ul', 'inv');
      groups[cat].forEach(function (det) {
        var li = el('li');
        var sw = el('span', 'swatch sm');
        sw.style.background = det.color.hex;
        li.appendChild(sw);
        li.appendChild(el('span', 'inv-name', det.label));
        li.appendChild(el('span', 'inv-meta', det.color.group + ' · ' + det.shape));
        list.appendChild(li);
      });
      container.appendChild(list);
    });
  }

  function statRow(label, value) {
    var row = el('div', 'stat');
    row.appendChild(el('span', 'stat-k', label));
    row.appendChild(el('span', 'stat-v', value));
    return row;
  }

  function renderLog(container, state) {
    clear(container);

    /* accuracy — only meaningful where an answer key exists */
    if (state.accuracy) {
      var a = state.accuracy;
      var card = el('section', 'card');
      card.appendChild(el('h3', 'eyebrow', 'Checked against the answer key'));
      card.appendChild(el('p', 'panel-note',
        'This room ships with a list of what is really in it, so the app can mark its own work.'));
      card.appendChild(statRow('Objects found', a.matched + ' of ' + a.truthCount));
      card.appendChild(statRow('False alarms', Math.max(0, a.detected - a.matched)));
      card.appendChild(statRow('Colour named right', Math.round(a.colorAccuracy * 100) + '%'));
      card.appendChild(statRow('Shape named right', Math.round(a.shapeAccuracy * 100) + '%'));
      card.appendChild(statRow('Box overlap (mean)', Math.round(a.meanIoU * 100) + '%'));
      container.appendChild(card);
    }

    if (state.stats) {
      var s = state.stats;
      var perf = el('section', 'card');
      perf.appendChild(el('h3', 'eyebrow', 'Last scan'));
      perf.appendChild(statRow('Detector', NS.Vision.ENGINES[s.engine].name));
      perf.appendChild(statRow('Colour table', s.lutBytes.toLocaleString() + ' entries'));
      perf.appendChild(statRow('Regions found', s.regions));
      if (s.skippedByPrefilter > 0) {
        perf.appendChild(statRow('Skipped by filters', s.skippedByPrefilter +
          ' of ' + s.regions));
      }
      perf.appendChild(statRow('Objects named', s.named));
      perf.appendChild(statRow('Total time', s.ms.total.toFixed(0) + ' ms'));
      var bd = el('div', 'ms');
      [['segment', s.ms.segment], ['merge', s.ms.merge], ['shape', s.ms.shape], ['name', s.ms.name]]
        .forEach(function (p) {
          var b = el('span', 'ms-part', p[0] + ' ' + p[1].toFixed(0) + 'ms');
          bd.appendChild(b);
        });
      perf.appendChild(bd);
      container.appendChild(perf);
    }

    if (state.stitch) {
      var st = state.stitch;
      var sc = el('section', 'card');
      sc.appendChild(el('h3', 'eyebrow', 'Last sweep'));
      sc.appendChild(statRow('Frames joined', st.frames));
      sc.appendChild(statRow('Panorama width', Math.round(st.width) + ' px'));
      sc.appendChild(statRow('Match confidence', Math.round(st.meanConfidence * 100) + '%'));
      if (st.meanShiftError !== null && st.meanShiftError !== undefined) {
        sc.appendChild(statRow('Alignment error', st.meanShiftError.toFixed(1) + ' px avg / ' +
          st.maxShiftError + ' px worst'));
      }
      if (st.fallbacks) sc.appendChild(statRow('Frames guessed from pace', st.fallbacks));
      container.appendChild(sc);
    }

    var hist = el('section', 'card');
    hist.appendChild(el('h3', 'eyebrow', 'Search history'));
    var ul = el('ul', 'log');
    state.history.forEach(function (h) {
      var li = el('li', h.found ? 'hit' : 'missed');
      li.appendChild(el('span', 'log-when', h.when));
      li.appendChild(el('span', 'log-q', '“' + h.query + '” in ' + h.room));
      li.appendChild(el('span', 'log-d', h.detail));
      ul.appendChild(li);
    });
    hist.appendChild(ul);
    container.appendChild(hist);
  }

  NS.UI = {
    el: el, clear: clear, View: View, drawRibbon: drawRibbon,
    renderResults: renderResults, renderInventory: renderInventory, renderLog: renderLog,
    emptyState: emptyState, toImageData: toImageData,
    colors: { HL: HL, INK: INK, PAPER: PAPER, SLATE: SLATE, FLAG: FLAG }
  };
})(typeof globalThis !== 'undefined' ? globalThis : this);
