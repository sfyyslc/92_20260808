/* ============================================================================
 * tests/harness.js — test plumbing, no external packages
 * ----------------------------------------------------------------------------
 * Two jobs:
 *   1. A tiny assert/report framework.
 *   2. Enough of a browser to boot the real index.html under Node: an HTML
 *      parser, a DOM, a canvas 2D stub, and a fake clock.
 *
 * The DOM is built by parsing the actual index.html, not by hand. That is the
 * point — if an id in the markup and an id in app.js drift apart, the boot test
 * throws, which is exactly the bug a human would hit on first load.
 * ==========================================================================*/
'use strict';

const fs = require('fs');
const path = require('path');
const vm = require('vm');

/* ==========================================================================
 * 1. TEST FRAMEWORK
 * ========================================================================*/
const results = { pass: 0, fail: 0, failures: [] };
let group = '';

function suite(name) { group = name; console.log('\n\x1b[1m' + name + '\x1b[0m'); }

function check(label, ok, detail) {
  if (ok) {
    results.pass++;
    console.log('  \x1b[32m✓\x1b[0m ' + label + (detail ? '  \x1b[90m' + detail + '\x1b[0m' : ''));
  } else {
    results.fail++;
    results.failures.push(group + ' › ' + label + (detail ? ' — ' + detail : ''));
    console.log('  \x1b[31m✗ ' + label + (detail ? '  ' + detail : '') + '\x1b[0m');
  }
}

const t = {
  ok:  (label, v, d) => check(label, !!v, d),
  eq:  (label, a, b) => check(label, a === b, 'got ' + fmt(a) + ', want ' + fmt(b)),
  gte: (label, a, b) => check(label, a >= b, fmt(a) + ' >= ' + fmt(b)),
  lte: (label, a, b) => check(label, a <= b, fmt(a) + ' <= ' + fmt(b)),
  near: (label, a, b, tol) =>
    check(label, Math.abs(a - b) <= tol, fmt(a) + ' ≈ ' + fmt(b) + ' ±' + tol),
  throws: (label, fn) => {
    let threw = false;
    try { fn(); } catch (e) { threw = true; }
    check(label, threw, threw ? '' : 'no error raised');
  }
};

function fmt(v) {
  if (typeof v === 'number') return Number.isInteger(v) ? String(v) : v.toFixed(3);
  return JSON.stringify(v);
}

function report() {
  const total = results.pass + results.fail;
  console.log('\n' + '─'.repeat(62));
  if (results.fail === 0) {
    console.log('\x1b[32m\x1b[1m  ' + total + ' checks, all passing\x1b[0m');
  } else {
    console.log('\x1b[31m\x1b[1m  ' + results.fail + ' of ' + total + ' checks failing\x1b[0m');
    results.failures.forEach(f => console.log('    · ' + f));
  }
  console.log('─'.repeat(62) + '\n');
  return results.fail === 0;
}

/* ==========================================================================
 * 2. HTML PARSER
 * Handles the subset of HTML this project uses: tags, attributes, text,
 * comments, void elements. No entity decoding beyond the few we emit.
 * ========================================================================*/
const VOID = new Set(['meta', 'link', 'input', 'br', 'hr', 'img', 'source', 'area', 'col']);
const ATTR_RE = /([a-zA-Z_:][-a-zA-Z0-9_:.]*)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s"'>]+)))?/g;

function parseHTML(src, doc) {
  const root = doc.createElement('#root');
  const stack = [root];
  const tagRe = /<!--[\s\S]*?-->|<\/([a-zA-Z][-a-zA-Z0-9]*)\s*>|<([a-zA-Z][-a-zA-Z0-9]*)((?:[^>"']|"[^"]*"|'[^']*')*?)(\/?)>/g;
  let last = 0, m;

  while ((m = tagRe.exec(src))) {
    const text = src.slice(last, m.index);
    if (text.trim()) stack[stack.length - 1].appendChild(doc.createTextNode(text));
    last = tagRe.lastIndex;

    if (m[0].startsWith('<!--')) continue;

    if (m[1]) {                                   // closing tag
      for (let i = stack.length - 1; i > 0; i--) {
        if (stack[i].tagName === m[1].toLowerCase()) { stack.length = i; break; }
      }
      continue;
    }

    const tag = m[2].toLowerCase();
    const node = doc.createElement(tag);
    let a;
    ATTR_RE.lastIndex = 0;
    while ((a = ATTR_RE.exec(m[3] || ''))) {
      const val = a[2] !== undefined ? a[2] : a[3] !== undefined ? a[3] : a[4] !== undefined ? a[4] : '';
      node.setAttribute(a[1].toLowerCase(), val);
    }
    stack[stack.length - 1].appendChild(node);
    if (!VOID.has(tag) && !m[4]) stack.push(node);
  }
  const tail = src.slice(last);
  if (tail.trim()) stack[stack.length - 1].appendChild(doc.createTextNode(tail));
  return root;
}

/* ==========================================================================
 * 3. CANVAS 2D STUB
 * Every drawing call is a no-op that gets counted, so a test can assert that
 * something was actually painted. Calls that must return a value do.
 * ========================================================================*/
function makeContext(canvas) {
  const calls = Object.create(null);
  const base = {
    canvas,
    __calls: calls,
    createImageData: (w, h) => ({ width: w, height: h, data: new Uint8ClampedArray(w * h * 4) }),
    getImageData: (x, y, w, h) => ({ width: w, height: h, data: new Uint8ClampedArray(w * h * 4) }),
    createLinearGradient: () => ({ addColorStop() {} }),
    createRadialGradient: () => ({ addColorStop() {} }),
    createPattern: () => null,
    measureText: (s) => ({ width: String(s).length * 6 })
  };
  // Any other 2D method is a counted no-op.
  return new Proxy(base, {
    get(target, prop) {
      if (prop in target) return target[prop];
      if (typeof prop !== 'string') return undefined;
      if (prop === 'then') return undefined;                 // not a promise
      return function () { calls[prop] = (calls[prop] || 0) + 1; };
    },
    set(target, prop, value) { target[prop] = value; return true; }
  });
}

/* ==========================================================================
 * 4. DOM
 * ========================================================================*/
function createDocument() {
  const byId = new Map();

  class ClassList {
    constructor(node) { this.node = node; this.set = new Set(); }
    add(...c) { c.forEach(x => x && this.set.add(x)); this.sync(); }
    remove(...c) { c.forEach(x => this.set.delete(x)); this.sync(); }
    contains(c) { return this.set.has(c); }
    toggle(c, force) {
      const on = force === undefined ? !this.set.has(c) : !!force;
      on ? this.set.add(c) : this.set.delete(c);
      this.sync();
      return on;
    }
    sync() { this.node.attrs.class = [...this.set].join(' '); }
    get value() { return [...this.set].join(' '); }
  }

  class Node {
    constructor(tag) {
      this.tagName = tag;
      this.attrs = Object.create(null);
      this.dataset = Object.create(null);
      this.style = Object.create(null);
      this.children = [];
      this.childNodes = [];
      this.parentNode = null;
      this.listeners = Object.create(null);
      this.classList = new ClassList(this);
      this._text = '';
      this.hidden = false;
      this.disabled = false;
      this.checked = false;
      this.value = '';
      this.tabIndex = -1;
      if (tag === 'canvas') { this.width = 300; this.height = 150; this._ctx = null; }
    }

    /* -- attributes ----------------------------------------------------- */
    setAttribute(k, v) {
      this.attrs[k] = String(v);
      if (k === 'class') { this.classList.set = new Set(String(v).split(/\s+/).filter(Boolean)); }
      else if (k === 'id') byId.set(String(v), this);
      else if (k === 'value') this.value = String(v);
      else if (k === 'hidden') this.hidden = true;
      else if (k === 'checked') this.checked = true;
      else if (k === 'disabled') this.disabled = true;
      else if (k.startsWith('data-')) {
        this.dataset[k.slice(5).replace(/-([a-z])/g, (_, c) => c.toUpperCase())] = String(v);
      }
    }
    getAttribute(k) { return k in this.attrs ? this.attrs[k] : null; }
    removeAttribute(k) { delete this.attrs[k]; }
    get id() { return this.attrs.id || ''; }
    get className() { return this.classList.value; }
    set className(v) { this.setAttribute('class', v); }

    /* -- tree ----------------------------------------------------------- */
    appendChild(node) {
      node.parentNode = this;
      this.childNodes.push(node);
      if (node.tagName !== '#text') this.children.push(node);
      return node;
    }
    removeChild(node) {
      this.childNodes = this.childNodes.filter(n => n !== node);
      this.children = this.children.filter(n => n !== node);
      node.parentNode = null;
      return node;
    }
    get firstChild() { return this.childNodes[0] || null; }
    get lastChild() { return this.childNodes[this.childNodes.length - 1] || null; }

    /* -- content -------------------------------------------------------- */
    get textContent() {
      if (this.tagName === '#text') return this._text;
      return this.childNodes.map(n => n.textContent).join('');
    }
    set textContent(v) {
      this.childNodes = [];
      this.children = [];
      this._text = String(v);
      if (this.tagName !== '#text') {
        const tn = new Node('#text');
        tn._text = String(v);
        this.appendChild(tn);
      }
    }
    get innerHTML() { return this._html || this.textContent; }
    set innerHTML(v) {
      this._html = String(v);
      this.childNodes = [];
      this.children = [];
      const tn = new Node('#text');
      tn._text = String(v).replace(/<[^>]*>/g, '');
      this.appendChild(tn);
    }

    /* -- queries -------------------------------------------------------- */
    matches(sel) {
      if (sel.startsWith('.')) return this.classList.contains(sel.slice(1));
      if (sel.startsWith('#')) return this.id === sel.slice(1);
      return this.tagName === sel.toLowerCase();
    }
    querySelectorAll(sel) {
      const out = [];
      const walk = n => {
        n.children.forEach(c => { if (c.matches(sel)) out.push(c); walk(c); });
      };
      walk(this);
      return out;
    }
    querySelector(sel) { return this.querySelectorAll(sel)[0] || null; }

    /* -- events --------------------------------------------------------- */
    addEventListener(type, fn) { (this.listeners[type] ||= []).push(fn); }
    removeEventListener(type, fn) {
      this.listeners[type] = (this.listeners[type] || []).filter(f => f !== fn);
    }
    /** Test-only: fire a handler as the browser would. */
    fire(type, event) {
      const e = Object.assign(
        { type, target: this, currentTarget: this, preventDefault() {}, stopPropagation() {} },
        event || {});
      (this.listeners[type] || []).forEach(fn => fn.call(this, e));
      return e;
    }
    get __hasListeners() { return Object.keys(this.listeners).length > 0; }

    /* -- misc browser API ----------------------------------------------- */
    getContext() { return (this._ctx ||= makeContext(this)); }
    /* The CSS box is deliberately independent of canvas.width/height. In a real
     * browser those are different things; conflating them makes a resize()
     * that reads the rect and writes the backing store grow without bound. */
    getBoundingClientRect() {
      const l = this.__layout || { width: 900, height: this.tagName === 'canvas' ? 560 : 400 };
      return { left: 0, top: 0, x: 0, y: 0,
               width: l.width, height: l.height, right: l.width, bottom: l.height };
    }
    setPointerCapture() {}
    releasePointerCapture() {}
    focus() {}
    blur() {}
    scrollIntoView() {}
    play() { return Promise.resolve(); }
    pause() {}
  }

  const doc = {
    readyState: 'complete',
    createElement: (tag) => new Node(String(tag).toLowerCase()),
    createTextNode: (txt) => { const n = new Node('#text'); n._text = txt; return n; },
    getElementById: (id) => byId.get(id) || null,
    querySelectorAll: (sel) => doc.documentElement.querySelectorAll(sel),
    querySelector: (sel) => doc.documentElement.querySelector(sel),
    addEventListener() {},
    removeEventListener() {},
    __byId: byId,
    Node
  };
  return doc;
}

/* ==========================================================================
 * 5. FAKE CLOCK + rAF
 * ========================================================================*/
function makeClock() {
  let now = 0, seq = 0;
  const timers = new Map();
  const raf = [];

  return {
    now: () => now,
    setTimeout(fn, ms) { const id = ++seq; timers.set(id, { at: now + (ms || 0), fn }); return id; },
    clearTimeout(id) { timers.delete(id); },
    setInterval(fn, ms) {
      const id = ++seq;
      timers.set(id, { at: now + (ms || 0), fn, every: Math.max(1, ms || 1) });
      return id;
    },
    clearInterval(id) { timers.delete(id); },
    requestAnimationFrame(fn) { raf.push(fn); return raf.length; },
    cancelAnimationFrame() {},

    /** Run queued animation frames, up to `max`, stopping early if `until` says so. */
    drainFrames(max, until) {
      let n = 0;
      while (raf.length && n < max) {
        const batch = raf.splice(0, raf.length);
        for (const fn of batch) { now += 16; fn(now); n++; if (until && until()) return n; }
      }
      return n;
    },
    /** Move the clock forward, firing timers and animation frames as we go. */
    advance(ms, frameCap = 4) {
      const target = now + ms;
      let guard = 0;
      while (now < target && guard++ < 10000) {
        const due = [...timers.entries()].filter(([, x]) => x.at <= target)
          .sort((a, b) => a[1].at - b[1].at)[0];
        if (!due) break;
        const [id, timer] = due;
        now = Math.max(now, timer.at);
        if (timer.every) timer.at = now + timer.every; else timers.delete(id);
        timer.fn();
        this.drainFrames(frameCap);
      }
      now = Math.max(now, target);
      this.drainFrames(frameCap);
    },
    get pendingFrames() { return raf.length; },
    get pendingTimers() { return timers.size; }
  };
}

/* ==========================================================================
 * 6. BOOT THE REAL APP
 * Reads index.html, honours its <script> order, and runs everything in a vm
 * sandbox so nothing leaks into the Node process.
 * ========================================================================*/
function bootApp(appDir) {
  const html = fs.readFileSync(path.join(appDir, 'index.html'), 'utf8');
  const doc = createDocument();
  doc.documentElement = parseHTML(html, doc);

  // script order comes from the markup, so a missing/misordered file fails here
  const scripts = [...html.matchAll(/<script\s+src="([^"]+)"><\/script>/g)].map(m => m[1]);

  const clock = makeClock();
  const sandbox = {
    document: doc,
    console,
    performance: { now: clock.now },
    setTimeout: clock.setTimeout.bind(clock),
    clearTimeout: clock.clearTimeout.bind(clock),
    setInterval: clock.setInterval.bind(clock),
    clearInterval: clock.clearInterval.bind(clock),
    requestAnimationFrame: clock.requestAnimationFrame.bind(clock),
    cancelAnimationFrame: clock.cancelAnimationFrame.bind(clock),
    matchMedia: () => ({ matches: false, addEventListener() {}, addListener() {} }),
    navigator: { userAgent: 'sweep-test' },       // no mediaDevices → no camera
    devicePixelRatio: 2,
    addEventListener() {},
    removeEventListener() {},
    Uint8ClampedArray, Uint32Array, Int32Array, Float32Array, Math, Date, JSON,
    Number, String, Array, Object, Boolean, Error, isNaN, parseInt, parseFloat
  };
  sandbox.window = sandbox;
  sandbox.globalThis = sandbox;
  sandbox.self = sandbox;
  // no localStorage on purpose: exercises the in-memory preference fallback

  const ctx = vm.createContext(sandbox);
  const loaded = [];
  for (const src of scripts) {
    const file = path.join(appDir, src);
    if (!fs.existsSync(file)) throw new Error('index.html references a missing file: ' + src);
    vm.runInContext(fs.readFileSync(file, 'utf8'), ctx, { filename: src });
    loaded.push(src);
  }
  return { doc, clock, sandbox, scripts: loaded, html };
}

module.exports = { suite, check, t, report, results, parseHTML, createDocument,
                   makeClock, bootApp, makeContext };
