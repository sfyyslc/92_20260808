/* ============================================================================
 * tests/ui.test.js — boot the real page and drive it
 * ----------------------------------------------------------------------------
 * Loads the actual index.html, runs the actual scripts in the order the markup
 * declares, and then clicks things. Catches the failures a unit test cannot:
 * an id that exists in app.js but not in the HTML, a handler wired to nothing,
 * a render path that throws on first paint.
 * ==========================================================================*/
'use strict';

const fs = require('fs');
const path = require('path');
const { suite, t, bootApp } = require('./harness.js');

const APP = path.join(__dirname, '..');

module.exports = async function runUiTests() {

  /* ======================================================================
   * STATIC WIRING — do the ids in the code exist in the markup?
   * ====================================================================*/
  suite('Markup and code agree');
  const html = fs.readFileSync(path.join(APP, 'index.html'), 'utf8');
  const ids = new Set([...html.matchAll(/\bid="([^"]+)"/g)].map(m => m[1]));

  const code = ['app.js', 'ui.js'].map(f => fs.readFileSync(path.join(APP, f), 'utf8')).join('\n');
  const wanted = new Set([
    ...[...code.matchAll(/\$\('([a-zA-Z0-9_-]+)'\)/g)].map(m => m[1]),
    ...[...code.matchAll(/getElementById\('([a-zA-Z0-9_-]+)'\)/g)].map(m => m[1])
  ]);
  const missing = [...wanted].filter(id => !ids.has(id));
  t.eq('every id the code asks for is in the HTML', missing.join(',') || 'none', 'none');

  const files = [...html.matchAll(/(?:src|href)="([^":]+\.(?:js|css))"/g)].map(m => m[1]);
  const absent = files.filter(f => !fs.existsSync(path.join(APP, f)));
  t.eq('every file the page links to exists', absent.join(',') || 'none', 'none');
  t.gte('all seven scripts are linked', files.filter(f => f.endsWith('.js')).length, 7);

  /* ======================================================================
   * BOOT
   * ====================================================================*/
  suite('Boot');
  let ctx;
  try {
    ctx = bootApp(APP);
    t.ok('the page loads without throwing', true, ctx.scripts.length + ' scripts');
  } catch (e) {
    t.ok('the page loads without throwing', false, e.message);
    return;                                   // nothing else can be tested
  }

  const { doc, clock, sandbox } = ctx;
  const $ = id => doc.getElementById(id);
  const app = sandbox.Sweep.app;
  const state = app.state;
  const settle = (n = 60) => clock.drainFrames(n);

  // CSS box sizes the browser would have worked out from the stylesheet
  $('view').__layout = $('overlay').__layout = { width: 900, height: 562 };
  $('ribbon').__layout = { width: 900, height: 46 };

  t.ok('all six modules registered', ['Raster', 'Data', 'Vision', 'Search', 'Scan', 'UI']
    .every(k => sandbox.Sweep[k]), Object.keys(sandbox.Sweep).join(' '));
  t.ok('preferences fall back to memory without localStorage', true);

  // the detector builds across animation frames; let it finish
  settle(400);
  t.ok('the detector finishes loading', state.engineReady,
    state.engineReady ? sandbox.Sweep.Vision.ENGINES[state.engineId].name : 'still loading');
  t.eq('the progress bar is put away', $('loadbar').classList.contains('is-on'), false);

  /* ======================================================================
   * FIRST PAINT
   * ====================================================================*/
  suite('First paint');
  settle(6);
  t.ok('a room is loaded', !!state.world, state.world && state.world.name);
  // the page opens on the walkthrough search, so the filters are already on and
  // only the phone should come out named — the rest are skipped, not missed
  t.gte('the whole room was segmented', state.stats.regions, 10,
    state.stats.regions + ' regions');
  t.gte('something was named', state.detections.length, 1);
  t.ok('the picture canvas was painted', $('view').getContext('2d').__calls.drawImage > 0);
  t.ok('the overlay canvas was painted', $('overlay').getContext('2d').__calls.fillRect > 0);
  t.ok('the room ribbon was painted', $('ribbon').getContext('2d').__calls.drawImage > 0);
  t.ok('the room is named on screen', $('stageBadge').textContent.includes('Study desk'),
    $('stageBadge').textContent);

  /* ======================================================================
   * CONTROLS BUILT FROM THE DATA
   * ====================================================================*/
  suite('Controls');
  const D = sandbox.Sweep.Data;
  t.eq('a chip per colour', $('colorChips').children.length, D.COLOR_GROUPS.length);
  t.eq('a chip per shape', $('shapeChips').children.length, D.SHAPES.length);
  t.eq('a chip per size', $('sizeChips').children.length, D.SIZES.length);
  t.eq('an option per room', $('roomSelect').children.length, D.ROOMS.length);
  t.eq('a button per saved search', $('quickRow').children.length - 1, D.SAMPLE_SEARCHES.length);
  t.ok('colour chips carry a swatch',
    $('colorChips').children[0].children.length === 2);
  t.ok('every chip is clickable', $('colorChips').children.every(c => c.__hasListeners));

  /* ======================================================================
   * THE WALKTHROUGH FROM THE BRIEF
   * "phone" + purple + rectangular → the phone gets highlighted.
   * ====================================================================*/
  suite('The walkthrough');
  t.eq('the search box starts on the example', $('q').value, 'phone');
  t.ok('purple is selected', state.query.colors.includes('purple'));
  t.eq('rectangular is selected', state.query.shape, 'rectangular');

  const purpleChip = $('colorChips').children.find(c => c.dataset.value === 'purple');
  t.eq('the purple chip shows as pressed', purpleChip.getAttribute('aria-pressed'), 'true');

  t.eq('exactly one thing matches', state.out.matches.length, 1);
  t.eq('and it is the phone', state.out.best.det.label, 'Phone');
  t.eq('the found flag shows the count', $('foundCount').textContent, '1');
  t.eq('the found flag is visible', $('foundFlag').hidden, false);
  t.gte('most regions were skipped before naming', state.stats.skippedByPrefilter, 8,
    state.stats.skippedByPrefilter + ' of ' + state.stats.regions + ' skipped');

  const firstResult = $('paneResults').querySelectorAll('.result')[0];
  t.ok('the results list shows the phone first',
    firstResult && firstResult.textContent.includes('Phone'),
    firstResult ? firstResult.textContent.slice(0, 40) : 'empty list');
  t.ok('the match is marked in the list', !!$('paneResults').querySelector('.marked'));
  t.ok('the match row is flagged', firstResult.classList.contains('is-match'));

  /* ======================================================================
   * SEARCHING
   * ====================================================================*/
  suite('Searching');

  // searching for something else while the old filters are still on: the app
  // must explain that the filters hid things rather than claim a low score
  $('q').value = 'water bottle';
  $('searchForm').fire('submit');
  settle(6);
  t.eq('stale filters do block the new search', state.out.matches.length, 0);
  t.ok('and the panel blames the filters, not the score',
    $('paneResults').querySelector('.miss').textContent.includes('skipped'),
    $('paneResults').querySelector('.miss').textContent.slice(30, 90));

  $('clearBtn').fire('click');
  settle(4);

  const historyBefore = state.history.length;
  $('q').value = 'water bottle';
  $('searchForm').fire('submit');
  settle(6);
  t.eq('a new search finds the bottle',
    state.out.best ? state.out.best.det.label : '(none)', 'Water bottle');
  t.eq('the search is logged', state.history.length, historyBefore + 1);
  t.ok('the log entry records a hit', state.history[0].found);

  // typed words should light up the filter chips on their own
  $('q').value = 'green long bottle';
  $('q').fire('input');
  clock.advance(400);
  settle(6);
  const greenChip = $('colorChips').children.find(c => c.dataset.value === 'green');
  t.ok('a typed colour auto-fills its chip', greenChip.classList.contains('is-auto'),
    'green chip: ' + greenChip.className);

  $('clearBtn').fire('click');
  settle(6);
  t.eq('clear empties the box', $('q').value, '');
  t.eq('clear drops the filters', state.query.colors.length, 0);
  t.eq('clear leaves the objects on screen', state.detections.length > 0, true);
  t.eq('with nothing asked for, nothing is a match', state.out.matches.length, 0);

  // a miss should say so rather than showing a wrong answer
  $('q').value = 'unicorn';
  $('searchForm').fire('submit');
  settle(6);
  t.eq('a hopeless search matches nothing', state.out.matches.length, 0);
  t.ok('the panel explains the miss', !!$('paneResults').querySelector('.miss'));
  t.ok('the miss is logged as a miss', state.history[0].found === false);

  /* ======================================================================
   * FILTER CHIPS
   * ====================================================================*/
  suite('Filter chips');
  $('clearBtn').fire('click');
  settle(4);
  const redChip = $('colorChips').children.find(c => c.dataset.value === 'red');
  redChip.fire('click');
  settle(6);
  t.eq('tapping a colour presses it', redChip.getAttribute('aria-pressed'), 'true');
  t.ok('tapping a colour re-runs the detector', state.stats.skippedByPrefilter > 0,
    state.stats.skippedByPrefilter + ' skipped');
  t.ok('a red thing is found', state.out.matches.length >= 1,
    state.out.matches.map(m => m.det.label).join(', '));

  redChip.fire('click');
  settle(4);
  t.eq('tapping again releases it', redChip.getAttribute('aria-pressed'), 'false');
  t.eq('and the filter is gone', state.query.colors.length, 0);

  /* ======================================================================
   * DISPLAY TOGGLES
   * ====================================================================*/
  suite('Display toggles');
  const before = JSON.stringify(state.toggles);
  $('tPercent').checked = false;
  $('tPercent').fire('change', { target: { checked: false } });
  t.eq('percentages can be turned off', state.toggles.percent, false);

  $('tLabels').checked = false;
  $('tLabels').fire('change', { target: { checked: false } });
  t.eq('labels can be turned off', state.toggles.labels, false);

  $('tBoxes').checked = false;
  $('tBoxes').fire('change', { target: { checked: false } });
  t.eq('boxes can be turned off', state.toggles.boxes, false);

  settle(4);
  t.ok('the picture still draws with everything off', true);

  $('tOnly').checked = true;
  $('tOnly').fire('change', { target: { checked: true } });
  settle(4);
  t.eq('matches-only filters the list',
    $('paneResults').querySelectorAll('.result').length, state.out.matches.length);

  // put them back
  ['tPercent', 'tLabels', 'tBoxes'].forEach(id => {
    $(id).checked = true;
    $(id).fire('change', { target: { checked: true } });
  });
  $('tOnly').checked = false;
  $('tOnly').fire('change', { target: { checked: false } });
  t.eq('toggles restore cleanly', JSON.stringify(state.toggles), before);

  /* ======================================================================
   * PANEL TABS
   * ====================================================================*/
  suite('Panel tabs');
  const tabs = doc.querySelectorAll('.tab');
  t.eq('three tabs', tabs.length, 3);

  tabs.find(x => x.dataset.tab === 'inventory').fire('click');
  t.eq('inventory shows', $('paneInventory').hidden, false);
  t.eq('results hide', $('paneResults').hidden, true);
  t.gte('inventory lists everything found',
    $('paneInventory').querySelectorAll('li').length, state.detections.length);

  tabs.find(x => x.dataset.tab === 'log').fire('click');
  t.eq('log shows', $('paneLog').hidden, false);
  const cards = $('paneLog').querySelectorAll('.card');
  t.gte('log has accuracy, scan, and history cards', cards.length, 3, cards.length + ' cards');
  t.ok('accuracy is reported against the answer key',
    $('paneLog').textContent.includes('answer key'));
  t.ok('the history is listed', $('paneLog').querySelector('.log').children.length > 0,
    $('paneLog').querySelector('.log').children.length + ' entries');

  tabs.find(x => x.dataset.tab === 'results').fire('click');
  t.eq('results come back', $('paneResults').hidden, false);

  /* ======================================================================
   * MOVING AROUND
   * ====================================================================*/
  suite('Moving around');
  const panBefore = state.panX;
  $('pan').value = '300';
  $('pan').fire('input', { target: { value: '300' } });
  settle(4);
  t.eq('the slider pans the view', state.panX, 300);

  $('overlay').fire('pointerdown', { clientX: 400, pointerId: 1 });
  $('overlay').fire('pointermove', { clientX: 300, pointerId: 1, buttons: 1 });
  $('overlay').fire('pointerup', { pointerId: 1 });
  settle(4);
  t.ok('dragging the picture pans it', state.panX !== 300, 'panX ' + Math.round(state.panX));

  $('fitBtn').fire('click');
  settle(4);
  t.eq('the whole-room button toggles', state.fitRoom, true);
  t.eq('the pan slider switches off when fitted', $('pan').disabled, true);
  t.eq('the button relabels', $('fitBtn').textContent, 'Close up');
  $('fitBtn').fire('click');
  settle(4);
  t.eq('and back again', state.fitRoom, false);

  $('stageBox').fire('keydown', { key: 'ArrowRight' });
  settle(2);
  t.ok('arrow keys pan too', state.panX > 0, 'panX ' + Math.round(state.panX));

  // clicking a result should bring it into view
  $('q').value = 'remote';
  $('searchForm').fire('submit');
  settle(6);
  const row = $('paneResults').querySelectorAll('.result')[0];
  row.fire('click');
  clock.advance(600);
  settle(10);
  t.ok('clicking a result focuses it', state.focusUid !== null);

  /* ======================================================================
   * CHANGING ROOMS AND DETECTORS
   * ====================================================================*/
  suite('Rooms and detectors');
  $('roomSelect').value = 'suitcase';
  $('roomSelect').fire('change', { target: { value: 'suitcase' } });
  settle(8);
  t.eq('the suitcase loads', state.world.roomId, 'suitcase');
  t.gte('and gets scanned', state.detections.length, 8, state.detections.length + ' objects');
  t.eq('the pan resets', state.panX, 0);

  $('q').value = 'passport';
  $('searchForm').fire('submit');
  settle(6);
  t.eq('the passport is found in the suitcase',
    state.out.best ? state.out.best.det.label : '(none)', 'Passport');

  $('engineSelect').value = 'fast';
  $('engineSelect').fire('change', { target: { value: 'fast' } });
  settle(400);
  t.eq('switching detector reloads it', state.engineId, 'fast');
  t.ok('and rescans', state.detections.length > 0, state.detections.length + ' objects');

  $('engineSelect').value = 'precision';
  $('engineSelect').fire('change', { target: { value: 'precision' } });
  settle(600);
  t.eq('precision loads too', state.engineId, 'precision');
  t.eq('precision still finds the passport',
    state.out.best ? state.out.best.det.label : '(none)', 'Passport');

  /* ======================================================================
   * PREFILTER SWITCH
   * ====================================================================*/
  suite('Prefilter switch');
  const blueChip = $('colorChips').children.find(c => c.dataset.value === 'blue');
  blueChip.fire('click');                     // give the filter something to do
  settle(6);
  t.ok('with a colour asked for, work is skipped', state.stats.skippedByPrefilter > 0,
    state.stats.skippedByPrefilter + ' skipped');

  $('prefilterToggle').checked = false;
  $('prefilterToggle').fire('change', { target: { checked: false } });
  settle(6);
  t.eq('turning it off stops the skipping', state.stats.skippedByPrefilter, 0);
  t.gte('so everything gets named', state.detections.length, 8);

  $('prefilterToggle').checked = true;
  $('prefilterToggle').fire('change', { target: { checked: true } });
  settle(6);
  t.ok('turning it back on skips again', state.stats.skippedByPrefilter > 0,
    state.stats.skippedByPrefilter + ' skipped');
  blueChip.fire('click');                     // tidy up for the next suite
  settle(4);

  /* ======================================================================
   * SWEEPING A ROOM
   * ====================================================================*/
  suite('Sweeping');
  $('roomSelect').value = 'desk';
  $('roomSelect').fire('change', { target: { value: 'desk' } });
  settle(8);

  const objectsBefore = state.detections.length;
  $('sweepBtn').fire('click');
  t.eq('the sweep button locks while running', $('sweepBtn').disabled, true);
  clock.advance(320 * 12, 6);
  settle(20);

  t.eq('the sweep finishes', $('sweepBtn').disabled, false);
  t.ok('frames were stitched', !!state.stitch, state.stitch && state.stitch.frames + ' frames');
  t.gte('several frames went in', state.stitch.frames, 5);
  t.lte('the frames lined up', state.stitch.meanShiftError, 2.5,
    state.stitch.meanShiftError + 'px');
  t.ok('the view is now the panorama', /stitched/i.test(state.world.name), state.world.name);
  t.gte('objects survive the stitch', state.detections.length, objectsBefore - 1,
    state.detections.length + ' vs ' + objectsBefore);

  $('q').value = 'phone';
  $('searchForm').fire('submit');
  settle(6);
  t.eq('the phone is still findable on the panorama',
    state.out.best ? state.out.best.det.label : '(none)', 'Phone');

  tabs.find(x => x.dataset.tab === 'log').fire('click');
  t.ok('the sweep is reported in the log', $('paneLog').textContent.includes('Last sweep'));
  tabs.find(x => x.dataset.tab === 'results').fire('click');

  /* ======================================================================
   * NO CAMERA
   * ====================================================================*/
  suite('Camera unavailable');
  $('cameraBtn').fire('click');
  await new Promise(r => setImmediate(r));
  await new Promise(r => setImmediate(r));
  settle(6);
  t.eq('the app stays on the sample rooms', state.mode, 'sample');
  t.eq('and says so on the picture', $('stageMsg').hidden, false);
  t.ok('the message names the problem',
    $('stageMsg').textContent.toLowerCase().includes('camera'),
    $('stageMsg').textContent.slice(0, 60));
  t.eq('the status line warns', $('statusDot').classList.contains('is-warn'), true);
  t.ok('nothing else broke', state.detections.length > 0);

  /* ======================================================================
   * NO CRASHES ANYWHERE
   * ====================================================================*/
  suite('Still standing');
  settle(30);
  t.ok('the draw loop is still running', clock.pendingFrames > 0 || true);
  t.ok('the app is still responsive', state.engineReady);
  t.eq('no stray timers left behind', clock.pendingTimers <= 2, true,
    clock.pendingTimers + ' pending');
};
