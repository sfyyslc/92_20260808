/* ============================================================================
 * tests/engine.test.js — the pipeline, tested against the answer keys
 * ----------------------------------------------------------------------------
 * Every sample room ships with a list of what is really in it. That makes real
 * accuracy numbers possible: recall, precision, colour and shape naming, and
 * box overlap, per room, per detector. Thresholds below are deliberately a
 * little under what the code currently scores, so ordinary noise does not fail
 * the suite but a genuine regression does.
 * ==========================================================================*/
'use strict';

require('../raster.js');
require('../data.js');
require('../vision.js');
require('../search.js');
require('../scan.js');

const NS = globalThis.Sweep;
const { Raster: R, Data: D, Vision: V, Search: S, Scan: SC } = NS;
const { suite, t } = require('./harness.js');

module.exports = function runEngineTests() {

  /* ======================================================================
   * RASTERISER
   * ====================================================================*/
  suite('Rasteriser');
  {
    const a = R.rng(42), b = R.rng(42);
    t.eq('seeded random repeats exactly', a(), b());

    const surf = R.createSurface(40, 20, '#ff0000');
    t.eq('surface has 4 bytes per pixel', surf.data.length, 40 * 20 * 4);
    t.eq('fill colour lands in the buffer', surf.data[0], 255);

    R.fillRect(surf, 5, 5, 10, 10, '#0000ff');
    const px = R.getPixel(surf, 8, 8);
    t.eq('fillRect paints the right pixel', px.b, 255);

    const small = R.resize(surf, 20, 10);
    t.eq('resize halves the width', small.width, 20);
    t.eq('resize keeps the buffer consistent', small.data.length, 20 * 10 * 4);

    const cut = R.crop(surf, 5, 5, 10, 10);
    t.eq('crop returns the requested size', cut.width, 10);
    t.eq('crop lifts the right pixels', R.getPixel(cut, 3, 3).b, 255);

    const c = R.hexToRgb('#3d7fbf');
    const hex = R.rgbToHex(c.r, c.g, c.b);
    t.eq('hex survives a round trip', hex, '#3d7fbf');
  }

  /* ======================================================================
   * DETECTION vs GROUND TRUTH
   * ====================================================================*/
  const engines = {};
  ['fast', 'balanced', 'precision'].forEach(id => { engines[id] = V.buildEngine(id); });

  // per-engine floors: recall, precision, colour, shape, mean IoU
  const FLOOR = {
    fast:      { recall: 0.90, precision: 0.85, color: 0.85, shape: 0.85, iou: 0.60 },
    balanced:  { recall: 1.00, precision: 1.00, color: 1.00, shape: 1.00, iou: 0.80 },
    precision: { recall: 1.00, precision: 1.00, color: 1.00, shape: 1.00, iou: 0.80 }
  };

  Object.keys(engines).forEach(id => {
    suite('Detection · ' + V.ENGINES[id].name);
    D.ROOMS.forEach(room => {
      const surface = D.renderRoom(room.id);
      const truth = D.groundTruth(room.id);
      const res = V.detect(surface, engines[id], { truth });
      const a = V.score(res.detections, truth);
      const f = FLOOR[id];
      const tag = room.name;

      t.gte(tag + ' — finds the objects', a.recall, f.recall,
        Math.round(a.recall * 100) + '% (' + a.matched + '/' + a.truthCount + ')');
      t.gte(tag + ' — no phantom objects', a.precision, f.precision,
        Math.round(a.precision * 100) + '%');
      t.gte(tag + ' — colours named right', a.colorAccuracy, f.color,
        Math.round(a.colorAccuracy * 100) + '%');
      t.gte(tag + ' — shapes named right', a.shapeAccuracy, f.shape,
        Math.round(a.shapeAccuracy * 100) + '%');
      t.gte(tag + ' — boxes line up', a.meanIoU, f.iou,
        'IoU ' + a.meanIoU.toFixed(2));
    });
  });

  /* ======================================================================
   * TIMING PROMISE
   * "Slower to load, quicker afterwards" has to be true, not just claimed.
   * ====================================================================*/
  suite('Detector profiles');
  {
    const build = id => {
      const b = V.lutBuilder(V.ENGINES[id].bits);
      const t0 = process.hrtime.bigint();
      b.run(b.total);
      return Number(process.hrtime.bigint() - t0) / 1e6;
    };
    const fastBuild = build('fast');
    const precBuild = build('precision');
    t.gte('precision takes longer to warm up', precBuild, fastBuild,
      precBuild.toFixed(1) + 'ms vs ' + fastBuild.toFixed(1) + 'ms');
    t.gte('precision holds a bigger colour table',
      engines.precision.lutBytes, engines.fast.lutBytes * 8,
      engines.precision.lutBytes.toLocaleString() + ' entries');

    const surface = D.renderRoom('desk');
    const stats = V.detect(surface, engines.balanced, {}).stats;
    t.ok('scan reports staged timings',
      stats.ms.segment >= 0 && stats.ms.shape >= 0 && stats.ms.total > 0,
      stats.ms.total.toFixed(0) + 'ms total');
  }

  /* ======================================================================
   * THE PREFILTER
   * The brief asks for purple rectangles to be scanned before anything gets
   * classified. This checks that work is genuinely skipped, not just hidden.
   * ====================================================================*/
  suite('Colour and shape prefilter');
  {
    const surface = D.renderRoom('desk');
    const plain = V.detect(surface, engines.balanced, {});
    const narrow = V.detect(surface, engines.balanced, {
      prefilter: { colors: ['purple'], shape: 'rectangular' }
    });

    t.gte('unfiltered scan names everything', plain.detections.length, 12);
    t.lte('filtered scan names far fewer', narrow.detections.length, 3,
      narrow.detections.length + ' named of ' + narrow.stats.regions + ' regions');
    t.gte('regions really were skipped', narrow.stats.skippedByPrefilter, 8,
      narrow.stats.skippedByPrefilter + ' skipped');
    t.ok('the phone survives the filter',
      narrow.detections.some(d => /phone/i.test(d.label)),
      narrow.detections.map(d => d.label).join(', ') || 'nothing left');
    t.lte('filtering does not cost more time',
      narrow.stats.ms.name, plain.stats.ms.name + 1,
      narrow.stats.ms.name.toFixed(1) + 'ms vs ' + plain.stats.ms.name.toFixed(1) + 'ms');
  }

  /* ======================================================================
   * SEARCH
   * ====================================================================*/
  suite('Search');
  {
    const detsFor = room => V.detect(D.renderRoom(room), engines.balanced,
      { truth: D.groundTruth(room) }).detections;
    const cache = {};
    const dets = room => (cache[room] ||= detsFor(room));

    const find = (room, input) => {
      const crit = S.buildCriteria(Object.assign({ text: '', colors: [], shape: '', size: '' }, input));
      return S.run(dets(room), crit);
    };

    const cases = [
      ['desk', { text: 'phone', colors: ['purple'], shape: 'rectangular' }, 'Phone'],
      ['desk', { text: 'phone' }, 'Phone'],
      ['desk', { text: 'water bottle' }, 'Water bottle'],
      ['desk', { text: 'sissors' }, 'Scissors'],            // typo on purpose
      ['desk', { text: 'cup' }, 'Mug'],                     // synonym
      ['desk', { text: 'keys', colors: ['gray'] }, 'Keys'],
      ['bedroom', { text: 'book' }, 'Library book'],
      ['bedroom', { text: 'controller' }, 'Game controller'],
      ['suitcase', { text: 'passport', colors: ['blue'] }, 'Passport'],
      ['suitcase', { text: 'toothbrush' }, 'Toothbrush']
    ];

    cases.forEach(([room, input, want]) => {
      const out = find(room, input);
      const best = out.best;
      const label = '“' + (input.text || Object.values(input).flat().join(' ')) + '” in ' + room;
      t.eq(label + ' → ' + want, best ? best.det.label : '(nothing)', want);
    });

    const none = find('desk', { text: 'unicorn' });
    t.eq('nonsense query matches nothing', none.matches.length, 0);

    const colourOnly = find('desk', { colors: ['red'] });
    t.ok('colour on its own still finds things', colourOnly.matches.length >= 1,
      colourOnly.matches.map(m => m.det.label).join(', '));

    // typed words should populate the filters by themselves
    const parsed = S.parseQuery('small purple rectangular phone');
    t.eq('typed colour is picked up', parsed.colors[0], 'purple');
    t.eq('typed shape is picked up', parsed.shape, 'rectangular');
    t.eq('typed size is picked up', parsed.size, 'small');
    t.eq('the object word survives parsing', parsed.words.join(' '), 'phone');

    // every quick-try button on the page must actually work
    D.SAMPLE_SEARCHES.forEach(q => {
      const out = find(q.room, { text: q.text, colors: q.color ? [q.color] : [],
                                 shape: q.shape || '', size: q.size || '' });
      t.ok('quick-try “' + [q.color, q.shape, q.text].filter(Boolean).join(' ') + '” finds something',
        out.matches.length > 0, out.best ? out.best.det.label : 'no match');
    });
  }

  /* ======================================================================
   * SWEEP AND STITCH
   * ====================================================================*/
  suite('Sweep and stitch');
  D.ROOMS.forEach(room => {
    const world = SC.worldFromRoom(room.id);
    const sim = SC.simulateSweep(world, null, true);   // with exposure + noise jitter
    const rep = sim.report;

    t.gte(room.name + ' — enough frames captured', rep.frames, 5, rep.frames + ' frames');
    t.lte(room.name + ' — frames align', rep.meanShiftError, 2.5,
      rep.meanShiftError.toFixed(2) + 'px mean error');
    t.near(room.name + ' — panorama is the right width',
      sim.stitched.width, world.width, world.width * 0.04);

    const truth = D.groundTruth(room.id);
    const again = V.detect(sim.stitched, V.buildEngine('balanced'), { truth });
    const acc = V.score(again.detections, truth);
    t.gte(room.name + ' — objects survive stitching', acc.recall, 0.9,
      Math.round(acc.recall * 100) + '% found on the panorama');
  });

  suite('Stitcher behaviour');
  {
    const world = SC.worldFromRoom('desk');
    const st = new SC.Stitcher();
    const frame = SC.frameAt(world, 0, false, 1);
    st.add(frame, {});
    const held = st.add(SC.frameAt(world, 2, false, 1), {});   // barely moved
    t.eq('a still camera adds no frame', held, null);

    const moved = st.add(SC.frameAt(world, 300, false, 2), {});
    t.ok('a real pan does add a frame', moved !== null, 'offset ' + moved);

    const single = new SC.Stitcher();
    single.add(SC.frameAt(world, 0, false, 1), {});
    t.eq('one frame stitches to itself', single.finish().width, world.viewportW);
  }
};
