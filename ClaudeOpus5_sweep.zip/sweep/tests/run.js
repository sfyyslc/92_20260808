/* ============================================================================
 * tests/run.js — run everything
 *
 *   node tests/run.js
 *
 * Exits 0 when every check passes, 1 otherwise, so it can sit in a CI step.
 * No packages to install; Node 18 or newer is all it needs.
 * ==========================================================================*/
'use strict';

const { report } = require('./harness.js');

(async () => {
  console.log('\n\x1b[1m\x1b[33m  Sweep — test run\x1b[0m');
  console.log('  ' + new Date().toISOString());

  try {
    require('./engine.test.js')();
    await require('./ui.test.js')();
  } catch (err) {
    console.error('\n\x1b[31m  The suite crashed:\x1b[0m ' + err.stack + '\n');
    process.exit(1);
  }

  process.exit(report() ? 0 : 1);
})();
