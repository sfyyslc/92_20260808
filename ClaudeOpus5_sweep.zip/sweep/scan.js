/* ============================================================================
 * Sweep — scan.js
 * ----------------------------------------------------------------------------
 * Getting a room into the app. Three ways in:
 *
 *   SAMPLE     a prebuilt room. The whole room is already one wide image, so
 *              "sweeping" is just moving a viewport across it.
 *   SWEEP      pan the camera across a space. Frames are captured, the shift
 *              between them is measured, and they are stitched into one wide
 *              picture that gets scanned in a single pass. One search then
 *              covers the whole room instead of whatever fits in the lens.
 *   LIVE       keep detecting on the current camera frame.
 *
 * The stitcher is the interesting part. It compares the brightness profile of
 * each column between consecutive frames and picks the horizontal shift that
 * lines them up best. No feature descriptors, no matrix maths — a phone panning
 * across a desk moves almost purely sideways, and for that case this is enough.
 * Because sample sweeps have a known true shift, the app can report its own
 * stitching error instead of asking you to take its word for it.
 * ==========================================================================*/
(function (global) {
  'use strict';

  var NS = global.Sweep || (global.Sweep = {});
  var R = NS.Raster || (typeof require === 'function' ? require('./raster.js') : null);
  var D = NS.Data || (typeof require === 'function' ? require('./data.js') : null);

  /* ==========================================================================
   * WORLDS
   * A "world" is whatever is currently being searched, plus the viewport that
   * is on screen. Sample rooms and stitched panoramas are interchangeable here.
   * ========================================================================*/

  function worldFromRoom(roomId) {
    var room = D.ROOMS_BY_ID[roomId];
    var surface = D.renderRoom(roomId);
    return {
      source: 'sample',
      roomId: roomId,
      name: room.name,
      blurb: room.blurb,
      surface: surface,
      width: surface.width,
      height: surface.height,
      viewportW: Math.round(surface.width * room.viewportFrac),
      truth: D.groundTruth(roomId)
    };
  }

  function worldFromSurface(surface, name, extra) {
    var w = {
      source: 'panorama', roomId: null, name: name || 'Stitched sweep', blurb: '',
      surface: surface, width: surface.width, height: surface.height,
      viewportW: Math.min(surface.width, Math.round(surface.height * 1.35)),
      truth: null
    };
    if (extra) for (var k in extra) w[k] = extra[k];
    return w;
  }

  /* ==========================================================================
   * FRAME MATCHING
   * ========================================================================*/

  /** Mean luminance of every column — a one-line summary of a frame. */
  function columnProfile(img) {
    var W = img.width, H = img.height, d = img.data;
    var prof = new Float32Array(W);
    for (var x = 0; x < W; x++) {
      var sum = 0;
      for (var y = 0; y < H; y++) {
        var i = (y * W + x) * 4;
        sum += 0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2];
      }
      prof[x] = sum / H;
    }
    return prof;
  }

  /**
   * Edges, not brightness. Differentiating the column profile throws away the
   * overall light level, so a camera that re-exposes mid-pan still matches.
   */
  function gradientProfile(prof) {
    var g = new Float32Array(prof.length - 1);
    for (var x = 0; x < g.length; x++) g[x] = prof[x + 1] - prof[x];
    return g;
  }

  /**
   * Best horizontal shift taking frame A to frame B.
   * Positive shift = the camera moved right.
   *
   * Scored with normalised cross-correlation, which is scale- and
   * offset-invariant — the whole point, since consecutive camera frames rarely
   * agree on exposure. Confidence compares the winning peak to the next best
   * one that is not adjacent to it: on a repeating texture like a quilted
   * suitcase lining several shifts fit almost equally well, and the honest
   * answer there is "not sure", not a confident wrong number.
   *
   * @returns { shift, confidence, ncc }
   */
  function estimateShift(profA, profB, maxShift) {
    var gA = gradientProfile(profA), gB = gradientProfile(profB);
    var W = Math.min(gA.length, gB.length);
    maxShift = Math.min(maxShift || Math.floor(W * 0.7), W - 16);
    // Zero is a legitimate answer: it is how a camera being held still looks,
    // and the stitcher needs to see it to drop the duplicate frame.
    var minShift = 0;
    var scores = new Float32Array(maxShift + 1);
    var bestShift = minShift, bestScore = -Infinity;

    for (var s = minShift; s <= maxShift; s++) {
      var n = W - s;
      if (n < 24) break;
      var sa = 0, sb = 0, saa = 0, sbb = 0, sab = 0;
      for (var x = 0; x < n; x++) {
        var a = gA[x + s], b = gB[x];
        sa += a; sb += b; saa += a * a; sbb += b * b; sab += a * b;
      }
      var num = n * sab - sa * sb;
      var den = Math.sqrt(Math.max(1e-6, (n * saa - sa * sa) * (n * sbb - sb * sb)));
      var ncc = num / den;
      scores[s] = ncc;
      if (ncc > bestScore) { bestScore = ncc; bestShift = s; }
    }

    // second-best peak, ignoring the neighbourhood of the winner
    var second = -Infinity;
    for (var t = minShift; t <= maxShift; t++) {
      if (Math.abs(t - bestShift) < Math.max(6, W * 0.03)) continue;
      if (scores[t] > second) second = scores[t];
    }
    var margin = second === -Infinity ? 1 : Math.max(0, bestScore - second);
    var confidence = Math.max(0, Math.min(1, bestScore)) * Math.min(1, 0.35 + margin * 1.8);

    return { shift: bestShift, confidence: confidence, ncc: bestScore };
  }

  /* ==========================================================================
   * STITCHER
   * ========================================================================*/

  function Stitcher(maxWidth) {
    this.frames = [];        // { surface, offset, shift, confidence }
    this.offset = 0;
    this.prevProfile = null;
    this.recentShifts = [];
    this.maxWidth = maxWidth || 4200;
  }

  /**
   * Add a frame. Returns the offset it was placed at, or null if it was
   * dropped for overlapping the previous frame almost exactly (camera held
   * still — no new information).
   */
  Stitcher.prototype.add = function (surface, opts) {
    opts = opts || {};
    var prof = columnProfile(surface);
    var shift = 0, conf = 1, fellBack = false;
    if (this.prevProfile) {
      var est = estimateShift(this.prevProfile, prof, Math.floor(surface.width * 0.7));
      shift = est.shift; conf = est.confidence;
      if (conf < 0.45 && this.recentShifts.length) {
        var med = this.recentShifts.slice().sort(function (a, b) { return a - b; })[
          Math.floor(this.recentShifts.length / 2)];
        // only override when the estimate disagrees wildly with the pan so far
        if (Math.abs(shift - med) > surface.width * 0.12) { shift = med; fellBack = true; }
      }
      if (shift < surface.width * 0.04 && !opts.force) return null;   // held still
      this.offset += shift;
      this.recentShifts.push(shift);
      if (this.recentShifts.length > 5) this.recentShifts.shift();
    }
    this.prevProfile = prof;
    this.frames.push({
      surface: surface, offset: this.offset, shift: shift,
      confidence: conf, fellBack: fellBack, trueShift: opts.trueShift
    });
    return this.offset;
  };

  /** Composite every added frame into one wide surface. */
  Stitcher.prototype.finish = function () {
    if (!this.frames.length) return null;
    var h = this.frames[0].surface.height;
    var last = this.frames[this.frames.length - 1];
    var w = Math.min(this.maxWidth, last.offset + last.surface.width);
    var out = R.createSurface(w, h, '#000000');

    this.frames.forEach(function (f, idx) {
      var sw = f.surface.width;
      // feather the left edge of every frame after the first so seams from a
      // slightly-off shift estimate do not show up as hard vertical lines
      var feather = idx === 0 ? 0 : Math.min(24, Math.round(f.shift * 0.5));
      for (var y = 0; y < h; y++) {
        for (var x = 0; x < sw; x++) {
          var dx = f.offset + x;
          if (dx < 0 || dx >= w) continue;
          var si = (y * sw + x) * 4, di = (y * w + dx) * 4;
          var a = feather && x < feather ? x / feather : 1;
          if (a >= 1) {
            out.data[di] = f.surface.data[si];
            out.data[di + 1] = f.surface.data[si + 1];
            out.data[di + 2] = f.surface.data[si + 2];
          } else {
            out.data[di] += (f.surface.data[si] - out.data[di]) * a;
            out.data[di + 1] += (f.surface.data[si + 1] - out.data[di + 1]) * a;
            out.data[di + 2] += (f.surface.data[si + 2] - out.data[di + 2]) * a;
          }
          out.data[di + 3] = 255;
        }
      }
    });
    return out;
  };

  /** How well the stitch went — reported honestly in the Log tab. */
  Stitcher.prototype.report = function () {
    var errs = [], confs = [], fallbacks = 0;
    this.frames.forEach(function (f) {
      confs.push(f.confidence);
      if (f.fellBack) fallbacks++;
      if (typeof f.trueShift === 'number') errs.push(Math.abs(f.shift - f.trueShift));
    });
    var mean = function (a) { return a.length ? a.reduce(function (x, y) { return x + y; }, 0) / a.length : 0; };
    return {
      frames: this.frames.length,
      width: this.frames.length ? this.frames[this.frames.length - 1].offset +
             this.frames[0].surface.width : 0,
      meanConfidence: mean(confs),
      fallbacks: fallbacks,
      meanShiftError: errs.length ? mean(errs) : null,
      maxShiftError: errs.length ? Math.max.apply(null, errs) : null
    };
  };

  /* ==========================================================================
   * SIMULATED SWEEP
   * Pans a viewport across a sample room to produce frames, exactly as a phone
   * would. Used to demonstrate (and measure) the stitcher without a camera.
   * ========================================================================*/

  function sweepPlan(world, frameCount) {
    var vw = world.viewportW;
    var travel = Math.max(0, world.width - vw);
    var n = frameCount || Math.max(6, Math.round(travel / (vw * 0.25)) + 1);
    var plan = [];
    for (var i = 0; i < n; i++) {
      plan.push(Math.round(travel * (n === 1 ? 0 : i / (n - 1))));
    }
    return { positions: plan, viewportW: vw };
  }

  /**
   * Crop one sweep frame out of a world.
   * `jitter` mimics what a real camera does while you pan: auto-exposure
   * hunting and sensor noise. Without it the stitcher would be matching
   * identical pixels, which proves nothing.
   */
  function frameAt(world, x, jitter, seed) {
    var f = R.crop(world.surface, x, 0, world.viewportW, world.height);
    if (jitter) {
      var rand = R.rng((seed || 1) * 7919);
      var exposure = 1 + (rand() - 0.5) * 0.16;
      for (var i = 0; i < f.data.length; i += 4) {
        f.data[i] *= exposure; f.data[i + 1] *= exposure; f.data[i + 2] *= exposure;
      }
      R.grain(f, 6, (seed || 1) * 31);
    }
    return f;
  }

  /**
   * Run the whole simulated sweep and stitch it back together.
   * Returns the stitched surface plus a report — a genuine round trip:
   * cut the room into frames, forget where they came from, put it back.
   */
  function simulateSweep(world, frameCount, jitter) {
    var plan = sweepPlan(world, frameCount);
    var st = new Stitcher();
    plan.positions.forEach(function (x, i) {
      var prev = i > 0 ? plan.positions[i - 1] : x;
      st.add(frameAt(world, x, jitter !== false, i + 1), { trueShift: x - prev, force: true });
    });
    return { stitched: st.finish(), report: st.report(), plan: plan, stitcher: st };
  }

  /* ==========================================================================
   * CAMERA (browser only)
   * ========================================================================*/

  function Camera() {
    this.stream = null;
    this.video = null;
    this.canvas = null;
    this.ctx = null;
  }

  Camera.prototype.available = function () {
    return typeof navigator !== 'undefined' &&
           !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia);
  };

  /** @returns Promise<HTMLVideoElement> */
  Camera.prototype.start = function (videoEl, facing) {
    var self = this;
    if (!this.available()) {
      return Promise.reject(new Error('This browser has no camera access.'));
    }
    return navigator.mediaDevices.getUserMedia({
      video: { facingMode: facing || 'environment', width: { ideal: 1280 }, height: { ideal: 720 } },
      audio: false
    }).then(function (stream) {
      self.stream = stream;
      self.video = videoEl;
      videoEl.srcObject = stream;
      return videoEl.play().then(function () { return videoEl; });
    });
  };

  Camera.prototype.stop = function () {
    if (this.stream) {
      this.stream.getTracks().forEach(function (t) { t.stop(); });
      this.stream = null;
    }
    if (this.video) { this.video.srcObject = null; this.video = null; }
  };

  /** Grab the current frame as an ImageData at a chosen width. */
  Camera.prototype.grab = function (width) {
    if (!this.video || !this.video.videoWidth) return null;
    var w = width || 640;
    var h = Math.round(this.video.videoHeight * (w / this.video.videoWidth));
    if (!this.canvas) {
      this.canvas = document.createElement('canvas');
      this.ctx = this.canvas.getContext('2d', { willReadFrequently: true });
    }
    if (this.canvas.width !== w || this.canvas.height !== h) {
      this.canvas.width = w; this.canvas.height = h;
    }
    this.ctx.drawImage(this.video, 0, 0, w, h);
    return this.ctx.getImageData(0, 0, w, h);
  };

  NS.Scan = {
    worldFromRoom: worldFromRoom,
    worldFromSurface: worldFromSurface,
    columnProfile: columnProfile,
    gradientProfile: gradientProfile,
    estimateShift: estimateShift,
    Stitcher: Stitcher,
    sweepPlan: sweepPlan,
    frameAt: frameAt,
    simulateSweep: simulateSweep,
    Camera: Camera
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = NS.Scan;
})(typeof globalThis !== 'undefined' ? globalThis : this);
