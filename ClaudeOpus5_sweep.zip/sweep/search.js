/* ============================================================================
 * Sweep — search.js
 * ----------------------------------------------------------------------------
 * Turns "purple rectangular phone" into a score for every detected object.
 *
 * Two things worth knowing:
 *
 *  1. Colour and shape words typed into the search box are pulled out and used
 *     as filters, then echoed back into the filter chips. Typing and tapping
 *     produce exactly the same query, so nobody has to learn which is "right".
 *
 *  2. A criterion only counts if you supplied it. Searching "phone" with no
 *     colour set does not quietly punish every object for not being purple —
 *     the weights are renormalised over the criteria you actually gave.
 * ==========================================================================*/
(function (global) {
  'use strict';

  var NS = global.Sweep || (global.Sweep = {});
  var D = NS.Data || (typeof require === 'function' ? require('./data.js') : null);
  var V = NS.Vision || (typeof require === 'function' ? require('./vision.js') : null);
  var R = NS.Raster || (typeof require === 'function' ? require('./raster.js') : null);

  /* Words that mean a shape, including the ones people actually type. */
  var SHAPE_WORDS = {
    rectangular: 'rectangular', rectangle: 'rectangular', rect: 'rectangular',
    oblong: 'rectangular', flat: 'rectangular',
    square: 'square', boxy: 'square', cube: 'square',
    round: 'round', circular: 'round', circle: 'round', ball: 'round', disc: 'round',
    oval: 'oval', elliptical: 'oval', egg: 'oval',
    long: 'long', thin: 'long', skinny: 'long', narrow: 'long', stick: 'long',
    cylindrical: 'long', tube: 'long',
    triangular: 'triangular', triangle: 'triangular', wedge: 'triangular',
    irregular: 'irregular', lumpy: 'irregular', messy: 'irregular',
    bunched: 'irregular', tangled: 'irregular', crumpled: 'irregular'
  };

  var SIZE_WORDS = {
    small: 'small', tiny: 'small', little: 'small', mini: 'small',
    medium: 'medium', 'mid-sized': 'medium', midsize: 'medium', normal: 'medium',
    large: 'large', big: 'large', huge: 'large', giant: 'large', bulky: 'large'
  };

  /* Noise words to drop before name matching. */
  var STOP = { my: 1, the: 1, a: 1, an: 1, of: 1, and: 1, is: 1, in: 1, on: 1,
               find: 1, where: 1, wheres: 1, locate: 1, look: 1, for: 1, to: 1, it: 1 };

  function tokenize(text) {
    return String(text || '').toLowerCase()
      .replace(/[^a-z0-9\s'-]/g, ' ')
      .split(/\s+/)
      .filter(Boolean);
  }

  /**
   * Pull colour / shape / size words out of free text.
   * @returns { colors:[groupId], shape, size, words:[remaining], picked:{} }
   */
  function parseQuery(text) {
    var out = { colors: [], shape: '', size: '', words: [], picked: {} };
    tokenize(text).forEach(function (w) {
      var stem = w.replace(/'s$/, '');
      if (D.COLOR_WORDS[stem]) {
        var g = D.COLOR_WORDS[stem];
        if (out.colors.indexOf(g) === -1) out.colors.push(g);
        out.picked[w] = 'color';
        return;
      }
      if (SHAPE_WORDS[stem]) { out.shape = out.shape || SHAPE_WORDS[stem]; out.picked[w] = 'shape'; return; }
      if (SIZE_WORDS[stem]) { out.size = out.size || SIZE_WORDS[stem]; out.picked[w] = 'size'; return; }
      if (STOP[stem]) return;
      out.words.push(stem);
    });
    return out;
  }

  /**
   * Merge what was typed with what was tapped. Chips win where they disagree,
   * because a chip is a deliberate act and a stray adjective might not be.
   */
  function buildCriteria(input) {
    var parsed = parseQuery(input.text || '');
    var colors = (input.colors && input.colors.length) ? input.colors.slice() : parsed.colors.slice();
    return {
      words: parsed.words,
      rawText: input.text || '',
      colors: colors,
      shape: input.shape || parsed.shape || '',
      size: input.size || parsed.size || '',
      parsed: parsed,
      active: function () {
        return (this.words.length ? 1 : 0) + (this.colors.length ? 1 : 0) +
               (this.shape ? 1 : 0) + (this.size ? 1 : 0);
      }
    };
  }

  /* -- fuzzy word matching -------------------------------------------------
   * Small edit distance with an early bail-out; people mistype "recieve" and
   * they mistype "sissors". */
  function editDistance(a, b, max) {
    if (a === b) return 0;
    if (Math.abs(a.length - b.length) > max) return max + 1;
    var prev = new Array(b.length + 1), cur = new Array(b.length + 1), i, j;
    for (j = 0; j <= b.length; j++) prev[j] = j;
    for (i = 1; i <= a.length; i++) {
      cur[0] = i;
      var best = cur[0];
      for (j = 1; j <= b.length; j++) {
        cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
        if (cur[j] < best) best = cur[j];
      }
      if (best > max) return max + 1;
      for (j = 0; j <= b.length; j++) prev[j] = cur[j];
    }
    return prev[b.length];
  }

  /** How well one query word matches one candidate word. */
  function wordScore(q, cand) {
    if (q === cand) return 1;
    if (cand.indexOf(q) === 0) return 0.9;            // "phon" → "phone"
    if (q.length >= 4 && cand.indexOf(q) !== -1) return 0.75;
    var tol = q.length >= 6 ? 2 : q.length >= 4 ? 1 : 0;
    if (tol) {
      var d = editDistance(q, cand, tol);
      if (d <= tol) return 0.82 - 0.12 * d;
    }
    return 0;
  }

  /* How much a hit is worth depending on where the word came from. "Controller"
   * is a listed nickname for a TV remote *and* half the real name of a game
   * controller; without these tiers the two tie and the wrong one can win. */
  var TIER = { name: 1, syn: 0.92, cat: 0.72 };

  /** Every word this detection could reasonably answer to, with its tier. */
  function vocabularyFor(det) {
    var words = [];
    var push = function (str, tier) {
      tokenize(str).forEach(function (w) { if (!STOP[w]) words.push({ w: w, k: tier }); });
    };
    if (det.label) push(det.label, TIER.name);
    (det.guesses || []).forEach(function (g) {
      var c = D.CATALOG_BY_ID[g.id];
      if (!c) return;
      push(c.name, TIER.name);
      c.syn.forEach(function (s) { push(s, TIER.syn); });
      push(c.cat, TIER.cat);
    });
    if (det.catalogId && D.CATALOG_BY_ID[det.catalogId]) {
      var c0 = D.CATALOG_BY_ID[det.catalogId];
      push(c0.name, TIER.name);
      c0.syn.forEach(function (s) { push(s, TIER.syn); });
      push(c0.cat, TIER.cat);
    }
    return words;
  }

  function textScore(det, words) {
    if (!words.length) return null;
    var vocab = vocabularyFor(det);
    var total = 0;
    words.forEach(function (q) {
      var best = 0;
      for (var i = 0; i < vocab.length; i++) {
        var s = wordScore(q, vocab[i].w) * vocab[i].k;
        if (s > best) best = s;
        if (best === 1) break;                 // an exact name hit cannot be beaten
      }
      total += best;
    });
    var score = total / words.length;
    // an object the detector only guessed at is a weaker answer than a
    // confirmed one, so temper the name match by how sure it is
    if (det.labelSource === 'predicted') score *= 0.72 + 0.28 * (det.confidence / 100);
    return score;
  }

  /* -- colour ------------------------------------------------------------- */
  var GROUP_LAB = {};
  D.COLOR_GROUPS.forEach(function (g) {
    var rgb = R.hexToRgb(g.swatch);
    GROUP_LAB[g.id] = V.srgbToLab(rgb.r, rgb.g, rgb.b);
  });

  function colorScore(det, colors) {
    if (!colors.length) return null;
    var best = 0;
    var rgb = R.hexToRgb(det.color.hex);
    var lab = V.srgbToLab(rgb.r, rgb.g, rgb.b);
    colors.forEach(function (g) {
      var s;
      if (det.color.group === g) s = 1;
      else {
        // near misses still count a little: navy under lamplight can read teal
        var d = V.deltaE(lab, GROUP_LAB[g] || [0, 0, 0]);
        s = Math.max(0, 1 - d / 62) * 0.8;
      }
      if (s > best) best = s;
    });
    return best;
  }

  function shapeScore(det, shape) {
    if (!shape) return null;
    return (D.SHAPE_SIM[det.shape] && D.SHAPE_SIM[det.shape][shape]) || 0;
  }

  function sizeScore(det, size) {
    if (!size) return null;
    var bucket = null;
    for (var i = 0; i < D.SIZES.length; i++) if (D.SIZES[i].id === size) bucket = D.SIZES[i];
    if (!bucket) return null;
    var v = det.sizeFrac;
    if (v >= bucket.range[0] && v <= bucket.range[1]) return 1;
    var d = v < bucket.range[0] ? bucket.range[0] - v : v - bucket.range[1];
    return Math.max(0, 1 - d / 0.14);
  }

  var WEIGHTS = { text: 0.50, color: 0.25, shape: 0.18, size: 0.07 };

  /** Score one detection against the criteria. */
  function scoreDetection(det, crit) {
    var parts = {
      text: textScore(det, crit.words),
      color: colorScore(det, crit.colors),
      shape: shapeScore(det, crit.shape),
      size: sizeScore(det, crit.size)
    };
    var sum = 0, wsum = 0;
    for (var k in parts) {
      if (parts[k] === null) continue;
      sum += parts[k] * WEIGHTS[k];
      wsum += WEIGHTS[k];
    }
    var score = wsum ? sum / wsum : 0;

    // a flat "no" on a criterion you explicitly asked for should sink the
    // result, however well the other criteria did
    if (parts.color !== null && parts.color < 0.25) score *= 0.45;
    if (parts.shape !== null && parts.shape < 0.2) score *= 0.55;
    if (parts.text !== null && parts.text < 0.2) score *= 0.5;

    return { score: score, parts: parts };
  }

  var THRESHOLD = 0.55;

  /**
   * Rank every detection against the criteria.
   * @returns { results, matches, best, criteria }
   */
  function run(detections, crit, threshold) {
    threshold = threshold === undefined ? THRESHOLD : threshold;
    var anyCriteria = crit.active() > 0;
    var results = detections.map(function (det) {
      var s = anyCriteria ? scoreDetection(det, crit) : { score: 0, parts: {} };
      return {
        det: det,
        score: s.score,
        parts: s.parts,
        match: anyCriteria && s.score >= threshold,
        reasons: describeReasons(det, s.parts, crit)
      };
    });
    results.sort(function (a, b) {
      if (b.score !== a.score) return b.score - a.score;
      return b.det.confidence - a.det.confidence;
    });
    var matches = results.filter(function (r) { return r.match; });
    return {
      results: results,
      matches: matches,
      best: matches[0] || null,
      searched: anyCriteria,
      criteria: crit,
      threshold: threshold
    };
  }

  /** Short human-readable notes for the results list. */
  function describeReasons(det, parts, crit) {
    var out = [];
    if (parts.text !== null && parts.text !== undefined) {
      out.push({ kind: 'name', ok: parts.text >= 0.6,
                 text: det.label + (parts.text >= 0.85 ? '' : ' (partial)') });
    }
    if (parts.color !== null && parts.color !== undefined) {
      out.push({ kind: 'colour', ok: parts.color >= 0.6, text: det.color.group });
    }
    if (parts.shape !== null && parts.shape !== undefined) {
      out.push({ kind: 'shape', ok: parts.shape >= 0.6, text: det.shape });
    }
    if (parts.size !== null && parts.size !== undefined) {
      out.push({ kind: 'size', ok: parts.size >= 0.6, text: det.sizeBucket });
    }
    return out;
  }

  NS.Search = {
    parseQuery: parseQuery,
    buildCriteria: buildCriteria,
    scoreDetection: scoreDetection,
    run: run,
    editDistance: editDistance,
    wordScore: wordScore,
    SHAPE_WORDS: SHAPE_WORDS,
    SIZE_WORDS: SIZE_WORDS,
    THRESHOLD: THRESHOLD
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = NS.Search;
})(typeof globalThis !== 'undefined' ? globalThis : this);
