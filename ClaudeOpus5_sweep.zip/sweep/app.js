/* ============================================================================
 * Sweep — app.js
 * ----------------------------------------------------------------------------
 * The controller. Owns the state, drives the pipeline, wires the DOM.
 *
 * The loop, whenever anything changes:
 *
 *     world  ──detect()──▶ detections ──search()──▶ ranked results ──▶ draw
 *
 * Two rules keep it predictable:
 *   • Changing the colour or shape filters re-runs detection, because those
 *     filters are applied *inside* the detector (that is what makes filtered
 *     searches faster). Changing only the words re-runs the ranking.
 *   • Nothing draws directly. Handlers change state and ask for a frame.
 * ==========================================================================*/
(function (global) {
  'use strict';

  var NS = global.Sweep;
  var D = NS.Data, V = NS.Vision, S = NS.Search, SC = NS.Scan, UI = NS.UI;
  var el = UI.el;
  var $ = function (id) { return document.getElementById(id); };

  /* -- preferences ---------------------------------------------------------
   * localStorage is unavailable in some embedded contexts, so it is treated as
   * a bonus rather than a dependency. */
  var Store = (function () {
    var mem = {};
    var ok = false;
    try { global.localStorage.setItem('__t', '1'); global.localStorage.removeItem('__t'); ok = true; }
    catch (e) { ok = false; }
    return {
      get: function (k, dflt) {
        try { var v = ok ? global.localStorage.getItem(k) : mem[k];
              return v === null || v === undefined ? dflt : JSON.parse(v); }
        catch (e) { return dflt; }
      },
      set: function (k, v) {
        try { var s = JSON.stringify(v); if (ok) global.localStorage.setItem(k, s); else mem[k] = s; }
        catch (e) { /* preferences are optional */ }
      }
    };
  })();

  /* ==========================================================================
   * STATE
   * ========================================================================*/
  var state = {
    engineId: Store.get('sweep.engine', 'balanced'),
    engine: null,
    engineReady: false,
    world: null,
    worldKey: null,
    panX: 0,
    fitRoom: false,
    mode: 'sample',                    // sample | live | sweeping
    detections: [],
    out: { results: [], matches: [], searched: false, threshold: S.THRESHOLD },
    stats: null,
    accuracy: null,
    stitch: null,
    query: { text: '', colors: [], shape: '', size: '' },
    prefilter: Store.get('sweep.prefilter', true),
    toggles: Store.get('sweep.toggles', {
      boxes: true, labels: true, percent: true, dim: true, matchesOnly: false
    }),
    tab: 'results',
    focusUid: null,
    sweepX: null,
    history: D.SAMPLE_HISTORY.slice(),
    reduceMotion: global.matchMedia
      ? global.matchMedia('(prefers-reduced-motion: reduce)').matches : false
  };

  var view, camera = new SC.Camera(), liveTimer = null, panAnim = null;

  /* ==========================================================================
   * STATUS
   * ========================================================================*/
  function setStatus(text, kind) {
    $('statusText').textContent = text;
    $('statusDot').className = 'status-dot' + (kind ? ' is-' + kind : '');
  }
  function setProgress(p) {
    var bar = $('loadbar');
    if (p === null) { bar.classList.remove('is-on'); return; }
    bar.classList.add('is-on');
    $('loadfill').style.width = Math.round(p * 100) + '%';
  }

  /* ==========================================================================
   * ENGINE LOADING
   * The colour table is built in slices so the page keeps responding and the
   * progress bar means something. Precision really is slower to start — and
   * really is quicker per frame afterwards.
   * ========================================================================*/
  function loadEngine(id, done) {
    var profile = V.ENGINES[id];
    state.engineId = id;
    state.engineReady = false;
    Store.set('sweep.engine', id);
    setStatus('Loading the ' + profile.name.toLowerCase() + ' detector…', 'busy');

    var builder = V.lutBuilder(profile.bits);
    var slice = Math.max(2048, Math.round(builder.total / 40));
    var t0 = performance.now();

    (function step() {
      var finished = builder.run(slice);
      setProgress(builder.progress);
      if (!finished) { requestAnimationFrame(step); return; }
      state.engine = V.makeEngine(profile, builder.lut);
      state.engineReady = true;
      var ms = Math.round(performance.now() - t0);
      setProgress(null);
      setStatus(profile.name + ' ready · ' + builder.total.toLocaleString() +
                ' colours in ' + ms + ' ms', 'ok');
      if (done) done();
    })();
  }

  /* ==========================================================================
   * PIPELINE
   * ========================================================================*/
  function currentCriteria() {
    return S.buildCriteria({
      text: state.query.text,
      colors: state.query.colors,
      shape: state.query.shape,
      size: state.query.size
    });
  }

  function runDetection() {
    if (!state.engineReady || !state.world) return;
    var crit = currentCriteria();
    var pre = state.prefilter ? { colors: crit.colors, shape: crit.shape } : null;
    var res = V.detect(state.world.surface, state.engine, {
      truth: state.world.truth,
      prefilter: pre
    });
    state.detections = res.detections;
    state.stats = res.stats;
    state.accuracy = state.world.truth ? V.score(res.detections, state.world.truth) : null;
    runSearch();
  }

  function runSearch() {
    var crit = currentCriteria();
    state.out = S.run(state.detections, crit);
    state.focusUid = state.out.best ? state.out.best.det.uid : null;
    syncAutoChips(crit);
    renderPanel();
    updateSummary(crit);
    requestDraw();
  }

  /** Log a search that actually found (or failed to find) something. */
  function recordSearch(crit) {
    if (!crit.active()) return;
    var q = crit.rawText.trim() || describeCriteria(crit);
    var best = state.out.best;
    var when = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    state.history.unshift({
      when: 'Just now, ' + when,
      room: state.world ? state.world.name : '—',
      query: q,
      found: !!best,
      detail: best
        ? best.det.label + ' · ' + best.det.confidence + '% · ' + best.det.where
        : 'No match above ' + Math.round(state.out.threshold * 100) + '%'
    });
    state.history = state.history.slice(0, 12);
    if (state.tab === 'log') renderPanel();
  }

  function describeCriteria(c) {
    return [c.colors.join('/'), c.shape, c.size].filter(Boolean).join(' ') || 'anything';
  }

  /* ==========================================================================
   * WORLDS
   * ========================================================================*/
  function setWorld(world, key) {
    state.world = world;
    state.worldKey = key;
    state.panX = 0;
    view.setWorld(world, key);
    $('stageBadge').textContent = world.name + (world.blurb ? ' — ' + world.blurb : '');
    $('ribbonHint').textContent = world.width + ' × ' + world.height + ' px';
    updatePanRange();
    runDetection();
  }

  function loadRoom(roomId) {
    stopCamera();
    state.mode = 'sample';
    state.stitch = null;
    setWorld(SC.worldFromRoom(roomId), 'room:' + roomId);
    setStatus('Scanned ' + D.ROOMS_BY_ID[roomId].name.toLowerCase(), 'ok');
  }

  /* ==========================================================================
   * SWEEP
   * Sample rooms: pan a viewport across the room, capture frames, stitch them
   * back into one picture, then scan that. The stitcher is the same code the
   * camera path uses — nothing about this is faked for the demo.
   * ========================================================================*/
  function runSweep() {
    if (state.mode === 'sweeping' || !state.world) return;
    if (state.mode === 'live') { return recordCameraSweep(); }

    var world = state.world;
    var plan = SC.sweepPlan(world);
    var st = new SC.Stitcher();
    var i = 0;
    state.mode = 'sweeping';
    state.fitRoom = false;
    $('fitBtn').setAttribute('aria-pressed', 'false');
    setStatus('Sweeping… frame 1 of ' + plan.positions.length, 'busy');
    $('sweepBtn').disabled = true;

    var startedAt = performance.now();
    var perFrame = state.reduceMotion ? 120 : 320;

    (function nextFrame() {
      var x = plan.positions[i];
      var prev = i > 0 ? plan.positions[i - 1] : x;
      st.add(SC.frameAt(world, x, true, i + 1), { trueShift: x - prev, force: true });
      state.sweepX = x + plan.viewportW / 2;
      state.panX = x;
      updatePanRange();
      setProgress((i + 1) / plan.positions.length);
      setStatus('Sweeping… frame ' + (i + 1) + ' of ' + plan.positions.length, 'busy');
      requestDraw();
      i++;
      if (i < plan.positions.length) {
        setTimeout(nextFrame, perFrame);
      } else {
        finishSweep(st, world, startedAt);
      }
    })();
  }

  function finishSweep(st, sourceWorld, startedAt) {
    var stitched = st.finish();
    state.stitch = st.report();
    state.sweepX = null;
    setProgress(null);
    $('sweepBtn').disabled = false;
    state.mode = 'sample';

    var name = sourceWorld.name + ' · stitched from ' + state.stitch.frames + ' frames';
    var world = SC.worldFromSurface(stitched, name, {
      truth: sourceWorld.truth, roomId: sourceWorld.roomId,
      blurb: 'one picture built from a pass across the room'
    });
    setWorld(world, 'stitch:' + Date.now());
    var ms = Math.round(performance.now() - startedAt);
    setStatus('Swept ' + state.stitch.frames + ' frames in ' + ms + ' ms · ' +
              state.detections.length + ' objects', 'ok');
  }

  /* -- camera sweep --------------------------------------------------------- */
  function recordCameraSweep() {
    var st = new SC.Stitcher();
    var frames = 0, MAX = 14;
    state.mode = 'sweeping';
    $('sweepBtn').disabled = true;
    setStatus('Pan slowly across the room…', 'busy');

    var timer = setInterval(function () {
      var img = camera.grab(560);
      if (img) {
        var added = st.add(img, {});
        if (added !== null) frames++;
      }
      setProgress(frames / MAX);
      setStatus('Recording sweep… ' + frames + ' frames (pan slowly)', 'busy');
      if (frames >= MAX) done();
    }, 420);

    function done() {
      clearInterval(timer);
      setProgress(null);
      $('sweepBtn').disabled = false;
      stopCamera();
      state.mode = 'sample';
      if (frames < 2) {
        setStatus('Sweep needs at least two frames — try panning further.', 'warn');
        return;
      }
      state.stitch = st.report();
      var stitched = st.finish();
      setWorld(SC.worldFromSurface(stitched, 'Your sweep', {
        blurb: state.stitch.frames + ' camera frames joined together'
      }), 'camsweep:' + Date.now());
      setStatus('Sweep built from ' + state.stitch.frames + ' frames · ' +
                state.detections.length + ' objects', 'ok');
    }
    state._stopSweep = done;
  }

  /* ==========================================================================
   * CAMERA
   * ========================================================================*/
  function startCamera() {
    var v = $('cam');
    setStatus('Asking for the camera…', 'busy');
    camera.start(v).then(function () {
      state.mode = 'live';
      v.hidden = false;
      $('cameraBtn').textContent = 'Stop camera';
      $('sweepBtn').textContent = 'Record a sweep';
      setStatus('Camera live — detecting continuously', 'ok');
      tickLive();
    }).catch(function (err) {
      state.mode = 'sample';
      setStatus('No camera available — staying with the sample rooms.', 'warn');
      showStageMessage('Camera unavailable',
        (err && err.message ? err.message + ' ' : '') +
        'The sample rooms below work exactly the same way.');
      setTimeout(hideStageMessage, 4200);
    });
  }

  function tickLive() {
    if (state.mode !== 'live') return;
    var img = camera.grab(640);
    if (img && state.engineReady) {
      var w = { source: 'live', name: 'Camera', blurb: '', surface: img,
                width: img.width, height: img.height,
                viewportW: img.width, truth: null };
      setWorldLive(w);
    }
    liveTimer = setTimeout(tickLive, V.ENGINES[state.engineId].interval);
  }

  /** Live frames replace the world without resetting the pan or the badge. */
  var liveFrameNo = 0;
  function setWorldLive(world) {
    state.world = world;
    view.setWorld(world, 'live:' + (++liveFrameNo));   // new key every frame
    var crit = currentCriteria();
    var res = V.detect(world.surface, state.engine, {
      prefilter: state.prefilter ? { colors: crit.colors, shape: crit.shape } : null
    });
    state.detections = res.detections;
    state.stats = res.stats;
    state.accuracy = null;
    state.out = S.run(state.detections, crit);
    state.focusUid = state.out.best ? state.out.best.det.uid : null;
    renderPanel();
    updateSummary(crit);
    requestDraw();
  }

  function stopCamera() {
    if (liveTimer) { clearTimeout(liveTimer); liveTimer = null; }
    state._stopSweep = null;
    camera.stop();
    $('cam').hidden = true;
    $('cameraBtn').textContent = 'Use camera';
    $('sweepBtn').textContent = 'Sweep the room';
    if (state.mode === 'live') state.mode = 'sample';
  }

  function showStageMessage(title, body) {
    var box = $('stageMsg');
    UI.clear(box);
    box.appendChild(el('strong', null, title));
    box.appendChild(el('p', null, body));
    box.hidden = false;
  }
  function hideStageMessage() { $('stageMsg').hidden = true; }

  /* ==========================================================================
   * PANEL RENDERING
   * ========================================================================*/
  function renderPanel() {
    if (state.tab === 'results') {
      UI.renderResults($('paneResults'), state.out, state, { focus: focusDetection });
    } else if (state.tab === 'inventory') {
      UI.renderInventory($('paneInventory'), state.out.results, state.world);
    } else {
      UI.renderLog($('paneLog'), state);
    }
  }

  function updateSummary(crit) {
    var box = $('summary');
    UI.clear(box);
    if (!state.detections.length) { box.hidden = true; return; }
    box.hidden = false;

    var n = state.out.matches.length;
    var line = el('p', 'summary-line');
    if (!crit.active()) {
      line.innerHTML = '<strong>' + state.detections.length + '</strong> objects in view. ' +
                       'Type what you are after.';
    } else if (n) {
      line.innerHTML = '<strong>' + n + '</strong> match' + (n === 1 ? '' : 'es') +
                       ' out of ' + state.detections.length + ' objects.';
    } else {
      line.innerHTML = 'No match yet — <strong>' + state.detections.length +
                       '</strong> objects checked.';
    }
    box.appendChild(line);

    if (state.stats && state.stats.skippedByPrefilter > 0) {
      box.appendChild(el('p', 'summary-note',
        'Filters skipped ' + state.stats.skippedByPrefilter + ' of ' +
        state.stats.regions + ' regions before naming them — ' +
        state.stats.ms.total.toFixed(0) + ' ms total.'));
    } else if (state.stats) {
      box.appendChild(el('p', 'summary-note',
        state.stats.regions + ' regions · ' + state.stats.ms.total.toFixed(0) + ' ms'));
    }

    var flag = $('foundFlag');
    flag.hidden = !n;
    $('foundCount').textContent = n;
  }

  /* ==========================================================================
   * FOCUS / PAN
   * ========================================================================*/
  function focusDetection(det) {
    state.focusUid = det.uid;
    var t = view.transform;
    if (state.fitRoom || !t || t.fit) { requestDraw(); return; }
    var target = det.box.x + det.box.w / 2 - t.srcW / 2;
    animatePan(Math.max(0, Math.min(t.maxPan || 0, target)));
  }

  function animatePan(to) {
    if (panAnim) cancelAnimationFrame(panAnim);
    if (state.reduceMotion) { state.panX = to; updatePanRange(); requestDraw(); return; }
    var from = state.panX, t0 = performance.now(), dur = 420;
    (function step(now) {
      var k = Math.min(1, (now - t0) / dur);
      var e = 1 - Math.pow(1 - k, 3);
      state.panX = from + (to - from) * e;
      updatePanRange();
      requestDraw();
      if (k < 1) panAnim = requestAnimationFrame(step); else panAnim = null;
    })(performance.now());
  }

  function updatePanRange() {
    var slider = $('pan');
    if (!state.world) return;
    var t = view.transform;
    var max = t && !t.fit ? (t.maxPan || 0) : 0;
    slider.max = Math.max(1, Math.round(max));
    slider.value = Math.round(Math.max(0, Math.min(max, state.panX)));
    slider.disabled = max <= 0 || state.fitRoom;
  }

  /* ==========================================================================
   * DRAW LOOP
   * ========================================================================*/
  var needsDraw = true;
  function requestDraw() { needsDraw = true; }

  function frame(time) {
    var animating = !state.reduceMotion && state.out.matches.length > 0;
    if (needsDraw || animating) {
      needsDraw = false;
      draw(time);
    }
    requestAnimationFrame(frame);
  }

  function draw(time) {
    if (!state.world) return;
    view.resize();
    view.computeTransform(state.world, state.panX, state.fitRoom);
    view.drawWorld(state.world);
    view.drawOverlay({
      results: state.out.results,
      toggles: state.toggles,
      time: time || 0,
      focusUid: state.focusUid,
      reduceMotion: state.reduceMotion
    });
    UI.drawRibbon($('ribbon'), view, state.world, state.out.results,
                  view.transform, state.sweepX);
  }

  /* ==========================================================================
   * CHIP BUILDERS
   * ========================================================================*/
  function buildChips() {
    var cc = $('colorChips');
    D.COLOR_GROUPS.forEach(function (g) {
      var b = el('button', 'chip chip-color');
      b.type = 'button';
      b.dataset.value = g.id;
      b.setAttribute('aria-pressed', 'false');
      var sw = el('span', 'chip-swatch');
      sw.style.background = g.swatch;
      b.appendChild(sw);
      b.appendChild(el('span', null, g.label));
      b.addEventListener('click', function () { toggleColor(g.id); });
      cc.appendChild(b);
    });

    var sc = $('shapeChips');
    D.SHAPES.forEach(function (s) {
      var b = el('button', 'chip');
      b.type = 'button';
      b.dataset.value = s.id;
      b.title = 'like a ' + s.hint;
      b.setAttribute('aria-pressed', 'false');
      b.appendChild(el('span', null, s.label));
      b.addEventListener('click', function () { pickShape(s.id); });
      sc.appendChild(b);
    });

    var zc = $('sizeChips');
    D.SIZES.forEach(function (s) {
      var b = el('button', 'chip');
      b.type = 'button';
      b.dataset.value = s.id;
      b.title = s.hint;
      b.setAttribute('aria-pressed', 'false');
      b.appendChild(el('span', null, s.label));
      b.addEventListener('click', function () { pickSize(s.id); });
      zc.appendChild(b);
    });

    var rooms = $('roomSelect');
    D.ROOMS.forEach(function (r) {
      var o = el('option', null, r.name);
      o.value = r.id;
      rooms.appendChild(o);
    });

    var quick = $('quickRow');
    D.SAMPLE_SEARCHES.forEach(function (q) {
      var b = el('button', 'quick-btn');
      b.type = 'button';
      b.textContent = [q.color, q.shape, q.text].filter(Boolean).join(' ');
      b.title = 'Search ' + (D.ROOMS_BY_ID[q.room] || {}).name;
      b.addEventListener('click', function () { applySample(q); });
      quick.appendChild(b);
    });
  }

  function applySample(q) {
    if (q.room && (!state.world || state.world.roomId !== q.room)) {
      $('roomSelect').value = q.room;
      loadRoom(q.room);
    }
    state.query.text = q.text;
    state.query.colors = q.color ? [q.color] : [];
    state.query.shape = q.shape || '';
    state.query.size = q.size || '';
    $('q').value = q.text;
    syncChipUI();
    runDetection();
    recordSearch(currentCriteria());
  }

  function toggleColor(id) {
    var i = state.query.colors.indexOf(id);
    if (i === -1) state.query.colors.push(id); else state.query.colors.splice(i, 1);
    syncChipUI();
    runDetection();                 // colour is a detector-stage filter
  }
  function pickShape(id) {
    state.query.shape = state.query.shape === id ? '' : id;
    syncChipUI();
    runDetection();                 // shape is a detector-stage filter
  }
  function pickSize(id) {
    state.query.size = state.query.size === id ? '' : id;
    syncChipUI();
    runSearch();                    // size only affects ranking
  }

  function syncChipUI() {
    [].forEach.call($('colorChips').children, function (b) {
      b.setAttribute('aria-pressed', state.query.colors.indexOf(b.dataset.value) !== -1);
      b.classList.remove('is-auto');
    });
    [].forEach.call($('shapeChips').children, function (b) {
      b.setAttribute('aria-pressed', state.query.shape === b.dataset.value);
      b.classList.remove('is-auto');
    });
    [].forEach.call($('sizeChips').children, function (b) {
      b.setAttribute('aria-pressed', state.query.size === b.dataset.value);
      b.classList.remove('is-auto');
    });
  }

  /** Show filters that came from the typed words, marked as auto-filled. */
  function syncAutoChips(crit) {
    syncChipUI();
    var p = crit.parsed;
    if (!state.query.colors.length) {
      p.colors.forEach(function (c) {
        [].forEach.call($('colorChips').children, function (b) {
          if (b.dataset.value === c) b.classList.add('is-auto');
        });
      });
    }
    if (!state.query.shape && p.shape) {
      [].forEach.call($('shapeChips').children, function (b) {
        if (b.dataset.value === p.shape) b.classList.add('is-auto');
      });
    }
    if (!state.query.size && p.size) {
      [].forEach.call($('sizeChips').children, function (b) {
        if (b.dataset.value === p.size) b.classList.add('is-auto');
      });
    }
  }

  /* ==========================================================================
   * EVENTS
   * ========================================================================*/
  function wire() {
    $('searchForm').addEventListener('submit', function (e) {
      e.preventDefault();
      state.query.text = $('q').value;
      $('q').blur();
      runDetection();
      recordSearch(currentCriteria());
    });

    var typeTimer = null;
    $('q').addEventListener('input', function () {
      state.query.text = $('q').value;
      clearTimeout(typeTimer);
      // typed colour/shape words feed the detector, so redetect on a short pause
      typeTimer = setTimeout(runDetection, 220);
    });

    $('clearBtn').addEventListener('click', function () {
      state.query = { text: '', colors: [], shape: '', size: '' };
      $('q').value = '';
      syncChipUI();
      runDetection();
      $('q').focus();
    });

    $('engineSelect').addEventListener('change', function (e) {
      loadEngine(e.target.value, runDetection);
    });

    $('roomSelect').addEventListener('change', function (e) { loadRoom(e.target.value); });
    $('sweepBtn').addEventListener('click', runSweep);

    $('cameraBtn').addEventListener('click', function () {
      if (state.mode === 'live') { stopCamera(); setStatus('Camera stopped', 'ok'); }
      else startCamera();
    });

    $('fitBtn').addEventListener('click', function () {
      state.fitRoom = !state.fitRoom;
      this.setAttribute('aria-pressed', String(state.fitRoom));
      this.textContent = state.fitRoom ? 'Close up' : 'Whole room';
      updatePanRange();
      requestDraw();
    });

    $('prefilterToggle').addEventListener('change', function (e) {
      state.prefilter = e.target.checked;
      Store.set('sweep.prefilter', state.prefilter);
      runDetection();
    });

    var toggleMap = { tBoxes: 'boxes', tLabels: 'labels', tPercent: 'percent',
                      tDim: 'dim', tOnly: 'matchesOnly' };
    Object.keys(toggleMap).forEach(function (id) {
      var input = $(id);
      input.checked = !!state.toggles[toggleMap[id]];
      input.addEventListener('change', function (e) {
        state.toggles[toggleMap[id]] = e.target.checked;
        Store.set('sweep.toggles', state.toggles);
        if (toggleMap[id] === 'matchesOnly') renderPanel();
        requestDraw();
      });
    });

    [].forEach.call(document.querySelectorAll('.tab'), function (t) {
      t.addEventListener('click', function () {
        state.tab = t.dataset.tab;
        [].forEach.call(document.querySelectorAll('.tab'), function (o) {
          var on = o === t;
          o.classList.toggle('is-on', on);
          o.setAttribute('aria-selected', String(on));
        });
        $('paneResults').hidden = state.tab !== 'results';
        $('paneInventory').hidden = state.tab !== 'inventory';
        $('paneLog').hidden = state.tab !== 'log';
        renderPanel();
      });
    });

    $('pan').addEventListener('input', function (e) {
      state.panX = Number(e.target.value);
      requestDraw();
    });

    /* drag to pan, on the picture and on the ribbon */
    dragPan($('overlay'), function (dx) {
      var t = view.transform;
      if (!t || t.fit) return;
      state.panX = Math.max(0, Math.min(t.maxPan, state.panX - dx / t.scale));
      updatePanRange();
      requestDraw();
    });

    var ribbon = $('ribbon');
    function ribbonSeek(clientX) {
      if (!state.world || state.fitRoom) return;
      var r = ribbon.getBoundingClientRect();
      var frac = (clientX - r.left) / r.width;
      var t = view.transform;
      state.panX = Math.max(0, Math.min(t.maxPan, frac * state.world.width - t.srcW / 2));
      updatePanRange();
      requestDraw();
    }
    ribbon.addEventListener('pointerdown', function (e) {
      ribbon.setPointerCapture(e.pointerId); ribbonSeek(e.clientX);
    });
    ribbon.addEventListener('pointermove', function (e) {
      if (e.buttons) ribbonSeek(e.clientX);
    });

    /* keyboard panning */
    $('stageBox').tabIndex = 0;
    $('stageBox').addEventListener('keydown', function (e) {
      var t = view.transform;
      if (!t || t.fit) return;
      var step = t.srcW * 0.25;
      if (e.key === 'ArrowRight') { state.panX = Math.min(t.maxPan, state.panX + step); }
      else if (e.key === 'ArrowLeft') { state.panX = Math.max(0, state.panX - step); }
      else return;
      e.preventDefault();
      updatePanRange();
      requestDraw();
    });

    global.addEventListener('resize', function () { requestDraw(); });
  }

  function dragPan(node, onMove) {
    var last = null;
    node.addEventListener('pointerdown', function (e) {
      last = e.clientX;
      node.setPointerCapture(e.pointerId);
      node.classList.add('is-dragging');
    });
    node.addEventListener('pointermove', function (e) {
      if (last === null) return;
      var dx = e.clientX - last;
      last = e.clientX;
      onMove(dx);
    });
    ['pointerup', 'pointercancel'].forEach(function (evt) {
      node.addEventListener(evt, function () { last = null; node.classList.remove('is-dragging'); });
    });
  }

  /* ==========================================================================
   * BOOT
   * ========================================================================*/
  function boot() {
    view = new UI.View($('view'), $('overlay'));
    buildChips();
    wire();
    $('engineSelect').value = state.engineId;
    $('prefilterToggle').checked = state.prefilter;
    syncChipUI();

    // start on the room from the walkthrough, with the search already typed in
    var first = D.SAMPLE_SEARCHES[0];
    $('roomSelect').value = first.room;
    $('q').value = first.text;
    state.query.text = first.text;
    state.query.colors = first.color ? [first.color] : [];
    state.query.shape = first.shape || '';
    syncChipUI();

    loadEngine(state.engineId, function () {
      loadRoom(first.room);
      requestAnimationFrame(frame);
    });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();

  // exposed for debugging from the console
  NS.app = { state: state, runDetection: runDetection, runSearch: runSearch };
})(typeof globalThis !== 'undefined' ? globalThis : this);
