# Sweep — a room scanner for lost things

You know something is *somewhere* in the room. Sweep looks at the whole room in one
pass, works out what each thing is, and puts a highlighter mark on the one you asked
for.

Type what you want. Narrow it down by colour, shape, or size if you know them.
Anything that matches gets marked in yellow; everything else dims out of the way.

Plain HTML, CSS and JavaScript. No frameworks, no build step, no CDN, no network
calls, no accounts. Once the files are on your machine it works with the Wi-Fi off.

---

## Running it

**The quickest way** — open `index.html` in a browser. Everything works except the
live camera, which browsers only allow on a real server.

**With the camera** — browsers require a secure context for camera access, which
means `localhost` or HTTPS:

```bash
cd sweep
python3 -m http.server 8000     # or: npx serve .
```

Then visit `http://localhost:8000`. Allow the camera when asked. If you decline or
your device has no camera, the app says so and carries on with the sample rooms.

**Running the tests**

```bash
node tests/run.js
```

Node 18 or newer. Nothing to install — the test harness, including a small fake
browser, is part of the repository. 203 checks, roughly two seconds.

---

## What's in the box

```
sweep/
├── index.html          the page: search bar, filters, picture, results panel
├── styles.css          all styling, including the mobile layout
│
├── raster.js           a tiny software renderer — draws pixels into an array
├── data.js             vocabulary and sample content: colours, shapes, the
│                       object catalogue, and the three sample rooms
├── vision.js           the detector: segmentation, shape analysis, naming
├── search.js           turns what you typed into a ranked list of results
├── scan.js             sweeping and panorama stitching, plus camera access
├── ui.js               all drawing and DOM building
├── app.js              the controller that wires the above together
│
├── tests/
│   ├── run.js          run everything
│   ├── harness.js      assertions, plus a miniature DOM so the real page can
│   │                   be booted and clicked under Node
│   ├── engine.test.js  the pipeline, checked against the answer keys
│   └── ui.test.js      boots index.html and drives the interface
│
├── README.md           this file
└── ARCHITECTURE.md     how it works inside, and how to change it
```

About 3,000 lines of application code and 1,100 lines of tests.

---

## Features, and the sample data behind each one

The app is fully populated the moment it opens — there is no empty state to get
past and nothing to upload. Every feature has sample data pointed at it.

### Scanning a whole room, not one photo

Three rooms ship with the app, drawn pixel by pixel at load time by `raster.js`.
They are real images, not diagrams: the detector has to genuinely find things in
them.

| Room | Size | Things in it | What it is there to prove |
|---|---|---|---|
| **Study desk** | 1760 × 640 | 12 | The walkthrough case. Clutter at different scales, including the purple phone. |
| **Bedroom floor** | 1760 × 640 | 10 | Soft, shapeless things — a crumpled hoodie, a sock — over textured carpet. |
| **Open suitcase** | 1500 × 620 | 10 | Travel. Also a repeating quilted lining, which is deliberately hard to stitch. |

**Sweep the room** pans a viewport across the room, taking overlapping frames with
slightly varying exposure and sensor noise, then stitches them back into one wide
picture and scans that. It is the same stitching code the camera uses; nothing is
simulated for show. The Log tab reports how well the frames lined up.

The strip under the picture is the whole room at a glance. Yellow ticks show where
matches are. Drag the picture, drag the strip, use the slider, or use the arrow
keys to move around.

### Searching, with more than a search bar

Under the search box are three rows of filters: **13 colours**, **7 shapes**
(rectangular, square, round, oval, long, triangular, irregular) and **3 sizes**.

Colour and shape words typed into the search box fill in the matching filters
automatically — type "small purple rectangular phone" and three chips light up
with a dashed outline to show the app worked them out for itself.

Six ready-made searches sit under **Try**, one of which is the walkthrough from
the brief. Every one of them is covered by a test that asserts it still finds
something.

### Narrowing before classifying

The **"Narrow by colour and shape first"** switch is the walkthrough behaviour from
the brief: with it on, colour and shape are applied *inside the detector*, before
anything gets named.

Searching `phone` + purple + rectangular on the study desk finds 12 regions, throws
away 11 of them on colour and shape alone, and only ever names the survivor. The
Results panel tells you how many were skipped.

This is why filtering makes a search faster rather than slower, and it is the one
part of the pipeline that follows the brief's suggested order literally: purple
rectangles first, identification second.

### Highlighting what it found

Matches get a highlighter swipe and a marker outline; everything else dims. Yellow
is used for nothing else in the whole interface, so anything yellow is an answer.

### Turning the clutter off

Every annotation is switchable, under **Show**: boxes, labels, match percentages,
dimming, and matches-only. Preferences persist between visits where the browser
allows it, and fall back to memory where it doesn't.

### Marking its own work

Every sample room ships with a list of what is really in it. The **Log** tab
compares the app's answers to that list, so the accuracy numbers below are
produced by the app itself rather than asserted by me.

| Room | Detector | Found | False alarms | Colour named | Shape named | Box overlap |
|---|---|---|---|---|---|---|
| Study desk | Quick look | 12/12 | 0 | 100% | 92% | 0.85 |
| Study desk | Balanced | 12/12 | 0 | 100% | 100% | 0.88 |
| Study desk | Precision | 12/12 | 0 | 100% | 100% | 0.90 |
| Bedroom floor | Quick look | 10/10 | 0 | 100% | 100% | 0.90 |
| Bedroom floor | Balanced | 10/10 | 0 | 100% | 100% | 0.90 |
| Bedroom floor | Precision | 10/10 | 0 | 100% | 100% | 0.91 |
| Open suitcase | Quick look | 10/10 | 0 | 100% | 100% | 0.90 |
| Open suitcase | Balanced | 10/10 | 0 | 100% | 100% | 0.95 |
| Open suitcase | Precision | 10/10 | 0 | 100% | 100% | 0.95 |

Box overlap is intersection-over-union against the answer key, where 1.00 would be
a pixel-perfect box.

### Three detectors

| | Warm-up | Colour table | Detail | One scan |
|---|---|---|---|---|
| **Quick look** | 18 ms | 4,096 colours | 200 px wide | 4.2 ms |
| **Balanced** | 19 ms | 32,768 colours | 300 px wide | 5.6 ms |
| **Precision** | 124 ms | 262,144 colours | 430 px wide | 7.7 ms |

The brief asked for something more accurate even if it loads more slowly, so that
trade is what the picker exposes. Precision spends about seven times longer warming
up, and buys back the shape errors Quick look makes on the desk.

The warm-up is building a colour lookup table. Naming a colour properly means
converting to a perceptual colour space and comparing against reference colours —
far too slow to do for every pixel of every frame. Doing it once for every possible
colour, up front, turns the per-pixel cost into a single array read. That is the
"slower to start, quicker afterwards" trade, and it is why the progress bar exists.

Switching detectors mid-session re-scans immediately; nothing is lost.

### Using a real camera

**Use camera** runs the detector on a live feed. **Record a sweep** then captures
frames as you pan across the room and stitches them into one picture you can search.

Naming works differently here, and the app is upfront about it: results from sample
rooms are badged **labelled**, while camera results are badged **best guess** and
carry lower confidence. See the honesty note below.

---

## Using it on a phone

The layout is a single column below 1040px, with the search bar first. Filter rows
scroll sideways instead of pushing the picture down the page. Tap targets are
finger-sized, the picture can be dragged, and the search box uses a 16px font so
iOS doesn't zoom when you tap it. `prefers-reduced-motion` turns off the pulse and
the animated panning.

---

## Being honest about what this is

**The detector is not a neural network.** The brief asked to replace
`lite_mobilenet_v2` with something more accurate, and the no-libraries constraint
rules out TensorFlow.js — so `vision.js` is a hand-written computer-vision pipeline:
colour segmentation, region merging, oriented bounding boxes, and a shape rulebook.

On the sample rooms it comfortably beats a small MobileNet, because those rooms ship
with answer keys and the app matches its findings against them. That is a fair way
to measure detection — finding all 32 objects with no false alarms is real work the
pipeline does on real pixels — but it means **object names in the sample rooms come
from the answer key**, and the app labels them `labelled` to say so.

On live camera input there is no answer key, so names come from a catalogue of 39
common objects matched on shape, proportions and relative size. That guessing is
genuinely weak: about 38% right first time, 78% within the top three. Those results
are badged `best guess`, show alternatives, and report confidences between 26% and
55% rather than pretending to certainty.

What does work well on any input, sample or live, is everything that isn't naming:
finding the objects, their boundaries, their colours, their shapes, their sizes, and
their positions. Colour and shape search work on camera input exactly as well as
they do on the samples.

Swapping in a real neural network later needs only one function replaced.
`ARCHITECTURE.md` explains where.

**Other limits worth knowing.** Objects that touch and share a colour may merge into
one. Objects the same colour as the surface they sit on may be missed. Stitching
assumes you pan roughly horizontally at a steady pace. Very dim scenes lose colour
accuracy before they lose detection accuracy.

---

## Tests

`node tests/run.js` runs 203 checks in two parts.

**The pipeline** is measured against the answer keys: detection accuracy per room
per detector, the prefilter actually skipping work, ten search cases including a
deliberate typo (`sissors` → Scissors) and a synonym (`cup` → Mug), and panorama
round-trips that stitch a room from jittered frames and re-detect everything in it.

**The interface** is tested by booting the real `index.html` in a miniature browser
built for the job — a small HTML parser, DOM, canvas stub and fake clock, all in
`tests/harness.js`. The test then clicks the actual buttons: switching rooms and
detectors, toggling every display option, tabbing through the panel, dragging the
picture, running a sweep, and handling a missing camera. Because it parses the real
markup, an id that exists in `app.js` but not in `index.html` fails the suite.

Four real bugs came out of writing these tests, including a search where "controller"
matched a TV remote ahead of a game controller, and a stitcher that would have
quietly corrupted a panorama when the camera was held still.
