/* ============================================================================
 * Sweep — raster.js
 * ----------------------------------------------------------------------------
 * A tiny software rasterizer.
 *
 * Why does this exist when browsers ship a perfectly good Canvas2D API?
 *   1. The sample rooms have to be REAL PIXELS, because the detector reads
 *      pixels. Drawing them ourselves means the demo data is not faked — the
 *      detector genuinely has to find the phone in the picture.
 *   2. This file has zero DOM dependencies, so the exact same drawing code runs
 *      under Node in tests/engine.test.js. What the test proves is what the
 *      browser shows.
 *
 * Everything works on a "surface": { width, height, data: Uint8ClampedArray }
 * which is deliberately the same shape as an ImageData object, so a surface can
 * be handed straight to ctx.putImageData().
 *
 * Edges are drawn hard (no anti-aliasing) on purpose: soft edges invent
 * in-between colours that the segmenter would have to throw away anyway.
 * ==========================================================================*/
(function (global) {
  'use strict';

  var NS = global.Sweep || (global.Sweep = {});

  /* -- deterministic PRNG (mulberry32) --------------------------------------
   * Seeded so grain/noise is identical every run. Tests depend on this. */
  function rng(seed) {
    var a = seed >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      var t = a;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  /* -- colour helpers ------------------------------------------------------ */

  function hexToRgb(hex) {
    var h = String(hex).replace('#', '');
    if (h.length === 3) h = h[0] + h[0] + h[1] + h[1] + h[2] + h[2];
    var n = parseInt(h, 16);
    return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
  }

  function rgbToHex(r, g, b) {
    return '#' + [r, g, b].map(function (v) {
      var s = Math.max(0, Math.min(255, Math.round(v))).toString(16);
      return s.length === 1 ? '0' + s : s;
    }).join('');
  }

  /** Lighten (amt > 0) or darken (amt < 0) a hex colour. amt is -1..1. */
  function shade(hex, amt) {
    var c = hexToRgb(hex);
    var t = amt < 0 ? 0 : 255;
    var p = Math.abs(amt);
    return rgbToHex(
      c.r + (t - c.r) * p,
      c.g + (t - c.g) * p,
      c.b + (t - c.b) * p
    );
  }

  /** Mix two hex colours. t=0 → a, t=1 → b. */
  function mix(a, b, t) {
    var ca = hexToRgb(a), cb = hexToRgb(b);
    return rgbToHex(
      ca.r + (cb.r - ca.r) * t,
      ca.g + (cb.g - ca.g) * t,
      ca.b + (cb.b - ca.b) * t
    );
  }

  /* -- surfaces ------------------------------------------------------------ */

  function createSurface(w, h, fillHex) {
    var s = { width: w, height: h, data: new Uint8ClampedArray(w * h * 4) };
    if (fillHex) fillRect(s, 0, 0, w, h, fillHex);
    else {
      // default: opaque black so alpha is never 0 (getImageData parity)
      for (var i = 3; i < s.data.length; i += 4) s.data[i] = 255;
    }
    return s;
  }

  function setPixel(s, x, y, r, g, b, alpha) {
    if (x < 0 || y < 0 || x >= s.width || y >= s.height) return;
    var i = (y * s.width + x) * 4;
    var d = s.data;
    if (alpha === undefined || alpha >= 1) {
      d[i] = r; d[i + 1] = g; d[i + 2] = b; d[i + 3] = 255;
    } else {
      d[i] = d[i] + (r - d[i]) * alpha;
      d[i + 1] = d[i + 1] + (g - d[i + 1]) * alpha;
      d[i + 2] = d[i + 2] + (b - d[i + 2]) * alpha;
      d[i + 3] = 255;
    }
  }

  function getPixel(s, x, y) {
    var i = (y * s.width + x) * 4;
    return { r: s.data[i], g: s.data[i + 1], b: s.data[i + 2] };
  }

  /* -- primitives ----------------------------------------------------------
   * Each takes a surface, geometry, a hex colour and an optional alpha. */

  function fillRect(s, x, y, w, h, hex, alpha) {
    var c = hexToRgb(hex);
    var x0 = Math.max(0, Math.round(x)), y0 = Math.max(0, Math.round(y));
    var x1 = Math.min(s.width, Math.round(x + w)), y1 = Math.min(s.height, Math.round(y + h));
    for (var yy = y0; yy < y1; yy++) {
      for (var xx = x0; xx < x1; xx++) setPixel(s, xx, yy, c.r, c.g, c.b, alpha);
    }
  }

  function fillRoundRect(s, x, y, w, h, radius, hex, alpha) {
    var c = hexToRgb(hex);
    var r = Math.min(radius, Math.min(w, h) / 2);
    var x0 = Math.max(0, Math.round(x)), y0 = Math.max(0, Math.round(y));
    var x1 = Math.min(s.width, Math.round(x + w)), y1 = Math.min(s.height, Math.round(y + h));
    for (var yy = y0; yy < y1; yy++) {
      for (var xx = x0; xx < x1; xx++) {
        var dx = 0, dy = 0;
        if (xx < x + r) dx = (x + r) - xx; else if (xx > x + w - r - 1) dx = xx - (x + w - r - 1);
        if (yy < y + r) dy = (y + r) - yy; else if (yy > y + h - r - 1) dy = yy - (y + h - r - 1);
        if (dx * dx + dy * dy <= r * r) setPixel(s, xx, yy, c.r, c.g, c.b, alpha);
      }
    }
  }

  function fillEllipse(s, cx, cy, rx, ry, hex, alpha) {
    var c = hexToRgb(hex);
    var x0 = Math.max(0, Math.floor(cx - rx)), y0 = Math.max(0, Math.floor(cy - ry));
    var x1 = Math.min(s.width, Math.ceil(cx + rx)), y1 = Math.min(s.height, Math.ceil(cy + ry));
    for (var yy = y0; yy < y1; yy++) {
      for (var xx = x0; xx < x1; xx++) {
        var nx = (xx + 0.5 - cx) / rx, ny = (yy + 0.5 - cy) / ry;
        if (nx * nx + ny * ny <= 1) setPixel(s, xx, yy, c.r, c.g, c.b, alpha);
      }
    }
  }

  /** Rounded rectangle rotated about its centre — used for pens, remotes, etc. */
  function fillRotatedRect(s, cx, cy, w, h, angleDeg, hex, radius, alpha) {
    var c = hexToRgb(hex);
    var a = angleDeg * Math.PI / 180;
    var cos = Math.cos(-a), sin = Math.sin(-a);
    var reach = Math.ceil(Math.sqrt(w * w + h * h) / 2) + 1;
    var r = Math.min(radius || 0, Math.min(w, h) / 2);
    for (var yy = Math.max(0, cy - reach); yy < Math.min(s.height, cy + reach); yy++) {
      for (var xx = Math.max(0, cx - reach); xx < Math.min(s.width, cx + reach); xx++) {
        var px = xx + 0.5 - cx, py = yy + 0.5 - cy;
        var lx = px * cos - py * sin, ly = px * sin + py * cos;   // into rect space
        var ax = Math.abs(lx), ay = Math.abs(ly);
        var hw = w / 2, hh = h / 2;
        if (ax > hw || ay > hh) continue;
        if (r > 0) {
          var ox = Math.max(0, ax - (hw - r)), oy = Math.max(0, ay - (hh - r));
          if (ox * ox + oy * oy > r * r) continue;
        }
        setPixel(s, xx | 0, yy | 0, c.r, c.g, c.b, alpha);
      }
    }
  }

  /** Convex/concave polygon fill via even-odd scanline crossing test. */
  function fillPolygon(s, pts, hex, alpha) {
    var c = hexToRgb(hex), i;
    var minY = Infinity, maxY = -Infinity, minX = Infinity, maxX = -Infinity;
    for (i = 0; i < pts.length; i++) {
      minY = Math.min(minY, pts[i][1]); maxY = Math.max(maxY, pts[i][1]);
      minX = Math.min(minX, pts[i][0]); maxX = Math.max(maxX, pts[i][0]);
    }
    for (var yy = Math.max(0, Math.floor(minY)); yy < Math.min(s.height, Math.ceil(maxY)); yy++) {
      for (var xx = Math.max(0, Math.floor(minX)); xx < Math.min(s.width, Math.ceil(maxX)); xx++) {
        var inside = false, px = xx + 0.5, py = yy + 0.5;
        for (i = 0, j = pts.length - 1; i < pts.length; j = i++) {
          var xi = pts[i][0], yi = pts[i][1], xj = pts[j][0], yj = pts[j][1];
          if (((yi > py) !== (yj > py)) && (px < (xj - xi) * (py - yi) / (yj - yi) + xi)) inside = !inside;
        }
        var j;
        if (inside) setPixel(s, xx, yy, c.r, c.g, c.b, alpha);
      }
    }
  }

  /** Thick line drawn as a chain of dots — used for cables and straps. */
  function strokePath(s, pts, thickness, hex, alpha) {
    for (var i = 1; i < pts.length; i++) {
      var a = pts[i - 1], b = pts[i];
      var dist = Math.hypot(b[0] - a[0], b[1] - a[1]);
      var steps = Math.max(1, Math.ceil(dist));
      for (var t = 0; t <= steps; t++) {
        var x = a[0] + (b[0] - a[0]) * (t / steps);
        var y = a[1] + (b[1] - a[1]) * (t / steps);
        fillEllipse(s, x, y, thickness / 2, thickness / 2, hex, alpha);
      }
    }
  }

  /* -- texture -------------------------------------------------------------
   * Grain keeps sample rooms from looking like flat vector art, and gives the
   * segmenter something slightly imperfect to chew on (like a real photo). */

  function grain(s, amount, seed, region) {
    var rand = rng(seed || 7);
    var r = region || { x: 0, y: 0, w: s.width, h: s.height };
    var x1 = Math.min(s.width, r.x + r.w), y1 = Math.min(s.height, r.y + r.h);
    for (var yy = Math.max(0, r.y); yy < y1; yy++) {
      for (var xx = Math.max(0, r.x); xx < x1; xx++) {
        var i = (yy * s.width + xx) * 4;
        var n = (rand() - 0.5) * 2 * amount;
        s.data[i] += n; s.data[i + 1] += n; s.data[i + 2] += n;
      }
    }
  }

  /** Soft vertical light falloff — cheap "one lamp in the room" lighting. */
  function verticalShade(s, topAmt, bottomAmt) {
    for (var yy = 0; yy < s.height; yy++) {
      var t = yy / (s.height - 1);
      var amt = topAmt + (bottomAmt - topAmt) * t;
      if (Math.abs(amt) < 0.002) continue;
      var target = amt < 0 ? 0 : 255, p = Math.abs(amt);
      for (var xx = 0; xx < s.width; xx++) {
        var i = (yy * s.width + xx) * 4;
        s.data[i] += (target - s.data[i]) * p;
        s.data[i + 1] += (target - s.data[i + 1]) * p;
        s.data[i + 2] += (target - s.data[i + 2]) * p;
      }
    }
  }

  /* -- resampling ----------------------------------------------------------
   * Box-filter downscale. The detector always analyses a small copy of the
   * world; this is the one place image size is reduced, so speed/accuracy
   * trade-offs all funnel through here. */

  function resize(src, w, h) {
    var out = createSurface(w, h);
    var sx = src.width / w, sy = src.height / h;
    for (var y = 0; y < h; y++) {
      var y0 = Math.floor(y * sy), y1 = Math.max(y0 + 1, Math.floor((y + 1) * sy));
      for (var x = 0; x < w; x++) {
        var x0 = Math.floor(x * sx), x1 = Math.max(x0 + 1, Math.floor((x + 1) * sx));
        var r = 0, g = 0, b = 0, n = 0;
        for (var yy = y0; yy < y1 && yy < src.height; yy++) {
          for (var xx = x0; xx < x1 && xx < src.width; xx++) {
            var i = (yy * src.width + xx) * 4;
            r += src.data[i]; g += src.data[i + 1]; b += src.data[i + 2]; n++;
          }
        }
        var o = (y * w + x) * 4;
        out.data[o] = r / n; out.data[o + 1] = g / n; out.data[o + 2] = b / n; out.data[o + 3] = 255;
      }
    }
    return out;
  }

  /** Copy a rectangular window out of a surface (used for panorama frames). */
  function crop(src, x, y, w, h) {
    var out = createSurface(w, h);
    for (var yy = 0; yy < h; yy++) {
      for (var xx = 0; xx < w; xx++) {
        var sxp = Math.min(src.width - 1, Math.max(0, x + xx));
        var syp = Math.min(src.height - 1, Math.max(0, y + yy));
        var i = (syp * src.width + sxp) * 4, o = (yy * w + xx) * 4;
        out.data[o] = src.data[i]; out.data[o + 1] = src.data[i + 1];
        out.data[o + 2] = src.data[i + 2]; out.data[o + 3] = 255;
      }
    }
    return out;
  }

  NS.Raster = {
    rng: rng,
    hexToRgb: hexToRgb, rgbToHex: rgbToHex, shade: shade, mix: mix,
    createSurface: createSurface, setPixel: setPixel, getPixel: getPixel,
    fillRect: fillRect, fillRoundRect: fillRoundRect, fillEllipse: fillEllipse,
    fillRotatedRect: fillRotatedRect, fillPolygon: fillPolygon, strokePath: strokePath,
    grain: grain, verticalShade: verticalShade, resize: resize, crop: crop
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = NS.Raster;
})(typeof globalThis !== 'undefined' ? globalThis : this);
