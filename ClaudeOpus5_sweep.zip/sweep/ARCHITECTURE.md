# Architecture

How Sweep is put together, why it is put together that way, and where to change
things.

---

## The shape of it

One pipeline, running left to right, re-entered whenever something changes:

```
  a picture              regions            named objects         ranked results
      │                     │                     │                     │
   segment  ─────────▶   merge   ─────────▶   describe  ─────────▶   search
      │                     │                     │                     │
 colour lookup      touching + contained    oriented box,          words, colour,
 per pixel          regions joined          shape rules,           shape, size
                                            colour, size
                                                 │
                            ┌────────────────────┴──────────────┐
                            │                                   │
                    sample room:                        camera frame:
                    name from answer key                guess from catalogue
                    "labelled", 70–98%                  "best guess", 26–55%
```

Pictures come from one of three places, and the rest of the pipeline cannot tell
them apart:

- a **sample room**, drawn at load time by `raster.js`
- a **panorama**, stitched from a sweep across a room or from camera frames
- a **live camera frame**

### Modules

Each file has one job and depends only on the ones above it. They attach to a
single global, `window.Sweep`, and also export through `module.exports` so the
tests can require them in Node.

| File | Job | Depends on |
|---|---|---|
| `raster.js` | Draw pixels into an array. Shapes, blur-free edges, seeded randomness, resize, crop. No DOM at all. | — |
| `data.js` | Vocabulary and content: colours, shapes, sizes, the 39-object catalogue, three rooms with answer keys, sample searches and history. | raster |
| `vision.js` | Find objects in a picture and describe them. The whole detector. | raster, data |
| `search.js` | Turn a query into a ranked, explained list. Never touches pixels. | data |
| `scan.js` | Sweeping, frame matching, panorama stitching, camera access. | raster, data |
| `ui.js` | Every canvas drawing operation and every DOM node built. | data, vision |
| `app.js` | State, event wiring, and the order things happen in. | all |

`index.html` loads them in exactly that order. The dependency graph is acyclic and
enforced by the load order — if a module reaches upward it breaks immediately.

### The one rule in `app.js`

Changing a **colour or shape filter re-runs detection**; changing **words re-runs
only the ranking**. Colour and shape are applied inside the detector, so they change
what gets found. Words are applied afterwards, so they only change the order.

Nothing draws directly from an event handler. Handlers change state and request a
frame; a single `requestAnimationFrame` loop does all drawing. This keeps a burst of
events — dragging, typing — from queueing up redundant repaints.

---

## Decisions worth explaining

### Why the detector is hand-written

The brief asked for something more accurate than `lite_mobilenet_v2`, and also for
no external libraries. Those two together rule out TensorFlow.js, which rules out
any pretrained network. The options were:

1. Ship a neural network's weights as a JavaScript file. Megabytes of numbers, and
   writing the inference code by hand anyway.
2. Fake it — hard-code what is in each sample room and pretend to detect.
3. Write a real, if old-fashioned, computer-vision pipeline.

Option 3 is what is here. It is honest: the pipeline reads real pixels and finds
real objects, and it is measurably good at that. What it cannot do is recognise
objects it has never seen, which is exactly what a neural network is for — so that
weakness is labelled in the interface rather than hidden.

### Sample rooms are rendered, not drawn as diagrams

`data.js` describes each room as a list of objects with positions, colours and
forms; `raster.js` renders them into a pixel buffer. The detector then has to find
them the same way it would find anything else.

This is what makes the accuracy numbers meaningful. Because the room description is
also the answer key, the app can mark its own work — which is where the accuracy
card in the Log tab comes from, and how the test suite measures regressions.

### Colour is a lookup table

Naming a colour well means converting sRGB to a perceptual space (CIE Lab) and
comparing against reference colours by ΔE. That is far too slow per pixel per frame.

So it is done once, up front, for every colour the table can represent, and the
result is stored. After that, naming a pixel's colour is one array read.

The table size is the accuracy dial: 4, 5 or 6 bits per channel gives 4,096, 32,768
or 262,144 entries. Building the biggest takes about 124 ms, which is why the table
is built in slices across animation frames with a progress bar rather than freezing
the page.

This is the "slower to load, quicker afterwards" trade the brief asked for, made
explicit as a three-way choice in the interface.

### Minimum-area boxes, not principal axes

Objects are boxed by rotating a candidate box through 12 coarse angles and 6 refine
angles and keeping the tightest.

The first implementation used image moments to find the principal axis, which is
faster and standard — and wrong for symmetric objects. A square has no principal
axis, so the maths picked the diagonal, and the square came out measured corner to
corner with a 50% fill ratio, which the shape rules then read as "irregular". The
rotating box has no such degeneracy. It costs a few milliseconds and it is why
shape naming reaches 100%.

### Shape is a rulebook, in order

`decideShape()` is a deliberately readable ladder — ring, very elongated, ragged,
box, circle, triangular, irregular — reading four measurements: fill ratio, aspect
ratio, corner occupancy on a 4×4 grid, and perimeter roughness.

Order matters, and the ladder runs most specific first. A rulebook was chosen over
a trained classifier because it can be read, argued with, and corrected in one
place, and because every branch can be explained to a user in the results panel.

### Stitching matches edges, not brightness

Frames are aligned by normalised cross-correlation over horizontal *gradient*
profiles.

The first version correlated brightness, which worked fine on two rooms and failed
badly on the suitcase — 290 px out — because a quilted lining repeats, so every
alignment looks equally good. Gradients are exposure-invariant and much sharper
peaked. A motion-continuity fallback covers the rest: when confidence drops and the
estimate disagrees wildly with the recent pace of the pan, the pace wins.

Zero is a legal answer, which is how a camera being held still is recognised. That
came out of a test: without it, a stationary camera produced a confident 271-pixel
shift and would have quietly corrupted the panorama.

### Search explains itself

Scoring is a weighted sum over only the criteria you actually used — text 0.50,
colour 0.25, shape 0.18, size 0.07, renormalised — with hard multipliers that sink a
result which flatly fails something you explicitly asked for. Anything at or above
0.55 is a match.

Every result carries the reason chips that produced its score, so a surprising
ranking can be understood rather than merely disbelieved.

Words are tiered by where they came from: an object's own name outranks a nickname,
which outranks its category. This exists because a test caught "controller" matching
a TV remote — which lists it as a nickname — ahead of a game controller, which has
the word in its actual name.

### Highlighter yellow means exactly one thing

The interface is kraft paper and ink, and reserves a single saturated yellow for
found objects. It appears as a marker swipe on the picture, behind matched names in
the list, as ticks on the room strip, and nowhere else. The rule holds throughout:
if it is yellow, it is an answer to what you asked.

---

## Changing things

### Add a room

In `data.js`, add an entry to `ROOMS`. Objects are declared with `it({...})`:

```js
{
  id: 'garage', name: 'Garage shelf', blurb: 'Where tools go to hide.',
  width: 1600, height: 620, viewportFrac: 0.44,
  surface: '#8a8578', texture: 'concrete',
  items: [
    it({ id: 'g-tape', catalog: 'tape', name: 'Tape measure',
         color: 'yellow', shape: 'square',
         form: 'roundrect', x: 220, y: 300, w: 120, h: 118, radius: 14,
         where: 'left end of the shelf' })
  ]
}
```

`color` and `shape` are the answer key, so they must describe what the thing
actually looks like once drawn — the accuracy score is measured against them. The
room appears in the picker, gets ground truth, and joins the test suite
automatically. Run `node tests/run.js`: if a shape annotation disagrees with the
silhouette, the suite says so.

`where` is the plain-English location shown in results. Write it as you would say
it out loud.

### Add an object to the catalogue

`CATALOG` in `data.js`. This is what live camera guessing draws on:

```js
{ id: 'stapler', name: 'Stapler', cat: 'Stationery',
  syn: ['staple gun'],
  shapes: { long: 1, rectangular: 0.7 },   // how well each shape fits
  aspect: [2.2, 3.4],                      // width ÷ height range
  hFrac:  [0.08, 0.18] }                   // height as a fraction of the frame
```

Tighter ranges score higher when they match, because scoring rewards specificity —
an entry that claims to fit everything wins nothing.

Synonyms are worth adding generously; they are what makes a search feel forgiving.
They rank just below the object's own name.

### Add a shape

Three places: the `SHAPES` list in `data.js` (id, label, plain-English hint), a row
and column in `SHAPE_SIM` so partial credit against neighbouring shapes is defined,
and a branch in `decideShape()` in `vision.js`.

Put the new branch in the ladder at the point where it is more specific than what
follows it. Then run the tests — every existing room checks its shape annotations,
so a rule that steals cases from another rule shows up immediately.

### Add a colour

`COLORS` in `data.js` holds reference colours; `COLOR_GROUPS` folds them into what
people actually search for (several reference reds, one "red" chip). `COLOR_WORDS`
maps typed synonyms. Add to all three. The lookup table rebuilds itself; nothing
else needs touching.

### Add a search field

Four edits: a scorer in `search.js` returning 0–1 or `null` when not asked for, a
weight in `WEIGHTS`, a line in `buildCriteria()`, and a chip row in `app.js`'s
`buildChips()`.

Decide one thing: does it filter pixels or rank results? If it can be judged before
naming — like colour and shape — pass it through the detector's `prefilter` option
and call `runDetection()` when it changes. If it only reorders, call `runSearch()`,
which is much cheaper.

### Swap in a real neural network

One function: `guessObject()` in `vision.js`. It receives a region's measurements
and returns a ranked list of `{ id, name, pct }`.

Everything upstream — segmentation, boxes, colours, shapes — already gives a model
exactly what it wants: tight crops of individual objects rather than a whole cluttered
room. Crop each detection's box from the source, run the model, and return its top-k
in the same shape. Search, ranking, highlighting and the interface need no changes.

The confidence badges would want revisiting: `labelSource` currently switches between
`labelled` and `best guess`, and a real model would deserve its own third state.

### Restyle it

Design tokens live at the top of `styles.css`. The colour rule is the one thing to
preserve: `--hl` is for found objects and nothing else. `ui.js` mirrors a handful of
those values as constants — `HL`, `INK`, `PAPER`, `SLATE`, `FLAG` — because canvas
cannot read CSS variables; change both or the picture and the page will drift apart.

---

## Assumptions

**About the pictures.** Objects differ in colour from the surface under them.
Lighting is roughly even. The camera looks more or less straight on — no correction
is applied for perspective or rotation. Sweeps pan horizontally at a fairly steady
pace; vertical panning is not handled.

**About objects.** Each is one connected region of similar colour. Two touching
objects of the same colour become one, and a strongly patterned object may split
into several. Objects are assumed not to be stacked or heavily occluded — a thing
half under a hoodie is measured as the part you can see.

**About names.** In sample rooms names come from the answer key. On camera input
they come from a 39-entry catalogue and are frequently wrong; the interface says so
rather than hiding it. Anything outside that catalogue can still be found, measured
and searched by colour, shape and size — it just cannot be named.

**About the platform.** Canvas 2D, `requestAnimationFrame`, and ES5-era JavaScript
with a few ES2015 conveniences. No modules, so it runs from `file://`. `localStorage`
is treated as optional and falls back to memory. `getUserMedia` needs a secure
context, and its absence is handled as a normal condition rather than an error.

**About people.** Written for middle school and up: no jargon in the interface, no
empty states, plain-English locations, and honest uncertainty over confident
nonsense. Everything the app annotates can be switched off by someone who finds it
noisy.

---

## How the tests are built

`tests/harness.js` contains a miniature browser — an HTML parser, a DOM with events
and class lists, a canvas 2D stub that counts drawing calls, and a fake clock
driving both timers and animation frames. `bootApp()` parses the real `index.html`,
reads the `<script>` tags out of it, and runs the real files in a `vm` sandbox.

This matters more than it might sound. Because the test boots the actual markup, an
id renamed in `app.js` but not in `index.html` fails the suite instead of failing on
someone's first page load. Because the clock is fake, a seven-frame sweep with
320 ms between frames runs instantly and deterministically.

`engine.test.js` measures the pipeline against the answer keys with per-detector
floors set just below current scores — ordinary variation passes, a real regression
does not. `ui.test.js` drives the interface: every toggle, every tab, both filter
kinds, dragging, sweeping, switching rooms and detectors, and a missing camera.

When adding a feature, add it to `ui.test.js` by clicking it the way a person would.
The harness is the reason that is cheap to do.
