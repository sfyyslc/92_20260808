/* ============================================================================
 * Sweep — data.js
 * ----------------------------------------------------------------------------
 * All of the app's vocabulary and sample content:
 *
 *   COLOURS   the 21 reference colours the detector can name, folded into 13
 *             searchable colour families (navy and sky both answer to "blue")
 *   SHAPES    the shape words the detector can assign, plus a similarity table
 *             so searching "rectangular" still half-matches a square
 *   CATALOG   ~34 everyday object profiles. Used to *guess* what a detected
 *             region is when there is no ground truth (i.e. live camera)
 *   ROOMS     three procedurally drawn rooms — a study desk, a bedroom floor
 *             and an open suitcase — rendered as real pixels by raster.js
 *
 * The rooms carry ground-truth boxes. That is what makes the Accuracy panel
 * possible: the app scores its own detector against the answer key.
 * ==========================================================================*/
(function (global) {
  'use strict';

  var NS = global.Sweep || (global.Sweep = {});
  var R = NS.Raster || (typeof require === 'function' ? require('./raster.js') : null);

  /* ==========================================================================
   * 1. COLOUR VOCABULARY
   * ========================================================================*/

  /* Reference colours. `group` is the family a shopper would actually type
   * into a search box. Segmentation happens on the group, not the exact name,
   * so a two-tone navy backpack stays one object. */
  var COLORS = [
    { name: 'red',      hex: '#d64545', group: 'red' },
    { name: 'crimson',  hex: '#a12b34', group: 'red' },
    { name: 'orange',   hex: '#e08a3c', group: 'orange' },
    { name: 'yellow',   hex: '#e8c341', group: 'yellow' },
    { name: 'olive',    hex: '#7d8a3a', group: 'green' },
    { name: 'green',    hex: '#46a05a', group: 'green' },
    { name: 'teal',     hex: '#2f9e94', group: 'teal' },
    { name: 'sky',      hex: '#58b6d8', group: 'blue' },
    { name: 'blue',     hex: '#3b6fd4', group: 'blue' },
    { name: 'navy',     hex: '#24386e', group: 'blue' },
    { name: 'purple',   hex: '#7b46c9', group: 'purple' },
    { name: 'lavender', hex: '#a97ce0', group: 'purple' },
    { name: 'magenta',  hex: '#b3479f', group: 'pink' },
    { name: 'pink',     hex: '#e07aa5', group: 'pink' },
    { name: 'brown',    hex: '#8a5a35', group: 'brown' },
    { name: 'beige',    hex: '#cbab7f', group: 'beige' },
    { name: 'black',    hex: '#1c1c20', group: 'black' },
    { name: 'charcoal', hex: '#3a3d44', group: 'black' },
    { name: 'gray',     hex: '#8b9099', group: 'gray' },
    { name: 'silver',   hex: '#c2c7cf', group: 'gray' },
    { name: 'white',    hex: '#f2f4f7', group: 'white' }
  ];

  /* The 13 families offered as filter chips, in a sensible visual order. */
  var COLOR_GROUPS = [
    { id: 'red',    label: 'Red',    swatch: '#d64545' },
    { id: 'orange', label: 'Orange', swatch: '#e08a3c' },
    { id: 'yellow', label: 'Yellow', swatch: '#e8c341' },
    { id: 'green',  label: 'Green',  swatch: '#46a05a' },
    { id: 'teal',   label: 'Teal',   swatch: '#2f9e94' },
    { id: 'blue',   label: 'Blue',   swatch: '#3b6fd4' },
    { id: 'purple', label: 'Purple', swatch: '#7b46c9' },
    { id: 'pink',   label: 'Pink',   swatch: '#e07aa5' },
    { id: 'brown',  label: 'Brown',  swatch: '#8a5a35' },
    { id: 'beige',  label: 'Beige',  swatch: '#cbab7f' },
    { id: 'gray',   label: 'Grey',   swatch: '#8b9099' },
    { id: 'black',  label: 'Black',  swatch: '#1c1c20' },
    { id: 'white',  label: 'White',  swatch: '#f2f4f7' }
  ];

  /* Words people type that should resolve to a family. */
  var COLOR_WORDS = {
    red: 'red', crimson: 'red', maroon: 'red', scarlet: 'red', burgundy: 'red',
    orange: 'orange', amber: 'orange', rust: 'orange', peach: 'orange',
    yellow: 'yellow', gold: 'yellow', golden: 'yellow', mustard: 'yellow', lemon: 'yellow',
    green: 'green', olive: 'green', lime: 'green', mint: 'green', emerald: 'green',
    teal: 'teal', turquoise: 'teal', cyan: 'teal', aqua: 'teal',
    blue: 'blue', navy: 'blue', sky: 'blue', cobalt: 'blue', denim: 'blue',
    purple: 'purple', violet: 'purple', lavender: 'purple', lilac: 'purple', indigo: 'purple',
    pink: 'pink', magenta: 'pink', rose: 'pink', fuchsia: 'pink', salmon: 'pink',
    brown: 'brown', chocolate: 'brown', tan: 'brown', bronze: 'brown', wooden: 'brown',
    beige: 'beige', cream: 'beige', khaki: 'beige', ivory: 'beige', sand: 'beige',
    gray: 'gray', grey: 'gray', silver: 'gray', steel: 'gray', slate: 'gray',
    black: 'black', charcoal: 'black', dark: 'black',
    white: 'white', pale: 'white', snow: 'white'
  };

  /* ==========================================================================
   * 2. SHAPE VOCABULARY
   * ========================================================================*/

  var SHAPES = [
    { id: 'rectangular', label: 'Rectangular', hint: 'phone, book, wallet' },
    { id: 'square',      label: 'Square',      hint: 'case, sticky notes' },
    { id: 'round',       label: 'Round',       hint: 'mug, ball, plate' },
    { id: 'oval',        label: 'Oval',        hint: 'glasses case, shoe' },
    { id: 'long',        label: 'Long & thin', hint: 'pen, bottle, cable' },
    { id: 'triangular',  label: 'Triangular',  hint: 'slice, hanger' },
    { id: 'irregular',   label: 'Irregular',   hint: 'keys, clothes, cable' }
  ];

  /* How well shape A satisfies a search for shape B. 1 = same word.
   * A person hunting a "rectangular" phone should still see squares. */
  var SHAPE_SIM = {
    rectangular: { rectangular: 1, square: 0.72, long: 0.6, oval: 0.3, round: 0.15, triangular: 0.2, irregular: 0.35 },
    square:      { square: 1, rectangular: 0.72, round: 0.4, oval: 0.25, long: 0.12, triangular: 0.2, irregular: 0.3 },
    round:       { round: 1, oval: 0.75, square: 0.4, irregular: 0.35, rectangular: 0.15, long: 0.1, triangular: 0.2 },
    oval:        { oval: 1, round: 0.75, long: 0.45, rectangular: 0.3, irregular: 0.4, square: 0.25, triangular: 0.2 },
    long:        { long: 1, rectangular: 0.6, oval: 0.45, irregular: 0.35, square: 0.12, round: 0.1, triangular: 0.2 },
    triangular:  { triangular: 1, irregular: 0.45, oval: 0.25, rectangular: 0.2, square: 0.2, round: 0.2, long: 0.2 },
    irregular:   { irregular: 1, oval: 0.4, round: 0.35, long: 0.35, rectangular: 0.35, square: 0.3, triangular: 0.45 }
  };

  /* Size buckets, measured as detected height ÷ frame height. */
  var SIZES = [
    { id: 'small',  label: 'Small',  range: [0.00, 0.16], hint: 'keys, earbuds' },
    { id: 'medium', label: 'Medium', range: [0.14, 0.34], hint: 'phone, mug' },
    { id: 'large',  label: 'Large',  range: [0.30, 1.00], hint: 'backpack, laptop' }
  ];

  /* ==========================================================================
   * 3. OBJECT CATALOGUE
   * Feature profiles used to name a region when nothing else knows better.
   *   shapes  – shape word → how typical it is for this object
   *   aspect  – long side ÷ short side
   *   hFrac   – height ÷ frame height, at a normal arm's-length scan
   * ========================================================================*/
  var CATALOG = [
    { id: 'phone', name: 'Phone', cat: 'Electronics', syn: ['mobile', 'cell', 'cellphone', 'smartphone', 'iphone', 'android'],
      shapes: { rectangular: 1, square: 0.4, long: 0.5 }, aspect: [1.6, 2.4], hFrac: [0.12, 0.28] },
    { id: 'tablet', name: 'Tablet', cat: 'Electronics', syn: ['ipad', 'kindle', 'e-reader'],
      shapes: { rectangular: 1, square: 0.6 }, aspect: [1.2, 1.6], hFrac: [0.28, 0.55] },
    { id: 'laptop', name: 'Laptop', cat: 'Electronics', syn: ['notebook computer', 'macbook', 'chromebook'],
      shapes: { rectangular: 1, square: 0.5 }, aspect: [1.2, 1.8], hFrac: [0.45, 0.9] },
    { id: 'remote', name: 'TV remote', cat: 'Electronics', syn: ['remote control', 'clicker', 'controller'],
      shapes: { rectangular: 1, long: 0.85 }, aspect: [2.6, 5.0], hFrac: [0.18, 0.36] },
    { id: 'gamepad', name: 'Game controller', cat: 'Electronics', syn: ['gamepad', 'joystick', 'xbox', 'playstation'],
      shapes: { irregular: 1, oval: 0.6, rectangular: 0.3 }, aspect: [1.2, 2.0], hFrac: [0.12, 0.28] },
    { id: 'earbuds', name: 'Earbuds case', cat: 'Electronics', syn: ['airpods', 'earphones', 'buds', 'headphone case'],
      shapes: { square: 1, round: 0.6, rectangular: 0.5 }, aspect: [1.0, 1.3], hFrac: [0.06, 0.15] },
    { id: 'headphones', name: 'Headphones', cat: 'Electronics', syn: ['cans', 'over-ear', 'headset'],
      shapes: { round: 1, irregular: 0.8, oval: 0.6 }, aspect: [1.0, 1.4], hFrac: [0.18, 0.4] },
    { id: 'charger', name: 'Charger cable', cat: 'Electronics', syn: ['cable', 'cord', 'lead', 'wire', 'usb', 'lightning'],
      shapes: { irregular: 1, long: 0.9 }, aspect: [1.5, 6.0], hFrac: [0.1, 0.5] },
    { id: 'powerbrick', name: 'Charger plug', cat: 'Electronics', syn: ['adapter', 'plug', 'power brick', 'wall charger'],
      shapes: { square: 1, rectangular: 0.7 }, aspect: [1.0, 1.4], hFrac: [0.07, 0.16] },
    { id: 'camera', name: 'Camera', cat: 'Electronics', syn: ['dslr', 'point and shoot', 'gopro'],
      shapes: { rectangular: 1, square: 0.6 }, aspect: [1.3, 1.9], hFrac: [0.12, 0.3] },
    { id: 'mouse', name: 'Mouse', cat: 'Electronics', syn: ['computer mouse'],
      shapes: { oval: 1, round: 0.5, irregular: 0.4 }, aspect: [1.4, 1.9], hFrac: [0.08, 0.18] },
    { id: 'wallet', name: 'Wallet', cat: 'Everyday carry', syn: ['purse', 'billfold', 'cardholder', 'card holder'],
      shapes: { rectangular: 1, square: 0.5 }, aspect: [1.3, 1.7], hFrac: [0.1, 0.24] },
    { id: 'keys', name: 'Keys', cat: 'Everyday carry', syn: ['keychain', 'keyring', 'house key', 'car key'],
      shapes: { irregular: 1, long: 0.5 }, aspect: [1.1, 2.6], hFrac: [0.05, 0.16] },
    { id: 'glasses', name: 'Glasses', cat: 'Everyday carry', syn: ['spectacles', 'eyeglasses', 'sunglasses', 'specs'],
      shapes: { oval: 1, long: 0.7, irregular: 0.6 }, aspect: [2.0, 3.4], hFrac: [0.06, 0.16] },
    { id: 'glassescase', name: 'Glasses case', cat: 'Everyday carry', syn: ['spectacle case', 'sunglasses case'],
      shapes: { oval: 1, long: 0.6, rectangular: 0.5 }, aspect: [1.9, 3.0], hFrac: [0.07, 0.18] },
    { id: 'watch', name: 'Watch', cat: 'Everyday carry', syn: ['wristwatch', 'smartwatch', 'fitbit'],
      shapes: { round: 1, irregular: 0.6, square: 0.5 }, aspect: [1.0, 1.5], hFrac: [0.05, 0.14] },
    { id: 'passport', name: 'Passport', cat: 'Travel', syn: ['travel document', 'id book'],
      shapes: { rectangular: 1 }, aspect: [1.3, 1.6], hFrac: [0.1, 0.24] },
    { id: 'ticket', name: 'Cards & tickets', cat: 'Travel', syn: ['boarding pass', 'card', 'id card', 'bank card'],
      shapes: { rectangular: 1 }, aspect: [1.5, 2.2], hFrac: [0.04, 0.12] },
    { id: 'suitcasekey', name: 'Padlock', cat: 'Travel', syn: ['lock', 'tsa lock'],
      shapes: { square: 1, round: 0.6 }, aspect: [1.0, 1.4], hFrac: [0.04, 0.12] },
    { id: 'book', name: 'Book', cat: 'Study', syn: ['notebook', 'textbook', 'journal', 'diary', 'binder', 'novel'],
      shapes: { rectangular: 1, square: 0.6 }, aspect: [1.2, 1.6], hFrac: [0.24, 0.5] },
    { id: 'stickynotes', name: 'Sticky notes', cat: 'Study', syn: ['post-it', 'postit', 'notes', 'memo pad'],
      shapes: { square: 1, rectangular: 0.6 }, aspect: [1.0, 1.2], hFrac: [0.08, 0.2] },
    { id: 'pen', name: 'Pen', cat: 'Study', syn: ['pencil', 'biro', 'marker', 'highlighter', 'sharpie'],
      shapes: { long: 1, rectangular: 0.5, irregular: 0.3 }, aspect: [5.0, 14.0], hFrac: [0.02, 0.12] },
    { id: 'scissors', name: 'Scissors', cat: 'Study', syn: ['shears', 'snips'],
      shapes: { irregular: 1, long: 0.7 }, aspect: [1.6, 3.2], hFrac: [0.14, 0.34] },
    { id: 'calculator', name: 'Calculator', cat: 'Study', syn: ['casio', 'graphing calculator'],
      shapes: { rectangular: 1 }, aspect: [1.7, 2.4], hFrac: [0.14, 0.3] },
    { id: 'ruler', name: 'Ruler', cat: 'Study', syn: ['straight edge', 'measure'],
      shapes: { long: 1, rectangular: 0.7 }, aspect: [6.0, 16.0], hFrac: [0.02, 0.1] },
    { id: 'mug', name: 'Mug', cat: 'Kitchen', syn: ['cup', 'coffee', 'tea', 'coffee cup'],
      shapes: { round: 1, oval: 0.6, irregular: 0.4 }, aspect: [1.0, 1.35], hFrac: [0.1, 0.26] },
    { id: 'bottle', name: 'Water bottle', cat: 'Kitchen', syn: ['flask', 'drink', 'thermos', 'canteen'],
      shapes: { long: 1, rectangular: 0.6, oval: 0.4 }, aspect: [2.4, 4.5], hFrac: [0.25, 0.6] },
    { id: 'plate', name: 'Plate or bowl', cat: 'Kitchen', syn: ['bowl', 'dish', 'saucer'],
      shapes: { round: 1, oval: 0.5 }, aspect: [1.0, 1.25], hFrac: [0.18, 0.45] },
    { id: 'fruit', name: 'Fruit', cat: 'Kitchen', syn: ['apple', 'orange', 'banana', 'snack'],
      shapes: { round: 1, oval: 0.7, irregular: 0.4 }, aspect: [1.0, 1.6], hFrac: [0.07, 0.2] },
    { id: 'shoe', name: 'Shoe', cat: 'Clothing', syn: ['sneaker', 'trainer', 'boot', 'sandal', 'slipper'],
      shapes: { oval: 1, irregular: 0.8, long: 0.5 }, aspect: [2.0, 3.2], hFrac: [0.14, 0.36] },
    { id: 'sock', name: 'Sock', cat: 'Clothing', syn: ['socks', 'stocking'],
      shapes: { oval: 1, irregular: 0.7, round: 0.5 }, aspect: [1.2, 2.4], hFrac: [0.07, 0.2] },
    { id: 'clothes', name: 'Clothing', cat: 'Clothing', syn: ['hoodie', 'shirt', 'jumper', 'sweater', 't-shirt', 'jacket', 'towel'],
      shapes: { irregular: 1, oval: 0.5, rectangular: 0.4 }, aspect: [1.0, 2.2], hFrac: [0.25, 0.7] },
    { id: 'hat', name: 'Hat', cat: 'Clothing', syn: ['cap', 'beanie', 'baseball cap'],
      shapes: { round: 1, oval: 0.7, irregular: 0.5 }, aspect: [1.0, 1.5], hFrac: [0.14, 0.32] },
    { id: 'bag', name: 'Bag', cat: 'Clothing', syn: ['backpack', 'rucksack', 'tote', 'handbag', 'pouch', 'toiletry bag'],
      shapes: { rectangular: 1, irregular: 0.8, oval: 0.5, square: 0.6 }, aspect: [1.0, 1.6], hFrac: [0.3, 0.8] },
    { id: 'toothbrush', name: 'Toothbrush', cat: 'Bathroom', syn: ['brush', 'dental'],
      shapes: { long: 1 }, aspect: [5.0, 12.0], hFrac: [0.03, 0.12] },
    { id: 'toiletries', name: 'Bottle of toiletries', cat: 'Bathroom', syn: ['sunscreen', 'shampoo', 'lotion', 'deodorant', 'sunblock'],
      shapes: { long: 1, rectangular: 0.6, oval: 0.5 }, aspect: [2.0, 4.0], hFrac: [0.16, 0.4] },
    { id: 'medicine', name: 'Medicine bottle', cat: 'Bathroom', syn: ['pills', 'tablets', 'inhaler', 'prescription'],
      shapes: { rectangular: 1, long: 0.7, round: 0.4 }, aspect: [1.4, 2.6], hFrac: [0.07, 0.18] },
    { id: 'hairbrush', name: 'Hairbrush', cat: 'Bathroom', syn: ['comb', 'brush'],
      shapes: { oval: 1, long: 0.8, irregular: 0.5 }, aspect: [2.2, 4.0], hFrac: [0.12, 0.3] },
    { id: 'belt', name: 'Belt', cat: 'Clothing', syn: ['strap'],
      shapes: { round: 1, irregular: 0.9, oval: 0.6 }, aspect: [1.0, 1.5], hFrac: [0.14, 0.34] }
  ];

  var CATALOG_BY_ID = {};
  CATALOG.forEach(function (c) { CATALOG_BY_ID[c.id] = c; });

  /* ==========================================================================
   * 4. ROOMS
   * Coordinates are in "world" pixels. Each room is far wider than the
   * viewport, which is the whole point: you sweep across it.
   * ========================================================================*/

  /** helper — build one item record */
  function it(o) { return o; }

  var ROOMS = [
    {
      id: 'desk',
      name: 'Study desk',
      blurb: 'Homework night. Twelve things on one desk.',
      width: 1760, height: 640,
      surface: { kind: 'wood', hex: '#8a5a35' },
      viewportFrac: 0.42,
      items: [
        it({ id: 'd-book', catalog: 'book', name: 'Notebook', color: 'blue', shape: 'rectangular',
             form: 'rect', x: 96, y: 208, w: 168, h: 214, radius: 6,
             where: 'far left end of the desk',
             details: [{ form: 'rect', dx: 12, dy: 12, w: 20, h: 190, shade: 0.22 }] }),
        it({ id: 'd-phone', catalog: 'phone', name: 'Phone', color: 'purple', shape: 'rectangular',
             form: 'roundrect', x: 316, y: 254, w: 68, h: 130, radius: 12,
             where: 'between the notebook and the red mug',
             details: [{ form: 'roundrect', dx: 7, dy: 9, w: 54, h: 104, radius: 6, shade: -0.24 }] }),
        it({ id: 'd-mug', catalog: 'mug', name: 'Mug', color: 'red', shape: 'round',
             form: 'ellipse', x: 428, y: 262, w: 108, h: 108,
             where: 'middle of the desk, right of the phone',
             details: [{ form: 'ellipse', dx: 22, dy: 22, w: 64, h: 64, shade: -0.18 }] }),
        it({ id: 'd-keys', catalog: 'keys', name: 'Keys', color: 'gray', shape: 'irregular',
             form: 'keys', x: 596, y: 404, w: 118, h: 74,
             where: 'near the front edge, in front of the wallet' }),
        it({ id: 'd-wallet', catalog: 'wallet', name: 'Wallet', color: 'black', shape: 'rectangular',
             form: 'rect', x: 700, y: 206, w: 134, h: 94, radius: 8,
             where: 'behind the keys, towards the back of the desk',
             details: [{ form: 'rect', dx: 0, dy: 44, w: 134, h: 7, shade: 0.16 }] }),
        it({ id: 'd-earbuds', catalog: 'earbuds', name: 'Earbuds case', color: 'white', shape: 'square',
             form: 'roundrect', x: 884, y: 300, w: 70, h: 68, radius: 18,
             where: 'centre of the desk, on its own' }),
        it({ id: 'd-bottle', catalog: 'bottle', name: 'Water bottle', color: 'green', shape: 'long',
             form: 'roundrect', x: 1006, y: 176, w: 78, h: 262, radius: 30,
             where: 'right of the earbuds case',
             details: [{ form: 'rect', dx: 0, dy: 8, w: 78, h: 26, shade: -0.22 }] }),
        it({ id: 'd-sticky', catalog: 'stickynotes', name: 'Sticky notes', color: 'yellow', shape: 'square',
             form: 'rect', x: 1136, y: 372, w: 96, h: 94, radius: 3,
             where: 'front of the desk, under the water bottle' }),
        it({ id: 'd-scissors', catalog: 'scissors', name: 'Scissors', color: 'teal', shape: 'irregular',
             form: 'scissors', x: 1262, y: 214, w: 104, h: 168, angle: 18,
             where: 'back right, next to the pen' }),
        it({ id: 'd-pen', catalog: 'pen', name: 'Pen', color: 'orange', shape: 'long',
             form: 'rotrect', x: 1316, y: 420, w: 168, h: 18, angle: -22, radius: 8,
             where: 'lying diagonally near the front right corner' }),
        it({ id: 'd-case', catalog: 'glassescase', name: 'Glasses case', color: 'pink', shape: 'oval',
             form: 'ellipse', x: 1462, y: 268, w: 148, h: 62,
             where: 'right side, above the pen' }),
        it({ id: 'd-remote', catalog: 'remote', name: 'TV remote', color: 'black', shape: 'long',
             form: 'roundrect', x: 1638, y: 220, w: 56, h: 186, radius: 16,
             where: 'far right end of the desk',
             details: [{ form: 'rect', dx: 12, dy: 24, w: 32, h: 40, shade: 0.2 }] })
      ]
    },

    {
      id: 'bedroom',
      name: 'Bedroom floor',
      blurb: 'Carpet, laundry, and something under the hoodie.',
      width: 1760, height: 640,
      surface: { kind: 'carpet', hex: '#b9a583' },
      viewportFrac: 0.42,
      items: [
        it({ id: 'b-hoodie', catalog: 'clothes', name: 'Hoodie', color: 'blue', shape: 'irregular',
             form: 'blob', x: 84, y: 208, w: 300, h: 268,
             where: 'dumped at the left edge of the carpet' }),
        it({ id: 'b-remote', catalog: 'remote', name: 'TV remote', color: 'black', shape: 'long',
             form: 'roundrect', x: 300, y: 420, w: 54, h: 178, radius: 14, angle: 0,
             where: 'poking out from under the hoodie',
             partly: true }),
        it({ id: 'b-sock', catalog: 'sock', name: 'Sock', color: 'white', shape: 'oval',
             form: 'ellipse', x: 448, y: 300, w: 128, h: 76, angle: 0,
             where: 'on its own between the hoodie and the controller' }),
        it({ id: 'b-pad', catalog: 'gamepad', name: 'Game controller', color: 'red', shape: 'oval',
             form: 'gamepad', x: 640, y: 268, w: 168, h: 116,
             where: 'middle of the carpet' }),
        it({ id: 'b-cable', catalog: 'charger', name: 'Charger cable', color: 'orange', shape: 'irregular',
             form: 'cable', x: 856, y: 236, w: 210, h: 200,
             where: 'coiled next to the controller' }),
        it({ id: 'b-shoe', catalog: 'shoe', name: 'Trainer', color: 'brown', shape: 'oval',
             form: 'shoe', x: 1096, y: 388, w: 224, h: 106,
             where: 'front of the carpet, right of the cable' }),
        it({ id: 'b-book', catalog: 'book', name: 'Library book', color: 'yellow', shape: 'rectangular',
             form: 'rect', x: 1128, y: 176, w: 186, h: 138, radius: 4, angle: 0,
             where: 'behind the trainer' }),
        it({ id: 'b-bottle', catalog: 'bottle', name: 'Water bottle', color: 'purple', shape: 'long',
             form: 'roundrect', x: 1372, y: 214, w: 74, h: 248, radius: 30,
             where: 'standing up on the right side' }),
        it({ id: 'b-apple', catalog: 'fruit', name: 'Apple', color: 'green', shape: 'round',
             form: 'ellipse', x: 1494, y: 402, w: 86, h: 86,
             where: 'right side, near the front' }),
        it({ id: 'b-brush', catalog: 'hairbrush', name: 'Hairbrush', color: 'pink', shape: 'oval',
             form: 'ellipse', x: 1600, y: 236, w: 92, h: 168,
             where: 'far right of the carpet' })
      ]
    },

    {
      id: 'suitcase',
      name: 'Open suitcase',
      blurb: 'Packed for a trip. Passport in here somewhere.',
      width: 1500, height: 620,
      surface: { kind: 'lining', hex: '#8b9099' },
      viewportFrac: 0.46,
      items: [
        it({ id: 's-shirt', catalog: 'clothes', name: 'Folded t-shirt', color: 'teal', shape: 'rectangular',
             form: 'rect', x: 78, y: 202, w: 228, h: 168, radius: 8,
             where: 'left compartment',
             details: [{ form: 'rect', dx: 0, dy: 80, w: 228, h: 8, shade: -0.2 }] }),
        it({ id: 's-passport', catalog: 'passport', name: 'Passport', color: 'blue', shape: 'rectangular',
             form: 'rect', x: 340, y: 258, w: 108, h: 148, radius: 4,
             where: 'tucked beside the t-shirt on the left',
             details: [{ form: 'rect', dx: 24, dy: 44, w: 60, h: 44, shade: 0.28 }] }),
        it({ id: 's-sockroll', catalog: 'sock', name: 'Rolled socks', color: 'red', shape: 'round',
             form: 'ellipse', x: 492, y: 300, w: 96, h: 92,
             where: 'middle left, rolled into a ball' }),
        it({ id: 's-charger', catalog: 'powerbrick', name: 'Charger plug', color: 'purple', shape: 'square',
             form: 'roundrect', x: 630, y: 316, w: 76, h: 74, radius: 10,
             where: 'centre of the case' }),
        it({ id: 's-sun', catalog: 'toiletries', name: 'Sunscreen', color: 'yellow', shape: 'long',
             form: 'roundrect', x: 752, y: 214, w: 62, h: 208, radius: 22,
             where: 'standing in the middle of the case' }),
        it({ id: 's-brush', catalog: 'toothbrush', name: 'Toothbrush', color: 'white', shape: 'long',
             form: 'rotrect', x: 848, y: 396, w: 186, h: 20, angle: -14, radius: 9,
             where: 'lying flat below the sunscreen' }),
        it({ id: 's-belt', catalog: 'belt', name: 'Belt', color: 'brown', shape: 'round',
             form: 'ring', x: 964, y: 210, w: 160, h: 160,
             where: 'coiled in the top right' }),
        it({ id: 's-pouch', catalog: 'bag', name: 'Toiletry bag', color: 'pink', shape: 'rectangular',
             form: 'roundrect', x: 1150, y: 236, w: 196, h: 142, radius: 16,
             where: 'right compartment',
             details: [{ form: 'rect', dx: 0, dy: 40, w: 196, h: 12, shade: -0.22 }] }),
        it({ id: 's-cam', catalog: 'camera', name: 'Camera', color: 'black', shape: 'rectangular',
             form: 'rect', x: 1156, y: 424, w: 132, h: 92, radius: 8,
             where: 'front right, below the toiletry bag',
             details: [{ form: 'ellipse', dx: 44, dy: 22, w: 46, h: 46, shade: 0.18 }] }),
        it({ id: 's-cans', catalog: 'headphones', name: 'Headphones', color: 'orange', shape: 'round',
             form: 'ring', x: 1330, y: 400, w: 130, h: 130,
             where: 'far right corner of the case' })
      ]
    }
  ];

  var ROOMS_BY_ID = {};
  ROOMS.forEach(function (r) { ROOMS_BY_ID[r.id] = r; });

  /* ==========================================================================
   * 5. ROOM RENDERER
   * Turns the item list above into actual pixels. Runs identically in the
   * browser and in Node, so the tests analyse the same image you see.
   * ========================================================================*/

  function colorHex(name) {
    for (var i = 0; i < COLORS.length; i++) if (COLORS[i].name === name) return COLORS[i].hex;
    return '#888888';
  }

  /** Axis-aligned bounds of an item, rotation included. */
  function itemBounds(item) {
    if (!item.angle) return { x: item.x, y: item.y, w: item.w, h: item.h };
    var a = Math.abs(item.angle * Math.PI / 180);
    var w = item.w * Math.cos(a) + item.h * Math.sin(a);
    var h = item.w * Math.sin(a) + item.h * Math.cos(a);
    return { x: item.x + (item.w - w) / 2, y: item.y + (item.h - h) / 2, w: w, h: h };
  }

  /** Draw the surface the objects are lying on. */
  function drawSurface(s, room) {
    var base = room.surface.hex;
    R.fillRect(s, 0, 0, s.width, s.height, base);

    if (room.surface.kind === 'wood') {
      // long grain lines, all within the same colour family as the desk
      var rand = R.rng(11);
      for (var y = 0; y < s.height; y += 7) {
        var amt = (rand() - 0.5) * 0.1;
        R.fillRect(s, 0, y, s.width, 3 + rand() * 3, R.shade(base, amt));
      }
      for (var k = 0; k < 26; k++) {
        var kx = rand() * s.width, ky = rand() * s.height;
        R.fillEllipse(s, kx, ky, 18 + rand() * 30, 3 + rand() * 4, R.shade(base, -0.07));
      }
    } else if (room.surface.kind === 'carpet') {
      var rc = R.rng(23);
      for (var i = 0; i < 5200; i++) {
        R.fillEllipse(s, rc() * s.width, rc() * s.height, 2 + rc() * 3, 1 + rc() * 2,
                      R.shade(base, (rc() - 0.5) * 0.14));
      }
    } else { // suitcase lining — quilted diagonal weave
      var rl = R.rng(31);
      for (var d = -s.height; d < s.width; d += 46) {
        R.strokePath(s, [[d, 0], [d + s.height, s.height]], 3, R.shade(base, -0.06));
        R.strokePath(s, [[d, s.height], [d + s.height, 0]], 3, R.shade(base, 0.05));
      }
      // case walls, so the sweep has landmarks
      R.fillRect(s, 0, 0, s.width, 62, R.shade(base, -0.16));
      R.fillRect(s, 0, s.height - 54, s.width, 54, R.shade(base, -0.16));
    }
    R.grain(s, 5, 3);
  }

  /** Draw one object. `form` picks the silhouette. */
  function drawItem(s, item) {
    var hex = colorHex(item.color);
    var b = itemBounds(item);

    // contact shadow: kept inside the surface's own colour family so it never
    // registers as a separate object
    var sh = { x: b.x - 6, y: b.y + b.h - 10, w: b.w + 12, h: 22 };
    shadowUnder(s, sh);

    switch (item.form) {
      case 'rect':
        R.fillRoundRect(s, item.x, item.y, item.w, item.h, item.radius || 0, hex); break;
      case 'roundrect':
        R.fillRoundRect(s, item.x, item.y, item.w, item.h, item.radius || 10, hex); break;
      case 'ellipse':
        R.fillEllipse(s, item.x + item.w / 2, item.y + item.h / 2, item.w / 2, item.h / 2, hex); break;
      case 'rotrect':
        R.fillRotatedRect(s, item.x + item.w / 2, item.y + item.h / 2, item.w, item.h,
                          item.angle || 0, hex, item.radius || 4); break;
      case 'ring': { // belt / headphones: thick torus
        var cx = item.x + item.w / 2, cy = item.y + item.h / 2;
        R.fillEllipse(s, cx, cy, item.w / 2, item.h / 2, hex);
        R.fillEllipse(s, cx, cy, item.w / 2 - 26, item.h / 2 - 26, R.shade(hex, -0.1));
        R.fillEllipse(s, cx, cy, item.w / 2 - 30, item.h / 2 - 30, hex);
        break;
      }
      case 'keys': { // a small ring plus three blades
        var kx = item.x, ky = item.y;
        R.fillEllipse(s, kx + 22, ky + 34, 22, 22, hex);
        R.fillEllipse(s, kx + 22, ky + 34, 12, 12, R.shade(hex, -0.35));
        R.fillRotatedRect(s, kx + 66, ky + 24, 66, 13, 8, hex, 4);
        R.fillRotatedRect(s, kx + 70, ky + 44, 72, 12, -12, hex, 4);
        R.fillRotatedRect(s, kx + 54, ky + 58, 48, 10, 26, hex, 4);
        break;
      }
      case 'scissors': {
        var sx = item.x, sy = item.y;
        R.fillRotatedRect(s, sx + 46, sy + 56, 20, 108, 12, hex, 8);
        R.fillRotatedRect(s, sx + 66, sy + 56, 20, 108, -12, hex, 8);
        R.fillEllipse(s, sx + 34, sy + 132, 26, 22, hex);
        R.fillEllipse(s, sx + 78, sy + 132, 26, 22, hex);
        R.fillEllipse(s, sx + 34, sy + 132, 13, 11, R.shade(hex, -0.4));
        R.fillEllipse(s, sx + 78, sy + 132, 13, 11, R.shade(hex, -0.4));
        break;
      }
      case 'gamepad': {
        var gx = item.x + item.w / 2, gy = item.y + item.h / 2;
        R.fillRoundRect(s, item.x + 34, item.y + 6, item.w - 68, item.h - 12, 26, hex);
        R.fillEllipse(s, item.x + 40, gy + 14, 42, 44, hex);
        R.fillEllipse(s, item.x + item.w - 40, gy + 14, 42, 44, hex);
        R.fillEllipse(s, gx - 30, gy - 6, 15, 15, R.shade(hex, -0.35));
        R.fillEllipse(s, gx + 30, gy - 6, 15, 15, R.shade(hex, -0.35));
        break;
      }
      case 'shoe': {
        var ex = item.x, ey = item.y;
        R.fillEllipse(s, ex + item.w * 0.55, ey + item.h * 0.6, item.w * 0.45, item.h * 0.4, hex);
        R.fillRoundRect(s, ex + 6, ey + item.h * 0.42, item.w * 0.72, item.h * 0.5, 22, hex);
        R.fillEllipse(s, ex + item.w * 0.42, ey + item.h * 0.3, item.w * 0.22, item.h * 0.3, hex);
        R.fillRect(s, ex + 6, ey + item.h - 20, item.w - 24, 16, R.shade(hex, 0.12));
        break;
      }
      case 'cable': {
        var p = [], cxx = item.x + item.w / 2, cyy = item.y + item.h / 2;
        for (var t = 0; t <= 62; t++) {
          var ang = t / 62 * Math.PI * 3.4;
          var rad = 24 + (t / 62) * (Math.min(item.w, item.h) / 2 - 18);
          p.push([cxx + Math.cos(ang) * rad, cyy + Math.sin(ang) * rad * 0.85]);
        }
        R.strokePath(s, p, 15, hex);
        break;
      }
      case 'blob': { // crumpled clothing
        var rb = R.rng(item.x | 0);
        var bx = item.x + item.w / 2, by = item.y + item.h / 2;
        for (var n = 0; n < 22; n++) {
          R.fillEllipse(s,
            bx + (rb() - 0.5) * item.w * 0.86,
            by + (rb() - 0.5) * item.h * 0.86,
            item.w * (0.07 + rb() * 0.15),
            item.h * (0.07 + rb() * 0.15),
            R.shade(hex, (rb() - 0.5) * 0.16));
        }
        // sleeves flung out to the sides
        R.strokePath(s, [[bx - item.w * 0.42, by - item.h * 0.1],
                         [bx - item.w * 0.18, by + item.h * 0.24],
                         [bx + item.w * 0.1, by + item.h * 0.42]], item.h * 0.17, hex);
        break;
      }
    }

    // sub-details are always a shade of the parent colour, so the merge pass
    // reunites them into a single object instead of reporting a "screen"
    (item.details || []).forEach(function (d) {
      var dhex = R.shade(hex, d.shade);
      if (d.form === 'ellipse') {
        R.fillEllipse(s, item.x + d.dx + d.w / 2, item.y + d.dy + d.h / 2, d.w / 2, d.h / 2, dhex);
      } else {
        R.fillRoundRect(s, item.x + d.dx, item.y + d.dy, d.w, d.h, d.radius || 0, dhex);
      }
    });
  }

  /** Darken a patch of whatever is already there (keeps the surface's hue). */
  function shadowUnder(s, r) {
    for (var y = Math.max(0, r.y | 0); y < Math.min(s.height, r.y + r.h); y++) {
      for (var x = Math.max(0, r.x | 0); x < Math.min(s.width, r.x + r.w); x++) {
        var nx = (x - (r.x + r.w / 2)) / (r.w / 2), ny = (y - (r.y + r.h / 2)) / (r.h / 2);
        var d = nx * nx + ny * ny;
        if (d > 1) continue;
        var a = (1 - d) * 0.13;                       // gentle: stays in-family
        var i = (y * s.width + x) * 4;
        s.data[i] *= (1 - a); s.data[i + 1] *= (1 - a); s.data[i + 2] *= (1 - a);
      }
    }
  }

  /** Render a whole room to a surface. Cached — rendering is not free. */
  var roomCache = {};
  function renderRoom(roomId) {
    if (roomCache[roomId]) return roomCache[roomId];
    var room = ROOMS_BY_ID[roomId];
    if (!room) throw new Error('Unknown room: ' + roomId);
    var s = R.createSurface(room.width, room.height);
    drawSurface(s, room);
    room.items.slice().sort(function (a, b) { return (a.y + a.h) - (b.y + b.h); })
        .forEach(function (item) { drawItem(s, item); });
    R.verticalShade(s, 0.05, -0.09);   // one lamp, up and to the left
    roomCache[roomId] = s;
    return s;
  }

  /** Answer key for a room: what is really there, and where. */
  function groundTruth(roomId) {
    return ROOMS_BY_ID[roomId].items.map(function (item) {
      var b = itemBounds(item);
      return {
        id: item.id, name: item.name, catalog: item.catalog, color: item.color,
        shape: item.shape, where: item.where, box: b
      };
    });
  }

  /* ==========================================================================
   * 6. SAMPLE APP CONTENT
   * ========================================================================*/

  /* Prefilled searches, so the search bar is useful the second the app opens. */
  var SAMPLE_SEARCHES = [
    { text: 'phone', color: 'purple', shape: 'rectangular', size: '', room: 'desk',
      note: 'the walkthrough from the brief' },
    { text: 'keys', color: 'gray', shape: 'irregular', size: 'small', room: 'desk' },
    { text: 'water bottle', color: '', shape: 'long', size: '', room: 'desk' },
    { text: 'remote', color: 'black', shape: 'rectangular', size: '', room: 'bedroom' },
    { text: 'charger', color: 'orange', shape: '', size: '', room: 'bedroom' },
    { text: 'passport', color: 'blue', shape: 'rectangular', size: '', room: 'suitcase' }
  ];

  /* A short history so the Log tab is populated on first run. */
  var SAMPLE_HISTORY = [
    { when: 'Yesterday, 21:14', room: 'Bedroom floor', query: 'remote', found: true,
      detail: 'TV remote · 88% · poking out from under the hoodie' },
    { when: 'Yesterday, 08:02', room: 'Study desk', query: 'purple phone', found: true,
      detail: 'Phone · 94% · between the notebook and the red mug' },
    { when: 'Sun, 17:40', room: 'Open suitcase', query: 'passport', found: true,
      detail: 'Passport · 91% · tucked beside the t-shirt on the left' },
    { when: 'Sun, 17:38', room: 'Open suitcase', query: 'sunglasses', found: false,
      detail: 'No match above 55% — try sweeping the side pockets' }
  ];

  NS.Data = {
    COLORS: COLORS, COLOR_GROUPS: COLOR_GROUPS, COLOR_WORDS: COLOR_WORDS,
    SHAPES: SHAPES, SHAPE_SIM: SHAPE_SIM, SIZES: SIZES,
    CATALOG: CATALOG, CATALOG_BY_ID: CATALOG_BY_ID,
    ROOMS: ROOMS, ROOMS_BY_ID: ROOMS_BY_ID,
    colorHex: colorHex, itemBounds: itemBounds,
    renderRoom: renderRoom, groundTruth: groundTruth,
    SAMPLE_SEARCHES: SAMPLE_SEARCHES, SAMPLE_HISTORY: SAMPLE_HISTORY
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = NS.Data;
})(typeof globalThis !== 'undefined' ? globalThis : this);
