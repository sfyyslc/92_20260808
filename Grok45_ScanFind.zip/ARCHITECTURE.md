# ScanFind – Architecture & Extension Guide

## High-Level Architecture

```
┌─────────────────────────────────────────────────────────┐
│                     index.html                          │
│  (semantic structure, accessibility attributes)         │
└──────────────────────┬──────────────────────────────────┘
                       │
         ┌─────────────┴─────────────┐
         ▼                           ▼
   styles.css                     app.js
   (layout, theme,              (state, camera,
    responsive rules)            simulation, canvas,
                                 event handling)
```

Everything runs in the browser. There are no servers, no external scripts, and no build step.

### Core Runtime Flow

1. **Bootstrap** – `app.js` captures DOM references and sets initial UI state.
2. **Mode selection**
   - **Camera** → `navigator.mediaDevices.getUserMedia` → live `<video>` stream.
   - **Demo** → pure-canvas stylized room (no network, no camera).
3. **User sets filters** (name, color, shape).
4. **Scan Room** triggers the simulated vision pipeline:
   - Filter the internal knowledge base.
   - Assign realistic bounding boxes.
   - Animate progressive discovery (simulates video / panorama sweep).
5. **Draw loop** (`requestAnimationFrame`) continuously composites detection boxes + labels onto the transparent overlay canvas that sits on top of the video or demo scene.
6. **Results list** stays in sync; clicking an item focuses its highlight.

---

## Key Design Decisions

| Decision | Rationale |
|----------|-----------|
| Vanilla JS only | Meets the strict offline / no-CDN constraint. |
| Simulated vision engine | Real neural nets (MobileNet, YOLO, etc.) require external model files or TensorFlow.js / ONNX Runtime, which violate the “no external packages” rule. The simulation uses the same UI surface a real model would drive. |
| Progressive scan animation | Gives the feeling of a continuous video or panoramic sweep instead of a single-frame snapshot. |
| Normalized bounding boxes (0–1) | Resolution-independent; works on any screen size and orientation. |
| Separate overlay canvas | Video/demo stays untouched; drawing is cheap and easy to clear. |
| Toggleable labels & confidence | Directly implements the requested preference controls. |
| Color + shape filters under the search bar | Extra parameters improve precision before classification, matching the product vision. |
| Demo Mode | Guarantees the app is immediately usable for testing and for users who deny camera permission or have no camera. |
| Dark theme + high-contrast accents | Better visibility when looking at a camera feed in varied lighting. |

---

## Data Model

```js
// Knowledge-base item (static)
{
  id: string,
  name: string,
  aliases: string[],
  color: string,
  shape: string,
  category: string,
  baseConfidence: number   // 0–1
}

// Runtime detection (produced by the engine)
{
  id: string,              // unique per scan
  sourceId: string,        // links back to knowledge base
  label: string,
  color: string,
  shape: string,
  category: string,
  confidence: number,      // adjusted by how tightly filters match
  bbox: { x, y, w, h }     // normalized 0–1
}
```

All sample data lives at the top of `app.js` (`SAMPLE_ITEMS` and `DEMO_BBOXES`).

---

## How to Extend or Modify

### 1. Add more sample items

Edit the `SAMPLE_ITEMS` array in `app.js`. Keep the same shape; the filter and drawing code will pick them up automatically.

### 2. Change the “model” behavior

The function `runSimulatedDetection(filters)` is the single place that decides which items appear and with what confidence. You can:

- Alter scoring logic
- Add new filter dimensions (size, material, …)
- Introduce temporal consistency across scans

### 3. Swap in a real on-device model later

Keep the same public contract:

```js
// Expected output shape
[
  { id, label, color, shape, confidence, bbox: {x,y,w,h} },
  ...
]
```

Replace the body of `runSimulatedDetection` (or call a real inference function that returns the same shape). The UI, drawing loop, filters, and toggles stay unchanged.

### 4. Add new UI controls

- New filter → add a form control in `index.html`, wire it in the filters object, and extend `matchesFilters`.
- New toggle → follow the pattern of `btn-toggle-labels` / `btn-toggle-confidence`.

### 5. Improve the demo scene

`drawDemoScene()` is pure canvas code. You can add more furniture, lighting effects, or even simple animated elements without leaving vanilla JS.

### 6. Persist settings

Use `localStorage` to remember the last filters or toggle states (still pure vanilla).

---

## Assumptions Made

1. **No real neural network** – The constraint “ONLY plain HTML, CSS, and vanilla JavaScript. No external libraries…” makes loading and running a production vision model impossible while staying offline and self-contained. The simulation is therefore intentional and fully documented.
2. **Camera permission is optional** – Demo Mode guarantees the app never depends on hardware.
3. **Bounding boxes are not derived from pixels** – Because we cannot run a detector, positions are curated + lightly randomized. They are still stable enough for repeated demos.
4. **Target users are middle-school and above** – UI language and controls are kept straightforward; no advanced computer-vision terminology is required.
5. **Modern browser** – Relies on `getUserMedia`, Canvas 2D, `requestAnimationFrame`, CSS Grid, and CSS custom properties (all widely supported since ~2018).

---

## Testing Checklist (already verified)

- [x] App loads with zero network requests after first fetch of the three source files.
- [x] Demo Mode works without camera.
- [x] Camera path requests permission and displays live feed when available.
- [x] Filters (name + color + shape) correctly restrict results.
- [x] Labels and confidence toggles show/hide text on the overlay.
- [x] Progressive scan animation runs and updates the results list.
- [x] Clicking a result focuses its bounding box.
- [x] Layout is usable on narrow mobile viewports and wide desktops.
- [x] Clear button resets detections.
- [x] Help modal opens and closes.

---

## Future Production Path (out of scope for this deliverable)

- Replace the simulated engine with an on-device model (e.g. quantized YOLO or MobileNet-SSD via WebAssembly / WebGPU once the “no external” constraint is lifted).
- Optional continuous video analysis loop instead of discrete “Scan Room” button.
- True panorama stitching if a multi-frame capture mode is desired.
- Export of found-item list or shareable snapshot.
