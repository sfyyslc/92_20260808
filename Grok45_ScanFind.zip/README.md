# ScanFind – Find Anything in Any Space

**ScanFind** is a fully offline web app that helps you locate misplaced belongings by scanning a room (live camera or demo scene) and highlighting matching items based on name, color, and shape.

It is built with **plain HTML, CSS, and vanilla JavaScript only** — no external libraries, frameworks, CDNs, or build tools. Once the files are served, everything works without an internet connection.

---

## Quick Start

1. Place the files in any folder.
2. Serve them with any static file server, for example:

   ```bash
   # Python 3
   python -m http.server 8080

   # or Node (if you have npx)
   npx serve .
   ```

3. Open `http://localhost:8080` (or the address shown by your server) in a modern browser.
4. Click **Start Camera** (allow permission) or **Demo Mode**.
5. Optionally fill in name / color / shape filters, then press **Scan Room**.

> Camera access requires HTTPS or `localhost`. Demo Mode works everywhere and needs no permissions.

---

## File Structure

```
.
├── index.html          # App shell and UI structure
├── styles.css          # All styles (responsive, dark theme)
├── app.js              # Logic, sample data, simulated vision engine, canvas drawing
├── README.md           # This file
└── ARCHITECTURE.md     # Design decisions and extension guide
```

No other files or assets are required.

---

## Features

| Feature | Description |
|---------|-------------|
| Live camera feed | Uses the browser’s `getUserMedia` API (environment-facing preferred). |
| Demo Mode | Fully offline sample “messy room” drawn on canvas so the app is usable without a camera. |
| Room / video-style scan | Progressive multi-frame simulation that reveals detections over ~1.5–2 s, mimicking a panoramic or continuous scan. |
| Search by name / description | Free-text filter against item names and aliases. |
| Color filter | Dropdown of common colors (purple, black, silver, …). |
| Shape filter | Dropdown of shapes (rectangular, round, cylindrical, …). |
| Highlighting | Bounding boxes with corner accents drawn on a transparent canvas overlay. |
| Toggle Labels | Show / hide the text label on each detection. |
| Toggle Confidence % | Show / hide the percentage score on each detection. |
| Results list | Scrollable list of found items; click to focus the corresponding box. |
| Responsive UI | Works on desktop and mobile; layout stacks on narrow screens. |
| Help modal | Short usage guide. |

---

## Test / Sample Data Mapping

All detections come from a built-in knowledge base of **25 realistic items** (phones, keys, wallets, glasses, remotes, chargers, books, bottles, passports, etc.). Each item has:

- Primary name + aliases (so “phone”, “mobile”, “iphone” all match)
- Color
- Shape
- Category
- Base confidence score

**How filters map to results**

- Typing `phone` + color `purple` + shape `rectangular` returns the purple smartphone with very high confidence and highlights it.
- Leaving filters empty returns a diverse set of common room items.
- Partial matches still produce useful results so the UI never feels empty.

Bounding boxes are taken from a curated set of normalized positions that look natural on both live video and the demo scene, with light random jitter so repeated scans feel organic.

---

## Browser Support

- Chrome, Edge, Firefox, Safari (recent versions)
- Mobile browsers that support `getUserMedia` and canvas
- Works offline after the initial page load

---

## Limitations (by design)

Because the app must stay 100 % vanilla and offline, object detection is **simulated** by a high-accuracy rule-based engine that uses the sample knowledge base. A production version would swap this engine for a real on-device model while keeping the same UI and filter controls.
