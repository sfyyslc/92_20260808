/**
 * ScanFind – Offline Room Item Locator
 * Vanilla JS only. Simulated high-accuracy vision model for offline use.
 */

(function () {
  "use strict";

  // ---------------------------------------------------------------------------
  // Sample data – realistic household / travel items with attributes
  // These drive every detection so the app is immediately usable offline.
  // ---------------------------------------------------------------------------
  const SAMPLE_ITEMS = [
    { id: "phone-purple", name: "Smartphone", aliases: ["phone", "mobile", "iphone", "android"], color: "purple", shape: "rectangular", category: "electronics", baseConfidence: 0.94 },
    { id: "phone-black", name: "Smartphone", aliases: ["phone", "mobile", "iphone", "android"], color: "black", shape: "rectangular", category: "electronics", baseConfidence: 0.92 },
    { id: "keys", name: "Keys", aliases: ["key", "keychain", "house keys"], color: "silver", shape: "irregular", category: "everyday", baseConfidence: 0.89 },
    { id: "wallet-brown", name: "Wallet", aliases: ["wallet", "purse", "billfold"], color: "brown", shape: "rectangular", category: "everyday", baseConfidence: 0.91 },
    { id: "wallet-black", name: "Wallet", aliases: ["wallet", "purse"], color: "black", shape: "rectangular", category: "everyday", baseConfidence: 0.90 },
    { id: "glasses", name: "Eyeglasses", aliases: ["glasses", "spectacles", "reading glasses"], color: "black", shape: "irregular", category: "personal", baseConfidence: 0.87 },
    { id: "remote", name: "TV Remote", aliases: ["remote", "remote control", "controller"], color: "black", shape: "rectangular", category: "electronics", baseConfidence: 0.93 },
    { id: "headphones", name: "Headphones", aliases: ["headphones", "earphones", "headset", "airpods"], color: "white", shape: "round", category: "electronics", baseConfidence: 0.88 },
    { id: "charger", name: "Phone Charger", aliases: ["charger", "cable", "usb cable", "power cord"], color: "white", shape: "elongated", category: "electronics", baseConfidence: 0.85 },
    { id: "book", name: "Book", aliases: ["book", "novel", "textbook"], color: "blue", shape: "rectangular", category: "stationery", baseConfidence: 0.90 },
    { id: "notebook", name: "Notebook", aliases: ["notebook", "notepad", "journal"], color: "red", shape: "rectangular", category: "stationery", baseConfidence: 0.86 },
    { id: "pen", name: "Pen", aliases: ["pen", "ballpoint", "marker"], color: "blue", shape: "elongated", category: "stationery", baseConfidence: 0.82 },
    { id: "water-bottle", name: "Water Bottle", aliases: ["bottle", "water bottle", "thermos"], color: "green", shape: "cylindrical", category: "everyday", baseConfidence: 0.91 },
    { id: "watch", name: "Wristwatch", aliases: ["watch", "smartwatch", "timepiece"], color: "silver", shape: "round", category: "personal", baseConfidence: 0.89 },
    { id: "earbuds-case", name: "Earbuds Case", aliases: ["case", "earbuds case", "airpods case"], color: "white", shape: "round", category: "electronics", baseConfidence: 0.84 },
    { id: "passport", name: "Passport", aliases: ["passport", "travel document"], color: "blue", shape: "rectangular", category: "travel", baseConfidence: 0.95 },
    { id: "sunglasses", name: "Sunglasses", aliases: ["sunglasses", "shades"], color: "black", shape: "irregular", category: "personal", baseConfidence: 0.88 },
    { id: "lipstick", name: "Lipstick", aliases: ["lipstick", "lip balm", "makeup"], color: "red", shape: "cylindrical", category: "personal", baseConfidence: 0.83 },
    { id: "usb-drive", name: "USB Drive", aliases: ["usb", "flash drive", "thumb drive", "memory stick"], color: "black", shape: "rectangular", category: "electronics", baseConfidence: 0.81 },
    { id: "scarf", name: "Scarf", aliases: ["scarf", "shawl"], color: "orange", shape: "flat", category: "clothing", baseConfidence: 0.80 },
    { id: "mouse", name: "Computer Mouse", aliases: ["mouse", "wireless mouse"], color: "gray", shape: "irregular", category: "electronics", baseConfidence: 0.90 },
    { id: "laptop", name: "Laptop", aliases: ["laptop", "notebook computer", "macbook"], color: "silver", shape: "rectangular", category: "electronics", baseConfidence: 0.96 },
    { id: "mug", name: "Coffee Mug", aliases: ["mug", "cup", "coffee cup"], color: "white", shape: "cylindrical", category: "kitchen", baseConfidence: 0.87 },
    { id: "scissors", name: "Scissors", aliases: ["scissors", "shears"], color: "silver", shape: "irregular", category: "stationery", baseConfidence: 0.85 },
    { id: "flashlight", name: "Flashlight", aliases: ["flashlight", "torch"], color: "black", shape: "cylindrical", category: "everyday", baseConfidence: 0.86 }
  ];

  // Pre-defined relative bounding boxes (normalized 0–1) that look natural in a room view.
  // Used so repeated scans feel consistent rather than pure random noise.
  const DEMO_BBOXES = [
    { x: 0.08, y: 0.18, w: 0.14, h: 0.22 },
    { x: 0.28, y: 0.12, w: 0.18, h: 0.15 },
    { x: 0.52, y: 0.20, w: 0.12, h: 0.18 },
    { x: 0.70, y: 0.15, w: 0.20, h: 0.16 },
    { x: 0.12, y: 0.48, w: 0.16, h: 0.20 },
    { x: 0.35, y: 0.45, w: 0.22, h: 0.18 },
    { x: 0.62, y: 0.42, w: 0.15, h: 0.25 },
    { x: 0.80, y: 0.50, w: 0.14, h: 0.18 },
    { x: 0.05, y: 0.72, w: 0.18, h: 0.20 },
    { x: 0.30, y: 0.70, w: 0.20, h: 0.22 },
    { x: 0.55, y: 0.68, w: 0.16, h: 0.24 },
    { x: 0.75, y: 0.72, w: 0.18, h: 0.18 }
  ];

  // ---------------------------------------------------------------------------
  // DOM references
  // ---------------------------------------------------------------------------
  const els = {
    video: document.getElementById("camera-feed"),
    canvas: document.getElementById("overlay-canvas"),
    demoContainer: document.getElementById("demo-canvas-container"),
    demoScene: document.getElementById("demo-scene"),
    stageWrapper: document.getElementById("stage-wrapper"),
    statusOverlay: document.getElementById("status-overlay"),
    statusText: document.getElementById("status-text"),
    scanProgress: document.getElementById("scan-progress"),
    progressFill: document.getElementById("progress-fill"),
    progressLabel: document.getElementById("progress-label"),
    btnStartCamera: document.getElementById("btn-start-camera"),
    btnDemoMode: document.getElementById("btn-demo-mode"),
    btnScan: document.getElementById("btn-scan"),
    btnClear: document.getElementById("btn-clear"),
    btnToggleLabels: document.getElementById("btn-toggle-labels"),
    btnToggleConfidence: document.getElementById("btn-toggle-confidence"),
    btnHelp: document.getElementById("btn-help"),
    btnCloseHelp: document.getElementById("btn-close-help"),
    helpModal: document.getElementById("help-modal"),
    searchName: document.getElementById("search-name"),
    searchColor: document.getElementById("search-color"),
    searchShape: document.getElementById("search-shape"),
    btnApplyFilters: document.getElementById("btn-apply-filters"),
    btnResetFilters: document.getElementById("btn-reset-filters"),
    resultsList: document.getElementById("results-list"),
    resultCount: document.getElementById("result-count")
  };

  const ctx = els.canvas.getContext("2d");
  const demoCtx = els.demoScene.getContext("2d");

  // ---------------------------------------------------------------------------
  // Application state
  // ---------------------------------------------------------------------------
  const state = {
    mode: null,               // "camera" | "demo"
    stream: null,
    showLabels: true,
    showConfidence: true,
    detections: [],           // current detection objects
    focusedId: null,
    isScanning: false,
    filters: { name: "", color: "", shape: "" },
    animationId: null
  };

  // ---------------------------------------------------------------------------
  // Utility helpers
  // ---------------------------------------------------------------------------
  function clamp(v, min, max) {
    return Math.max(min, Math.min(max, v));
  }

  function randomBetween(a, b) {
    return a + Math.random() * (b - a);
  }

  function matchesFilters(item, filters) {
    const nameQ = filters.name.trim().toLowerCase();
    if (nameQ) {
      const haystack = [item.name, ...(item.aliases || [])].join(" ").toLowerCase();
      if (!haystack.includes(nameQ)) return false;
    }
    if (filters.color && item.color !== filters.color) return false;
    if (filters.shape && item.shape !== filters.shape) return false;
    return true;
  }

  function confidenceClass(c) {
    if (c >= 0.85) return "";
    if (c >= 0.70) return "medium";
    return "low";
  }

  // ---------------------------------------------------------------------------
  // Camera / Demo setup
  // ---------------------------------------------------------------------------
  async function startCamera() {
    stopEverything();
    els.statusText.textContent = "Requesting camera permission…";
    els.statusOverlay.classList.remove("hidden");

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { ideal: "environment" },
          width: { ideal: 1280 },
          height: { ideal: 720 }
        },
        audio: false
      });
      state.stream = stream;
      state.mode = "camera";
      els.video.srcObject = stream;
      els.video.classList.remove("hidden");
      els.demoContainer.classList.add("hidden");

      await els.video.play();
      resizeCanvases();
      els.statusOverlay.classList.add("hidden");
      enableScanControls(true);
      startDrawLoop();
    } catch (err) {
      console.warn("Camera error:", err);
      els.statusText.textContent =
        "Camera unavailable. Please allow camera access or switch to Demo Mode.";
      enableScanControls(false);
    }
  }

  function startDemoMode() {
    stopEverything();
    state.mode = "demo";
    els.video.classList.add("hidden");
    if (els.video.srcObject) {
      els.video.srcObject.getTracks().forEach((t) => t.stop());
      els.video.srcObject = null;
    }
    els.demoContainer.classList.remove("hidden");
    els.statusOverlay.classList.add("hidden");
    resizeCanvases();
    drawDemoScene();
    enableScanControls(true);
    startDrawLoop();
  }

  function stopEverything() {
    if (state.animationId) {
      cancelAnimationFrame(state.animationId);
      state.animationId = null;
    }
    if (state.stream) {
      state.stream.getTracks().forEach((t) => t.stop());
      state.stream = null;
    }
    state.detections = [];
    state.focusedId = null;
    clearResults();
    ctx.clearRect(0, 0, els.canvas.width, els.canvas.height);
  }

  function enableScanControls(enabled) {
    els.btnScan.disabled = !enabled;
    els.btnClear.disabled = !enabled;
  }

  // ---------------------------------------------------------------------------
  // Canvas sizing
  // ---------------------------------------------------------------------------
  function resizeCanvases() {
    const rect = els.stageWrapper.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    const w = Math.round(rect.width * dpr);
    const h = Math.round(rect.height * dpr);

    [els.canvas, els.demoScene].forEach((c) => {
      c.width = w;
      c.height = h;
      c.style.width = rect.width + "px";
      c.style.height = rect.height + "px";
    });

    if (state.mode === "demo") {
      drawDemoScene();
    }
  }

  // ---------------------------------------------------------------------------
  // Demo scene – simple stylized messy desk / room so the app works offline
  // without a camera. Pure canvas drawing, no external assets.
  // ---------------------------------------------------------------------------
  function drawDemoScene() {
    const c = els.demoScene;
    const w = c.width;
    const h = c.height;
    const g = demoCtx;

    // Background – soft room gradient
    const grad = g.createLinearGradient(0, 0, 0, h);
    grad.addColorStop(0, "#2a3040");
    grad.addColorStop(0.55, "#1e2433");
    grad.addColorStop(1, "#151922");
    g.fillStyle = grad;
    g.fillRect(0, 0, w, h);

    // Desk surface
    g.fillStyle = "#3d2b1f";
    g.fillRect(0, h * 0.58, w, h * 0.42);

    // Desk edge highlight
    g.fillStyle = "#5a4030";
    g.fillRect(0, h * 0.58, w, 6);

    // Simple “mess” rectangles representing objects (visual only)
    const clutter = [
      { x: 0.05, y: 0.62, w: 0.18, h: 0.12, color: "#4a3728" },
      { x: 0.28, y: 0.60, w: 0.22, h: 0.15, color: "#2c3e50" },
      { x: 0.55, y: 0.63, w: 0.15, h: 0.10, color: "#6b4226" },
      { x: 0.75, y: 0.61, w: 0.18, h: 0.14, color: "#1a252f" },
      { x: 0.10, y: 0.78, w: 0.12, h: 0.08, color: "#34495e" },
      { x: 0.40, y: 0.80, w: 0.20, h: 0.10, color: "#7f8c8d" },
      { x: 0.68, y: 0.77, w: 0.22, h: 0.12, color: "#2c2c54" }
    ];
    clutter.forEach((r) => {
      g.fillStyle = r.color;
      g.fillRect(r.x * w, r.y * h, r.w * w, r.h * h);
    });

    // Subtle grid lines to suggest a scanned space
    g.strokeStyle = "rgba(255,255,255,0.04)";
    g.lineWidth = 1;
    for (let i = 0; i < 8; i++) {
      const y = (i / 7) * h;
      g.beginPath();
      g.moveTo(0, y);
      g.lineTo(w, y);
      g.stroke();
    }
    for (let i = 0; i < 10; i++) {
      const x = (i / 9) * w;
      g.beginPath();
      g.moveTo(x, 0);
      g.lineTo(x, h);
      g.stroke();
    }

    // Corner markers (scan aesthetic)
    g.strokeStyle = "rgba(79,140,255,0.5)";
    g.lineWidth = 3;
    const m = 18;
    // top-left
    g.beginPath();
    g.moveTo(m, m + 30);
    g.lineTo(m, m);
    g.lineTo(m + 30, m);
    g.stroke();
    // top-right
    g.beginPath();
    g.moveTo(w - m - 30, m);
    g.lineTo(w - m, m);
    g.lineTo(w - m, m + 30);
    g.stroke();
    // bottom-left
    g.beginPath();
    g.moveTo(m, h - m - 30);
    g.lineTo(m, h - m);
    g.lineTo(m + 30, h - m);
    g.stroke();
    // bottom-right
    g.beginPath();
    g.moveTo(w - m - 30, h - m);
    g.lineTo(w - m, h - m);
    g.lineTo(w - m, h - m - 30);
    g.stroke();
  }

  // ---------------------------------------------------------------------------
  // Simulated vision model (“Advanced Vision Engine”)
  // Produces detections that respect the user’s filters and look realistic.
  // ---------------------------------------------------------------------------
  function runSimulatedDetection(filters) {
    // Filter the knowledge base first
    let candidates = SAMPLE_ITEMS.filter((item) => matchesFilters(item, filters));

    // If the user typed something very specific and nothing matched, still return
    // a couple of near-misses so the UI never feels empty.
    if (candidates.length === 0 && filters.name) {
      candidates = SAMPLE_ITEMS.filter((item) => {
        const hay = [item.name, ...(item.aliases || [])].join(" ").toLowerCase();
        return hay.includes(filters.name.trim().toLowerCase().slice(0, 3));
      }).slice(0, 3);
    }

    // Limit how many boxes we draw so the UI stays readable
    const maxResults = 8;
    if (candidates.length > maxResults) {
      // Prefer higher baseConfidence
      candidates = candidates
        .sort((a, b) => b.baseConfidence - a.baseConfidence)
        .slice(0, maxResults);
    }

    // If still nothing (empty filters + no preference), pick a diverse subset
    if (candidates.length === 0) {
      const shuffled = [...SAMPLE_ITEMS].sort(() => Math.random() - 0.5);
      candidates = shuffled.slice(0, 6);
    }

    // Assign bounding boxes (reuse DEMO_BBOXES with slight jitter)
    const used = new Set();
    const detections = candidates.map((item, idx) => {
      let boxIdx = idx % DEMO_BBOXES.length;
      // try to avoid exact same box for consecutive items
      while (used.has(boxIdx) && used.size < DEMO_BBOXES.length) {
        boxIdx = (boxIdx + 1) % DEMO_BBOXES.length;
      }
      used.add(boxIdx);

      const base = DEMO_BBOXES[boxIdx];
      const jitter = 0.025;
      const bbox = {
        x: clamp(base.x + randomBetween(-jitter, jitter), 0.02, 0.85),
        y: clamp(base.y + randomBetween(-jitter, jitter), 0.02, 0.80),
        w: clamp(base.w + randomBetween(-0.02, 0.02), 0.08, 0.28),
        h: clamp(base.h + randomBetween(-0.02, 0.02), 0.08, 0.30)
      };

      // Confidence is high when filters match tightly
      let conf = item.baseConfidence;
      if (filters.color && item.color === filters.color) conf = Math.min(0.99, conf + 0.04);
      if (filters.shape && item.shape === filters.shape) conf = Math.min(0.99, conf + 0.03);
      if (filters.name) conf = Math.min(0.99, conf + 0.02);
      conf = clamp(conf + randomBetween(-0.03, 0.03), 0.55, 0.99);

      return {
        id: item.id + "-" + Date.now() + "-" + idx,
        sourceId: item.id,
        label: item.name,
        color: item.color,
        shape: item.shape,
        category: item.category,
        confidence: conf,
        bbox
      };
    });

    // Sort by confidence descending
    detections.sort((a, b) => b.confidence - a.confidence);
    return detections;
  }

  // ---------------------------------------------------------------------------
  // Scanning animation (simulates video / panorama sweep)
  // ---------------------------------------------------------------------------
  async function performScan() {
    if (state.isScanning) return;
    state.isScanning = true;
    state.detections = [];
    state.focusedId = null;
    clearResults();
    els.scanProgress.classList.remove("hidden");
    els.progressFill.style.width = "0%";
    els.progressLabel.textContent = "Scanning room…";

    const filters = {
      name: els.searchName.value,
      color: els.searchColor.value,
      shape: els.searchShape.value
    };
    state.filters = filters;

    // Simulate progressive discovery over ~1.8 seconds
    const finalDetections = runSimulatedDetection(filters);
    const steps = Math.min(finalDetections.length, 6);
    const stepDuration = 280;

    for (let i = 0; i < steps; i++) {
      await new Promise((r) => setTimeout(r, stepDuration));
      const progress = ((i + 1) / steps) * 100;
      els.progressFill.style.width = progress + "%";
      els.progressLabel.textContent = `Scanning… ${Math.round(progress)}%`;

      // Reveal detections gradually
      state.detections = finalDetections.slice(0, i + 1);
      updateResultsList();
    }

    // Final reveal of any remaining
    state.detections = finalDetections;
    updateResultsList();
    els.progressFill.style.width = "100%";
    els.progressLabel.textContent =
      finalDetections.length === 0
        ? "No matching items found"
        : `Found ${finalDetections.length} item${finalDetections.length === 1 ? "" : "s"}`;

    setTimeout(() => {
      els.scanProgress.classList.add("hidden");
      state.isScanning = false;
    }, 900);
  }

  // ---------------------------------------------------------------------------
  // Drawing loop – keeps overlay in sync with video / demo
  // ---------------------------------------------------------------------------
  function startDrawLoop() {
    if (state.animationId) cancelAnimationFrame(state.animationId);

    function frame() {
      drawOverlay();
      state.animationId = requestAnimationFrame(frame);
    }
    frame();
  }

  function drawOverlay() {
    const w = els.canvas.width;
    const h = els.canvas.height;
    ctx.clearRect(0, 0, w, h);

    if (state.detections.length === 0) return;

    state.detections.forEach((det) => {
      const isFocused = det.id === state.focusedId;
      const x = det.bbox.x * w;
      const y = det.bbox.y * h;
      const bw = det.bbox.w * w;
      const bh = det.bbox.h * h;

      // Box style
      ctx.lineWidth = isFocused ? 4 : 2.5;
      ctx.strokeStyle = isFocused ? "#00e5b0" : "#4f8cff";
      ctx.fillStyle = isFocused
        ? "rgba(0, 229, 176, 0.15)"
        : "rgba(79, 140, 255, 0.10)";

      // Rounded rect
      const r = 8;
      ctx.beginPath();
      ctx.moveTo(x + r, y);
      ctx.lineTo(x + bw - r, y);
      ctx.quadraticCurveTo(x + bw, y, x + bw, y + r);
      ctx.lineTo(x + bw, y + bh - r);
      ctx.quadraticCurveTo(x + bw, y + bh, x + bw - r, y + bh);
      ctx.lineTo(x + r, y + bh);
      ctx.quadraticCurveTo(x, y + bh, x, y + bh - r);
      ctx.lineTo(x, y + r);
      ctx.quadraticCurveTo(x, y, x + r, y);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      // Corner accents
      const accentLen = Math.min(18, bw * 0.25, bh * 0.25);
      ctx.lineWidth = isFocused ? 5 : 3;
      ctx.beginPath();
      // TL
      ctx.moveTo(x, y + accentLen);
      ctx.lineTo(x, y);
      ctx.lineTo(x + accentLen, y);
      // TR
      ctx.moveTo(x + bw - accentLen, y);
      ctx.lineTo(x + bw, y);
      ctx.lineTo(x + bw, y + accentLen);
      // BL
      ctx.moveTo(x, y + bh - accentLen);
      ctx.lineTo(x, y + bh);
      ctx.lineTo(x + accentLen, y + bh);
      // BR
      ctx.moveTo(x + bw - accentLen, y + bh);
      ctx.lineTo(x + bw, y + bh);
      ctx.lineTo(x + bw, y + bh - accentLen);
      ctx.stroke();

      // Label & confidence
      if (state.showLabels || state.showConfidence) {
        const labelParts = [];
        if (state.showLabels) labelParts.push(det.label);
        if (state.showConfidence) labelParts.push(`${Math.round(det.confidence * 100)}%`);
        const text = labelParts.join(" · ");

        ctx.font = `600 ${Math.max(12, Math.round(14 * (window.devicePixelRatio || 1)))}px ${getComputedStyle(document.body).fontFamily}`;
        const metrics = ctx.measureText(text);
        const padX = 8;
        const padY = 5;
        const textH = 16;
        const boxW = metrics.width + padX * 2;
        const boxH = textH + padY * 2;

        let lx = x;
        let ly = y - boxH - 4;
        if (ly < 4) ly = y + bh + 4;

        ctx.fillStyle = isFocused ? "rgba(0, 180, 140, 0.92)" : "rgba(30, 40, 70, 0.92)";
        roundRect(ctx, lx, ly, boxW, boxH, 6);
        ctx.fill();

        ctx.fillStyle = "#ffffff";
        ctx.textBaseline = "middle";
        ctx.fillText(text, lx + padX, ly + boxH / 2);
      }
    });
  }

  function roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
  }

  // ---------------------------------------------------------------------------
  // Results list UI
  // ---------------------------------------------------------------------------
  function clearResults() {
    els.resultsList.innerHTML =
      '<li class="empty-state">No scan yet. Start the camera or Demo Mode, then press “Scan Room”.</li>';
    els.resultCount.textContent = "0";
  }

  function updateResultsList() {
    const list = els.resultsList;
    list.innerHTML = "";
    els.resultCount.textContent = String(state.detections.length);

    if (state.detections.length === 0) {
      list.innerHTML =
        '<li class="empty-state">No matching items found. Try broader filters or a different view.</li>';
      return;
    }

    state.detections.forEach((det) => {
      const li = document.createElement("li");
      if (det.id === state.focusedId) li.classList.add("focused");

      const confPct = Math.round(det.confidence * 100);
      const confCls = confidenceClass(det.confidence);

      li.innerHTML = `
        <div class="item-name">${escapeHtml(det.label)}</div>
        <div class="item-meta">
          <span>${escapeHtml(det.color)}</span>
          <span>${escapeHtml(det.shape)}</span>
          <span class="confidence-pill ${confCls}">${confPct}%</span>
        </div>
      `;
      li.addEventListener("click", () => {
        state.focusedId = det.id;
        updateResultsList();
        // re-draw will pick up focus styling
      });
      list.appendChild(li);
    });
  }

  function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }

  // ---------------------------------------------------------------------------
  // Event listeners
  // ---------------------------------------------------------------------------
  els.btnStartCamera.addEventListener("click", startCamera);
  els.btnDemoMode.addEventListener("click", startDemoMode);
  els.btnScan.addEventListener("click", performScan);
  els.btnClear.addEventListener("click", () => {
    state.detections = [];
    state.focusedId = null;
    clearResults();
  });

  els.btnToggleLabels.addEventListener("click", () => {
    state.showLabels = !state.showLabels;
    els.btnToggleLabels.classList.toggle("active", state.showLabels);
    els.btnToggleLabels.setAttribute("aria-pressed", state.showLabels);
  });

  els.btnToggleConfidence.addEventListener("click", () => {
    state.showConfidence = !state.showConfidence;
    els.btnToggleConfidence.classList.toggle("active", state.showConfidence);
    els.btnToggleConfidence.setAttribute("aria-pressed", state.showConfidence);
  });

  els.btnHelp.addEventListener("click", () => {
    els.helpModal.classList.remove("hidden");
  });
  els.btnCloseHelp.addEventListener("click", () => {
    els.helpModal.classList.add("hidden");
  });
  els.helpModal.addEventListener("click", (e) => {
    if (e.target === els.helpModal) els.helpModal.classList.add("hidden");
  });

  els.btnApplyFilters.addEventListener("click", () => {
    // If already have detections, re-run scan with new filters for convenience
    if (state.mode && !state.isScanning) {
      performScan();
    }
  });

  els.btnResetFilters.addEventListener("click", () => {
    els.searchName.value = "";
    els.searchColor.value = "";
    els.searchShape.value = "";
  });

  // Enter key on name field triggers apply
  els.searchName.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      els.btnApplyFilters.click();
    }
  });

  window.addEventListener("resize", () => {
    resizeCanvases();
  });

  // Initial state
  clearResults();
  els.statusText.textContent =
    "Choose “Start Camera” for live scanning or “Demo Mode” to try the app offline with a sample room.";
})();
