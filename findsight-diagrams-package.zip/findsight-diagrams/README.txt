FindSight Diagram Package
==========================

Files
-----
- findsight-architecture.svg: client-only modules, browser boundary, data paths, analysis paths, outputs, and tests.
- findsight-user-flow.svg: source selection, target setup, readiness checks, mode-specific scan paths, and result/refinement loops.
- findsight-user-journey-map.svg: six-stage journey from recognizing the need through locating the item or refining the search.

Notes
-----
- Each SVG is standalone, scalable, and editable in a text editor or vector design tool.
- No external images, scripts, font files, or network resources are referenced.
- The palette follows the supplied FindSight CSS variables, with standard font fallbacks.
- The journey map labels its emotion curve and opportunity statements as design hypotheses because the supplied source package does not contain observed user-research data.

Source basis
------------
README.md, ARCHITECTURE.md, index.html, app.js, data.js, vision-engine.js, styles.css, run-tests.js, and TEST-RESULTS.md.
