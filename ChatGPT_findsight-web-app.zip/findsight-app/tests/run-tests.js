'use strict';

const assert = require('node:assert/strict');
const data = require('../data.js');
const engine = require('../vision-engine.js');

let passed = 0;

function test(name, fn) {
  try {
    fn();
    passed += 1;
    console.log(`PASS  ${name}`);
  } catch (error) {
    console.error(`FAIL  ${name}`);
    throw error;
  }
}

function createMockCanvas(width, height, paintPixel) {
  const pixels = new Uint8ClampedArray(width * height * 4);
  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      const [red, green, blue, alpha = 255] = paintPixel(x, y);
      const offset = (y * width + x) * 4;
      pixels[offset] = red;
      pixels[offset + 1] = green;
      pixels[offset + 2] = blue;
      pixels[offset + 3] = alpha;
    }
  }

  return {
    width,
    height,
    getContext() {
      return {
        getImageData() {
          return { data: pixels, width, height };
        }
      };
    }
  };
}

test('sample catalog contains twelve realistic items', () => {
  assert.equal(data.items.length, 12);
  assert.equal(data.zones.length, 4);
});

test('phone example matches by name, color, and shape', () => {
  const results = engine.matchItems(data.items, {
    query: 'phone',
    color: 'Purple',
    shape: 'Rectangular',
    category: 'Any category',
    minConfidence: 0.7
  });
  assert.equal(results.length, 1);
  assert.equal(results[0].id, 'purple-phone');
  assert.equal(results[0].matchScore, 1);
});

test('aliases such as mobile resolve to the phone', () => {
  const results = engine.matchItems(data.items, {
    query: 'mobile',
    color: 'Any color',
    shape: 'Any shape',
    category: 'Any category',
    minConfidence: 0.5
  });
  assert.equal(results[0].id, 'purple-phone');
});

test('attribute filters reject otherwise related items', () => {
  const results = engine.matchItems(data.items, {
    query: 'phone',
    color: 'Blue',
    shape: 'Rectangular',
    category: 'Any category',
    minConfidence: 0.5
  });
  assert.deepEqual(results, []);
});

test('text normalization is case and punctuation tolerant', () => {
  assert.equal(engine.normalizeText('  Cell-Phone!! '), 'cell phone');
  assert.deepEqual(engine.tokenize('Purple rectangular phone'), ['purple', 'rectangular', 'phone']);
});

test('RGB to HSV conversion recognizes primary red', () => {
  const hsv = engine.rgbToHsv(255, 0, 0);
  assert.equal(Math.round(hsv.h), 0);
  assert.equal(Math.round(hsv.s), 100);
  assert.equal(Math.round(hsv.v), 100);
});

test('named color matcher identifies purple and keeps pink hue-specific', () => {
  assert.equal(engine.pixelMatchesColor(118, 55, 200, 'Purple'), true);
  assert.equal(engine.pixelMatchesColor(40, 180, 100, 'Purple'), false);
  assert.equal(engine.pixelMatchesColor(228, 91, 146, 'Pink'), true);
  assert.equal(engine.pixelMatchesColor(40, 180, 100, 'Pink'), false);
});

test('shape classifier distinguishes rectangular, round, and cylindrical regions', () => {
  assert.equal(engine.classifyShape(100, 40, 0.82), 'Rectangular');
  assert.equal(engine.classifyShape(50, 50, 0.52), 'Round');
  assert.equal(engine.classifyShape(30, 100, 0.62), 'Cylindrical');
});

test('shape compatibility allows practical near-neighbor shapes', () => {
  assert.equal(engine.shapesAreCompatible('Square', 'Rectangular'), true);
  assert.equal(engine.shapesAreCompatible('Oval', 'Round'), true);
  assert.equal(engine.shapesAreCompatible('Irregular', 'Round'), false);
});

test('offline color-region detector finds a purple rectangle', () => {
  const canvas = createMockCanvas(40, 30, (x, y) => {
    const insideRectangle = x >= 6 && x <= 27 && y >= 9 && y <= 21;
    return insideRectangle ? [118, 55, 200, 255] : [245, 247, 250, 255];
  });

  const regions = engine.findColorRegions(canvas, 'Purple', 'Rectangular', {
    minimumPixelRatio: 0.001,
    maximumResults: 3
  });

  assert.equal(regions.length, 1);
  assert.equal(regions[0].shape, 'Rectangular');
  assert.equal(regions[0].x, 6);
  assert.equal(regions[0].y, 9);
  assert.equal(regions[0].width, 22);
  assert.equal(regions[0].height, 13);
  assert.ok(regions[0].confidence >= 0.8);
});

console.log(`\n${passed} logic tests passed.`);
