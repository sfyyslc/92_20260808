# Test Results

Tested on 2026-08-08.

## Automated logic tests

Command:

```bash
node tests/run-tests.js
```

Result: **10 of 10 passed**.

Coverage includes sample-data integrity, name and alias matching, color/shape/category filtering, text normalization, HSV color conversion, named-color matching, shape classification, shape compatibility, and connected-component detection of a synthetic purple rectangular region.

## Headless browser smoke test

Result: **31 of 31 checks passed**, with no JavaScript runtime exceptions and no browser error-log entries.

The browser pass checked:

- Initial app boot and all 12 inventory cards
- Default purple-phone result and detection overlay
- Label-box visibility and matched-only mode
- Quick-search and inventory-card interactions
- Video-mode selection and bundled sample sweep
- Loading three sample panorama captures
- Panorama assembly, visibility, scan-button state, and camera-stream shutdown
- Minimum-confidence filtering of live/panorama candidates
- Correct media-layer hiding when modes change
- Label and confidence toggle state
- Rescan start, progress advancement, progressive item reveal, and stop behavior
- Responsive desktop layout at 1440 × 1200
- Responsive mobile layout at 390 × 844

Reference screenshots are in `tests/screenshots/desktop.png` and `tests/screenshots/mobile.png`.

## Environment-limited checks

A physical camera was not available in the headless test environment. Camera permission handling, local-only processing paths, and the sample panorama workflow were inspected, but live hardware capture should also be checked on the target phone or laptop. The local video picker requires a user-selected video and was not automated; the built-in sample video-sweep path was tested instead.
