(function initializeFindSight() {
  'use strict';

  const data = window.FindSightData;
  const engine = window.VisionEngine;

  if (!data || !engine) {
    document.body.innerHTML = '<p style="padding:2rem;font-family:sans-serif">FindSight could not load its local data files.</p>';
    return;
  }

  const elements = {
    modeTabs: Array.from(document.querySelectorAll('.mode-tab')),
    scanButton: document.getElementById('scanButton'),
    scannerStage: document.getElementById('scannerStage'),
    mediaContent: document.getElementById('mediaContent'),
    demoImage: document.getElementById('demoImage'),
    cameraVideo: document.getElementById('cameraVideo'),
    panoramaCanvas: document.getElementById('panoramaCanvas'),
    analysisCanvas: document.getElementById('analysisCanvas'),
    detectionOverlay: document.getElementById('detectionOverlay'),
    scanBeam: document.getElementById('scanBeam'),
    targetChipText: document.getElementById('targetChipText'),
    stageMessage: document.getElementById('stageMessage'),
    stageMessageTitle: document.getElementById('stageMessageTitle'),
    stageMessageText: document.getElementById('stageMessageText'),
    stageToast: document.getElementById('stageToast'),
    scanStatusText: document.getElementById('scanStatusText'),
    scanProgressText: document.getElementById('scanProgressText'),
    scanProgress: document.getElementById('scanProgress'),
    scanProgressFill: document.getElementById('scanProgressFill'),
    panControl: document.getElementById('panControl'),
    panRange: document.getElementById('panRange'),
    modeActionBar: document.getElementById('modeActionBar'),
    zoneStrip: document.getElementById('zoneStrip'),
    searchForm: document.getElementById('searchForm'),
    searchInput: document.getElementById('searchInput'),
    colorSelect: document.getElementById('colorSelect'),
    shapeSelect: document.getElementById('shapeSelect'),
    categorySelect: document.getElementById('categorySelect'),
    confidenceRange: document.getElementById('confidenceRange'),
    confidenceOutput: document.getElementById('confidenceOutput'),
    clearSearchButton: document.getElementById('clearSearchButton'),
    quickSearches: document.querySelector('.quick-searches'),
    labelsToggle: document.getElementById('labelsToggle'),
    confidenceToggle: document.getElementById('confidenceToggle'),
    allBoxesToggle: document.getElementById('allBoxesToggle'),
    autoPanToggle: document.getElementById('autoPanToggle'),
    resultCard: document.getElementById('resultCard'),
    resultStatusIcon: document.getElementById('resultStatusIcon'),
    resultHeading: document.getElementById('resultHeading'),
    resultSummary: document.getElementById('resultSummary'),
    resultMeta: document.getElementById('resultMeta'),
    focusResultButton: document.getElementById('focusResultButton'),
    inventoryGrid: document.getElementById('inventoryGrid'),
    inventoryCount: document.getElementById('inventoryCount'),
    helpButton: document.getElementById('helpButton'),
    helpDialog: document.getElementById('helpDialog'),
    videoFileInput: document.getElementById('videoFileInput')
  };

  const COLOR_SWATCHES = {
    purple: ['#7651d6', '#fff'],
    blue: ['#2f69c1', '#fff'],
    silver: ['#c5cdd6', '#253247'],
    red: ['#bd3d4e', '#fff'],
    gray: ['#7b8491', '#fff'],
    white: ['#f8fafc', '#344054'],
    green: ['#3ea878', '#fff'],
    yellow: ['#edc54c', '#5f4a00'],
    navy: ['#243c6a', '#fff'],
    black: ['#222933', '#fff'],
    pink: ['#e45b92', '#fff'],
    orange: ['#e6812b', '#fff'],
    brown: ['#765744', '#fff']
  };

  const ITEM_ICONS = {
    Electronics: '⌁',
    'Everyday carry': '◇',
    'School supplies': '✎',
    Clothing: '≈',
    'Personal items': '○',
    Travel: '▣'
  };

  const state = {
    mode: 'demo',
    scanning: false,
    scanToken: 0,
    scanProgress: 1,
    pan: 0,
    contentScale: 1.5,
    scannedItemIds: new Set(data.items.map((item) => item.id)),
    currentMatches: [],
    activeResultId: 'purple-phone',
    stream: null,
    videoObjectUrl: '',
    videoUsesDemo: false,
    liveDetections: [],
    panoramaFrames: [],
    panoramaDetections: [],
    panoramaAssembled: false,
    panoramaScale: 1,
    lastAnalysisAt: 0,
    toastTimer: 0
  };

  function clamp(value, minimum, maximum) {
    return Math.min(maximum, Math.max(minimum, value));
  }

  function escapeHtml(value) {
    return String(value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function percentage(value) {
    return `${Math.round(Number(value) * 100)}%`;
  }

  function populateSelect(select, options, selectedValue) {
    select.innerHTML = options
      .map((option) => `<option value="${escapeHtml(option)}"${option === selectedValue ? ' selected' : ''}>${escapeHtml(option)}</option>`)
      .join('');
  }

  function currentCriteria() {
    return {
      query: elements.searchInput.value.trim(),
      color: elements.colorSelect.value,
      shape: elements.shapeSelect.value,
      category: elements.categorySelect.value,
      minConfidence: Number(elements.confidenceRange.value) / 100
    };
  }

  function formatTarget(criteria) {
    const parts = [];
    if (!engine.isAny(criteria.color)) parts.push(criteria.color.toLowerCase());
    if (!engine.isAny(criteria.shape)) parts.push(criteria.shape.toLowerCase());
    parts.push(criteria.query || 'item');
    return parts.join(' ');
  }

  function updateTargetChip() {
    elements.targetChipText.textContent = `Target: ${formatTarget(currentCriteria())}`;
  }

  function setStageMessage(title, text, visible) {
    elements.stageMessageTitle.textContent = title;
    elements.stageMessageText.textContent = text;
    elements.stageMessage.hidden = !visible;
  }

  function showToast(message, duration) {
    window.clearTimeout(state.toastTimer);
    elements.stageToast.textContent = message;
    elements.stageToast.hidden = false;
    state.toastTimer = window.setTimeout(() => {
      elements.stageToast.hidden = true;
    }, duration || 3200);
  }

  function setProgress(progress, statusText) {
    const normalized = clamp(progress, 0, 1);
    state.scanProgress = normalized;
    const value = Math.round(normalized * 100);
    elements.scanProgressFill.style.width = `${value}%`;
    elements.scanProgressText.textContent = `${value}%`;
    elements.scanProgress.setAttribute('aria-valuenow', String(value));
    if (statusText) elements.scanStatusText.textContent = statusText;
  }

  function setScanning(active) {
    state.scanning = active;
    elements.scannerStage.classList.toggle('is-scanning', active);
    const label = elements.scanButton.querySelector('span');
    if (active) {
      label.textContent = 'Stop scan';
      elements.scanButton.setAttribute('aria-label', 'Stop the active scan');
    } else {
      const labels = {
        demo: 'Rescan room',
        camera: 'Scan camera',
        video: state.videoUsesDemo ? 'Run sample sweep' : 'Scan video',
        panorama: 'Scan panorama'
      };
      label.textContent = labels[state.mode];
      elements.scanButton.removeAttribute('aria-label');
      elements.scannerStage.style.setProperty('--scan-position', '0%');
    }
  }

  function configureContentScale(scale) {
    state.contentScale = Math.max(1, Number(scale) || 1);
    elements.mediaContent.classList.toggle('is-standard', state.contentScale === 1);
    elements.mediaContent.classList.toggle('is-panorama', state.contentScale > 1);
    elements.mediaContent.style.width = `${state.contentScale * 100}%`;
    elements.panControl.hidden = state.contentScale <= 1;
    setPan(state.contentScale <= 1 ? 0 : state.pan, false);
  }

  function setPan(value, updateRange) {
    const normalized = clamp(Number(value) || 0, 0, 1);
    state.pan = normalized;
    const maximumTranslation = state.contentScale > 1 ? ((state.contentScale - 1) / state.contentScale) * 100 : 0;
    elements.mediaContent.style.transform = `translateX(-${normalized * maximumTranslation}%)`;
    if (updateRange !== false) elements.panRange.value = String(Math.round(normalized * 100));
    updateZoneStrip();
  }

  function focusSceneCoordinate(centerX, sceneWidth) {
    const visibleFraction = 1 / state.contentScale;
    if (visibleFraction >= 1) {
      setPan(0);
      return;
    }
    const normalizedCenter = centerX / sceneWidth;
    const desired = (normalizedCenter - visibleFraction / 2) / (1 - visibleFraction);
    setPan(clamp(desired, 0, 1));
  }

  function showMedia(kind) {
    elements.demoImage.hidden = kind !== 'demo';
    elements.cameraVideo.hidden = kind !== 'video';
    elements.panoramaCanvas.hidden = kind !== 'canvas';
  }

  function updateModeTabs() {
    elements.modeTabs.forEach((tab) => {
      const active = tab.dataset.mode === state.mode;
      tab.classList.toggle('is-active', active);
      tab.setAttribute('aria-selected', String(active));
      tab.tabIndex = active ? 0 : -1;
    });
  }

  function renderZoneStrip() {
    elements.zoneStrip.innerHTML = data.zones
      .map((zone) => `<div class="zone-pill" data-zone="${zone.id}"><span>${escapeHtml(zone.name)}</span></div>`)
      .join('');
    updateZoneStrip();
  }

  function updateZoneStrip() {
    const demoLike = state.mode === 'demo' || (state.mode === 'video' && state.videoUsesDemo);
    elements.zoneStrip.hidden = !demoLike;
    if (!demoLike) return;

    const scanX = state.scanProgress * data.scene.width;
    const visibleFraction = 1 / state.contentScale;
    const viewportCenter = (state.pan * (1 - visibleFraction) + visibleFraction / 2) * data.scene.width;

    elements.zoneStrip.querySelectorAll('.zone-pill').forEach((pill) => {
      const zone = data.zones.find((candidate) => candidate.id === pill.dataset.zone);
      const scanned = state.scanProgress >= 1 || scanX >= zone.endX;
      const active = viewportCenter >= zone.startX && viewportCenter < zone.endX;
      pill.classList.toggle('is-scanned', scanned);
      pill.classList.toggle('is-active', active);
    });
  }

  function displayPreferences() {
    elements.detectionOverlay.classList.toggle('hide-labels', !elements.labelsToggle.checked);
    elements.detectionOverlay.classList.toggle('hide-confidence', !elements.confidenceToggle.checked);
  }

  function makeDetectionBox(box, options) {
    const detection = document.createElement('div');
    detection.className = 'detection-box';
    if (options.isMatch) detection.classList.add('is-match');
    if (options.isSecondary) detection.classList.add('is-secondary-match');
    detection.style.left = `${box.left}%`;
    detection.style.top = `${box.top}%`;
    detection.style.width = `${box.width}%`;
    detection.style.height = `${box.height}%`;
    detection.setAttribute('aria-label', options.ariaLabel);

    const label = document.createElement('span');
    label.className = `detection-label${box.top < 11 ? ' is-below' : ''}`;
    label.innerHTML = `<span class="item-name">${escapeHtml(options.label)}</span><span class="confidence-value">${escapeHtml(options.confidence)}</span>`;
    detection.appendChild(label);
    return detection;
  }

  function renderDemoOverlay() {
    const matches = state.currentMatches;
    const matchIds = new Set(matches.map((item) => item.id));
    const bestId = matches[0]?.id;
    const showAll = elements.allBoxesToggle.checked;
    const fragment = document.createDocumentFragment();

    data.items.forEach((item) => {
      if (!state.scannedItemIds.has(item.id)) return;
      const isMatch = matchIds.has(item.id);
      if (!showAll && !isMatch) return;

      const box = {
        left: (item.box.x / data.scene.width) * 100,
        top: (item.box.y / data.scene.height) * 100,
        width: (item.box.width / data.scene.width) * 100,
        height: (item.box.height / data.scene.height) * 100
      };

      fragment.appendChild(makeDetectionBox(box, {
        isMatch: item.id === bestId,
        isSecondary: isMatch && item.id !== bestId,
        label: item.name,
        confidence: percentage(item.confidence),
        ariaLabel: `${item.name}, ${percentage(item.confidence)} confidence`
      }));
    });

    elements.detectionOverlay.replaceChildren(fragment);
    displayPreferences();
  }

  function liveDetectionLabel() {
    const query = elements.searchInput.value.trim();
    return query || 'Target item';
  }

  function renderLiveOverlay(detections, sourceWidth, sourceHeight) {
    const fragment = document.createDocumentFragment();
    detections.forEach((detection, index) => {
      const box = {
        left: (detection.x / sourceWidth) * 100,
        top: (detection.y / sourceHeight) * 100,
        width: (detection.width / sourceWidth) * 100,
        height: (detection.height / sourceHeight) * 100
      };
      fragment.appendChild(makeDetectionBox(box, {
        isMatch: index === 0,
        isSecondary: index > 0,
        label: `${liveDetectionLabel()} · ${detection.shape}`,
        confidence: percentage(detection.confidence),
        ariaLabel: `${liveDetectionLabel()} candidate, ${detection.shape}, ${percentage(detection.confidence)} confidence`
      }));
    });
    elements.detectionOverlay.replaceChildren(fragment);
    displayPreferences();
  }

  function renderCurrentOverlay() {
    if (state.mode === 'demo' || (state.mode === 'video' && state.videoUsesDemo)) {
      renderDemoOverlay();
      return;
    }

    if (state.mode === 'panorama' && state.panoramaAssembled) {
      const width = Math.max(1, elements.panoramaCanvas.width);
      const height = Math.max(1, elements.panoramaCanvas.height);
      renderLiveOverlay(state.panoramaDetections, width, height);
      return;
    }

    renderLiveOverlay(state.liveDetections, elements.analysisCanvas.width, elements.analysisCanvas.height);
  }

  function metaPill(text) {
    return `<span class="meta-pill">${escapeHtml(text)}</span>`;
  }

  function updateDemoResult(matches) {
    const best = matches[0];
    const hasResult = Boolean(best);
    elements.resultCard.classList.toggle('is-empty', !hasResult);
    elements.focusResultButton.hidden = !hasResult;

    if (!best) {
      elements.resultStatusIcon.textContent = '…';
      elements.resultHeading.textContent = state.scanning ? 'Still scanning' : 'No matching item found';
      elements.resultSummary.textContent = state.scanning
        ? 'The scanner has not reached a matching object yet.'
        : 'Try removing one filter, lowering the confidence threshold, or choosing another sample item.';
      elements.resultMeta.innerHTML = '';
      state.activeResultId = '';
      renderInventory();
      return;
    }

    state.activeResultId = best.id;
    elements.resultStatusIcon.textContent = '✓';
    elements.resultHeading.textContent = `${best.name} found`;
    const extra = matches.length > 1 ? ` ${matches.length - 1} additional match${matches.length === 2 ? '' : 'es'} also highlighted.` : '';
    elements.resultSummary.textContent = `${best.location}.${extra}`;
    elements.resultMeta.innerHTML = [
      metaPill(percentage(best.confidence)),
      metaPill(best.color),
      metaPill(best.shape),
      metaPill(best.category)
    ].join('');
    renderInventory();
  }

  function updateLiveResult(detections) {
    const best = detections[0];
    const criteria = currentCriteria();
    const hasResult = Boolean(best);
    elements.resultCard.classList.toggle('is-empty', !hasResult);
    elements.focusResultButton.hidden = true;
    state.activeResultId = '';

    if (!best) {
      elements.resultStatusIcon.textContent = '⌕';
      elements.resultHeading.textContent = state.scanning ? 'Looking for a match' : 'No live candidate yet';
      elements.resultSummary.textContent = engine.isAny(criteria.color)
        ? 'Choose a target color so the offline camera detector can isolate likely regions.'
        : 'Start a scan and point the camera toward a clearly visible object with the selected color.';
      elements.resultMeta.innerHTML = [metaPill(criteria.color), metaPill(criteria.shape)].join('');
      return;
    }

    elements.resultStatusIcon.textContent = '✓';
    elements.resultHeading.textContent = `${liveDetectionLabel()} candidate found`;
    elements.resultSummary.textContent = `The strongest highlighted region matches ${criteria.color.toLowerCase()} pixels and is estimated to be ${best.shape.toLowerCase()}.`;
    elements.resultMeta.innerHTML = [
      metaPill(percentage(best.confidence)),
      metaPill(criteria.color),
      metaPill(best.shape),
      metaPill('Local analysis')
    ].join('');
  }

  function renderInventory() {
    const activeId = state.activeResultId;
    elements.inventoryGrid.innerHTML = data.items.map((item) => {
      const colorKey = engine.normalizeText(item.color);
      const [swatch, text] = COLOR_SWATCHES[colorKey] || ['#e4e7ec', '#344054'];
      const icon = ITEM_ICONS[item.category] || '⌕';
      return `
        <button class="inventory-item${item.id === activeId ? ' is-active' : ''}" type="button" data-item-id="${item.id}" aria-label="Search for ${escapeHtml(item.name)}">
          <span class="item-swatch" style="--swatch:${swatch};--swatch-text:${text}" aria-hidden="true">${icon}</span>
          <span class="item-copy">
            <strong>${escapeHtml(item.name)}</strong>
            <small>${escapeHtml(item.shape)} · ${escapeHtml(item.category)}</small>
          </span>
          <span class="item-confidence">${percentage(item.confidence)}</span>
        </button>`;
    }).join('');
    elements.inventoryCount.textContent = `${data.items.length} detected`;
  }

  function computeDemoMatches() {
    const scannedItems = data.items.filter((item) => state.scannedItemIds.has(item.id));
    state.currentMatches = engine.matchItems(scannedItems, currentCriteria());
    renderDemoOverlay();
    updateDemoResult(state.currentMatches);
  }

  function applySearch(options) {
    const settings = { focus: false, runLiveScan: false, ...options };
    updateTargetChip();

    if (state.mode === 'demo' || (state.mode === 'video' && state.videoUsesDemo)) {
      computeDemoMatches();
      if (settings.focus && state.currentMatches[0]) focusBestResult(false);
      return;
    }

    if (state.mode === 'panorama' && state.panoramaAssembled) {
      analyzePanorama();
      return;
    }

    state.liveDetections = [];
    renderCurrentOverlay();
    updateLiveResult(state.liveDetections);
    if (settings.runLiveScan) startScan();
  }

  function focusBestResult(scrollIntoView) {
    const best = state.currentMatches[0];
    if (!best) return;
    const centerX = best.box.x + best.box.width / 2;
    focusSceneCoordinate(centerX, data.scene.width);
    showToast(`${best.name} is highlighted in the room.`);
    if (scrollIntoView !== false) {
      elements.scannerStage.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  }

  function updateScanButtonAvailability() {
    if (state.scanning) {
      elements.scanButton.disabled = false;
      return;
    }
    if (state.mode === 'camera') {
      elements.scanButton.disabled = !state.stream || elements.cameraVideo.readyState < 2;
    } else if (state.mode === 'video') {
      elements.scanButton.disabled = !state.videoUsesDemo && (!elements.cameraVideo.src || elements.cameraVideo.readyState < 2);
    } else if (state.mode === 'panorama') {
      elements.scanButton.disabled = !state.panoramaAssembled;
    } else {
      elements.scanButton.disabled = false;
    }
  }

  function renderModeActions() {
    let html = '';

    if (state.mode === 'demo') {
      html = `
        <button class="action-button is-accent" type="button" data-action="focus-target">Jump to best match</button>
        <button class="action-button" type="button" data-action="reset-pan">Reset room view</button>
        <p class="action-note">The sample panorama contains twelve pre-mapped detections for testing every search and display control.</p>`;
    } else if (state.mode === 'camera') {
      html = `
        <button class="action-button is-accent" type="button" data-action="start-camera"${state.stream ? ' disabled' : ''}>Start camera</button>
        <button class="action-button is-danger" type="button" data-action="stop-camera"${state.stream ? '' : ' disabled'}>Stop camera</button>
        <p class="action-note">Select a color before scanning. Frames are analyzed locally and never uploaded.</p>`;
    } else if (state.mode === 'video') {
      html = `
        <button class="action-button is-accent" type="button" data-action="choose-video">Choose video</button>
        <button class="action-button" type="button" data-action="sample-video">Use sample sweep</button>
        <button class="action-button" type="button" data-action="toggle-video"${state.videoUsesDemo || !elements.cameraVideo.src ? ' disabled' : ''}>Play / pause</button>
        <p class="action-note">Upload a local video, or use the bundled panoramic sweep to test the workflow immediately.</p>`;
    } else {
      html = `
        <button class="action-button is-accent" type="button" data-action="start-camera"${state.stream ? ' disabled' : ''}>Start camera</button>
        <button class="action-button" type="button" data-action="capture-frame"${state.stream ? '' : ' disabled'}>Capture frame</button>
        <button class="action-button" type="button" data-action="sample-captures">Load sample captures</button>
        <button class="action-button" type="button" data-action="assemble-panorama"${state.panoramaFrames.length >= 2 ? '' : ' disabled'}>Assemble panorama</button>
        <button class="action-button is-danger" type="button" data-action="clear-captures"${state.panoramaFrames.length ? '' : ' disabled'}>Clear</button>
        <span class="capture-count">${state.panoramaFrames.length} frame${state.panoramaFrames.length === 1 ? '' : 's'}</span>
        <p class="action-note">Capture two to six overlapping views, then assemble and scan them as one wide strip.</p>`;
    }

    elements.modeActionBar.innerHTML = html;
    updateScanButtonAvailability();
  }

  function stopMediaStream() {
    if (state.stream) {
      state.stream.getTracks().forEach((track) => track.stop());
      state.stream = null;
    }
    if (elements.cameraVideo.srcObject) {
      elements.cameraVideo.pause();
      elements.cameraVideo.srcObject = null;
    }
  }

  function revokeVideoObjectUrl() {
    if (state.videoObjectUrl) {
      URL.revokeObjectURL(state.videoObjectUrl);
      state.videoObjectUrl = '';
    }
  }

  function cancelActiveScan(message) {
    state.scanToken += 1;
    setScanning(false);
    if (message) {
      setProgress(state.scanProgress, message);
      showToast(message);
    }
    updateScanButtonAvailability();
  }

  function resetDynamicDetections() {
    state.liveDetections = [];
    state.panoramaDetections = [];
    elements.detectionOverlay.replaceChildren();
    updateLiveResult([]);
  }

  function switchMode(mode) {
    if (mode === state.mode) return;
    cancelActiveScan();

    if (state.mode === 'camera' || state.mode === 'panorama') stopMediaStream();
    if (state.mode === 'video') {
      elements.cameraVideo.pause();
      elements.cameraVideo.removeAttribute('src');
      elements.cameraVideo.load();
      revokeVideoObjectUrl();
      state.videoUsesDemo = false;
    }

    state.mode = mode;
    state.pan = 0;
    state.liveDetections = [];
    updateModeTabs();

    if (mode === 'demo') {
      showMedia('demo');
      configureContentScale(1.5);
      setPan(0);
      state.scannedItemIds = new Set(data.items.map((item) => item.id));
      setProgress(1, `Scan complete · ${data.items.length} items cataloged`);
      setStageMessage('', '', false);
      computeDemoMatches();
    } else if (mode === 'camera') {
      showMedia('video');
      configureContentScale(1);
      elements.cameraVideo.removeAttribute('src');
      elements.cameraVideo.load();
      setProgress(0, 'Camera ready to start');
      resetDynamicDetections();
      setStageMessage('Camera is off', 'Start the camera to scan a live space.', true);
    } else if (mode === 'video') {
      showMedia('video');
      configureContentScale(1);
      setProgress(0, 'No video selected');
      resetDynamicDetections();
      setStageMessage('Choose a video', 'Use a local video file or load the bundled sample sweep.', true);
    } else {
      state.panoramaAssembled = false;
      showMedia('video');
      configureContentScale(1);
      setProgress(0, `${state.panoramaFrames.length} panorama frames captured`);
      resetDynamicDetections();
      setStageMessage('Build a panorama', 'Start the camera and capture overlapping frames, or load sample captures.', true);
    }

    setScanning(false);
    renderModeActions();
    updateScanButtonAvailability();
  }

  async function startCamera() {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      setStageMessage('Camera unavailable', 'This browser does not provide camera access. Use the demo panorama or sample captures instead.', true);
      showToast('Camera access is not supported in this browser.');
      return;
    }

    try {
      stopMediaStream();
      state.stream = await navigator.mediaDevices.getUserMedia({
        audio: false,
        video: {
          facingMode: { ideal: 'environment' },
          width: { ideal: 1280 },
          height: { ideal: 720 }
        }
      });
      state.videoUsesDemo = false;
      if (state.mode === 'panorama') {
        state.panoramaAssembled = false;
        state.panoramaDetections = [];
      }
      showMedia('video');
      configureContentScale(1);
      elements.cameraVideo.srcObject = state.stream;
      elements.cameraVideo.removeAttribute('src');
      await elements.cameraVideo.play();
      setStageMessage('', '', false);
      setProgress(0, state.mode === 'panorama' ? 'Camera ready · capture overlapping frames' : 'Camera ready · choose a target and scan');
      renderModeActions();
      updateScanButtonAvailability();
    } catch (error) {
      console.error('Camera start failed:', error);
      stopMediaStream();
      setStageMessage('Camera permission needed', 'Allow camera access, or continue with the demo panorama and sample captures.', true);
      showToast('Camera could not start. Check browser permission settings.');
      renderModeActions();
    }
  }

  function stopCamera() {
    cancelActiveScan();
    stopMediaStream();
    resetDynamicDetections();
    setProgress(0, 'Camera stopped');
    setStageMessage('Camera is off', state.mode === 'panorama' ? 'Restart it to capture more panorama frames.' : 'Start the camera to scan a live space.', true);
    renderModeActions();
  }

  function loadVideoFile(file) {
    if (!file) return;
    cancelActiveScan();
    stopMediaStream();
    revokeVideoObjectUrl();
    state.videoUsesDemo = false;
    state.videoObjectUrl = URL.createObjectURL(file);
    showMedia('video');
    configureContentScale(1);
    elements.cameraVideo.srcObject = null;
    elements.cameraVideo.src = state.videoObjectUrl;
    elements.cameraVideo.loop = true;
    elements.cameraVideo.muted = true;
    elements.cameraVideo.load();
    setStageMessage('Loading video', file.name, true);
    setProgress(0, `Loading ${file.name}`);

    const onReady = () => {
      elements.cameraVideo.removeEventListener('loadeddata', onReady);
      setStageMessage('', '', false);
      setProgress(0, `Video ready · ${file.name}`);
      resetDynamicDetections();
      renderModeActions();
      updateScanButtonAvailability();
    };
    elements.cameraVideo.addEventListener('loadeddata', onReady);
  }

  function useSampleVideo() {
    cancelActiveScan();
    stopMediaStream();
    revokeVideoObjectUrl();
    elements.cameraVideo.pause();
    elements.cameraVideo.removeAttribute('src');
    elements.cameraVideo.load();
    state.videoUsesDemo = true;
    showMedia('demo');
    configureContentScale(1.5);
    setPan(0);
    state.scannedItemIds = new Set(data.items.map((item) => item.id));
    setStageMessage('', '', false);
    setProgress(1, `Sample sweep ready · ${data.items.length} items cataloged`);
    computeDemoMatches();
    renderModeActions();
    setScanning(false);
  }

  function toggleVideoPlayback() {
    if (!elements.cameraVideo.src || state.videoUsesDemo) return;
    if (elements.cameraVideo.paused) {
      elements.cameraVideo.play().catch((error) => {
        console.error('Video playback failed:', error);
        showToast('The browser blocked video playback. Press play again.');
      });
    } else {
      elements.cameraVideo.pause();
    }
  }

  function captureCurrentFrame() {
    if (!state.stream || elements.cameraVideo.readyState < 2) {
      showToast('Start the camera before capturing a panorama frame.');
      return;
    }
    if (state.panoramaFrames.length >= 6) {
      showToast('Six frames is the current panorama limit.');
      return;
    }

    const frame = document.createElement('canvas');
    frame.width = 640;
    frame.height = 360;
    const context = frame.getContext('2d');
    context.drawImage(elements.cameraVideo, 0, 0, frame.width, frame.height);
    state.panoramaFrames.push(frame);
    setProgress(state.panoramaFrames.length / 6, `${state.panoramaFrames.length} panorama frame${state.panoramaFrames.length === 1 ? '' : 's'} captured`);
    showToast(`Captured frame ${state.panoramaFrames.length}. Move the camera sideways with some overlap.`);
    renderModeActions();
  }

  function waitForImage(image) {
    if (image.complete && image.naturalWidth) return Promise.resolve();
    return new Promise((resolve, reject) => {
      image.addEventListener('load', resolve, { once: true });
      image.addEventListener('error', reject, { once: true });
    });
  }

  async function loadSampleCaptures() {
    try {
      stopMediaStream();
      await waitForImage(elements.demoImage);
      state.panoramaFrames = [];
      const sourceWidth = data.scene.width;
      const sourceHeight = data.scene.height;
      const cropWidth = 1200;
      const cropHeight = 675;
      const cropY = 112;
      const starts = [0, 600, 1200];

      starts.forEach((startX) => {
        const frame = document.createElement('canvas');
        frame.width = 640;
        frame.height = 360;
        const context = frame.getContext('2d');
        context.drawImage(
          elements.demoImage,
          clamp(startX, 0, sourceWidth - cropWidth),
          cropY,
          cropWidth,
          Math.min(cropHeight, sourceHeight - cropY),
          0,
          0,
          frame.width,
          frame.height
        );
        state.panoramaFrames.push(frame);
      });
      state.panoramaAssembled = false;
      setProgress(0.5, '3 sample panorama frames loaded');
      setStageMessage('Sample frames ready', 'Assemble the panorama, then scan it using the current color and shape filters.', true);
      renderModeActions();
      showToast('Loaded three overlapping sample room frames.');
    } catch (error) {
      console.error('Sample capture generation failed:', error);
      showToast('Sample captures could not be generated.');
    }
  }

  function clearPanoramaFrames() {
    cancelActiveScan();
    state.panoramaFrames = [];
    state.panoramaDetections = [];
    state.panoramaAssembled = false;
    showMedia('video');
    configureContentScale(1);
    elements.detectionOverlay.replaceChildren();
    setProgress(0, 'No panorama frames captured');
    setStageMessage('Build a panorama', 'Start the camera and capture overlapping frames, or load sample captures.', true);
    renderModeActions();
  }

  function assemblePanorama() {
    if (state.panoramaFrames.length < 2) {
      showToast('Capture or load at least two frames first.');
      return;
    }

    const frameWidth = 480;
    const frameHeight = 270;
    const canvas = elements.panoramaCanvas;
    canvas.width = frameWidth * state.panoramaFrames.length;
    canvas.height = frameHeight;
    const context = canvas.getContext('2d');
    context.clearRect(0, 0, canvas.width, canvas.height);

    state.panoramaFrames.forEach((frame, index) => {
      context.drawImage(frame, index * frameWidth, 0, frameWidth, frameHeight);
      if (index > 0) {
        const gradient = context.createLinearGradient(index * frameWidth - 32, 0, index * frameWidth + 32, 0);
        gradient.addColorStop(0, 'rgba(255,255,255,0)');
        gradient.addColorStop(0.5, 'rgba(255,255,255,0.10)');
        gradient.addColorStop(1, 'rgba(255,255,255,0)');
        context.fillStyle = gradient;
        context.fillRect(index * frameWidth - 32, 0, 64, frameHeight);
      }
    });

    state.panoramaAssembled = true;
    state.panoramaScale = Math.max(1, (canvas.width / canvas.height) / (16 / 9));
    stopMediaStream();
    showMedia('canvas');
    configureContentScale(state.panoramaScale);
    setPan(0);
    setStageMessage('', '', false);
    setProgress(1, `Panorama assembled · ${state.panoramaFrames.length} frames`);
    analyzePanorama();
    renderModeActions();
    updateScanButtonAvailability();
    showToast('Panorama assembled. Search filters now scan the full strip.');
  }

  function analyzeCanvasSource(source, targetCanvas) {
    const context = targetCanvas.getContext('2d', { willReadFrequently: true });
    context.clearRect(0, 0, targetCanvas.width, targetCanvas.height);
    context.drawImage(source, 0, 0, targetCanvas.width, targetCanvas.height);
    const criteria = currentCriteria();
    return engine
      .findColorRegions(targetCanvas, criteria.color, criteria.shape)
      .filter((region) => region.confidence >= criteria.minConfidence);
  }

  function analyzeVideoFrame() {
    if (elements.cameraVideo.readyState < 2) return [];
    try {
      return analyzeCanvasSource(elements.cameraVideo, elements.analysisCanvas);
    } catch (error) {
      console.error('Video frame analysis failed:', error);
      return [];
    }
  }

  function analyzePanorama() {
    if (!state.panoramaAssembled || !state.panoramaFrames.length) return;
    const criteria = currentCriteria();
    if (engine.isAny(criteria.color)) {
      state.panoramaDetections = [];
      renderCurrentOverlay();
      updateLiveResult([]);
      showToast('Choose a color before scanning the panorama.');
      return;
    }

    const frameTarget = document.createElement('canvas');
    frameTarget.width = 240;
    frameTarget.height = 135;
    const outputWidth = elements.panoramaCanvas.width;
    const outputHeight = elements.panoramaCanvas.height;
    const frameOutputWidth = outputWidth / state.panoramaFrames.length;
    const results = [];

    state.panoramaFrames.forEach((frame, index) => {
      const regions = analyzeCanvasSource(frame, frameTarget);
      regions.forEach((region) => {
        results.push({
          ...region,
          id: `panorama-${index}-${region.id}`,
          x: index * frameOutputWidth + (region.x / frameTarget.width) * frameOutputWidth,
          y: (region.y / frameTarget.height) * outputHeight,
          width: (region.width / frameTarget.width) * frameOutputWidth,
          height: (region.height / frameTarget.height) * outputHeight
        });
      });
    });

    state.panoramaDetections = results
      .sort((a, b) => b.confidence - a.confidence)
      .slice(0, 8);
    renderCurrentOverlay();
    updateLiveResult(state.panoramaDetections);
  }

  function startDemoScan() {
    cancelActiveScan();
    const token = ++state.scanToken;
    state.scannedItemIds = new Set();
    state.currentMatches = [];
    setPan(0);
    setScanning(true);
    setProgress(0, 'Scanning desk area…');
    renderDemoOverlay();
    updateDemoResult([]);

    const duration = 6200;
    const startedAt = performance.now();
    let previousCount = -1;

    function frame(now) {
      if (token !== state.scanToken) return;
      const progress = clamp((now - startedAt) / duration, 0, 1);
      elements.scannerStage.style.setProperty('--scan-position', `${progress * 100}%`);
      setProgress(progress, progress < 1 ? `Scanning room · ${Math.round(progress * 100)}%` : `Scan complete · ${data.items.length} items cataloged`);
      if (elements.autoPanToggle.checked) setPan(progress);

      const scanX = progress * data.scene.width;
      const discovered = data.items.filter((item) => item.box.x + item.box.width / 2 <= scanX + 90);
      if (discovered.length !== previousCount) {
        previousCount = discovered.length;
        state.scannedItemIds = new Set(discovered.map((item) => item.id));
        computeDemoMatches();
      }
      updateZoneStrip();

      if (progress < 1) {
        requestAnimationFrame(frame);
        return;
      }

      state.scannedItemIds = new Set(data.items.map((item) => item.id));
      computeDemoMatches();
      setScanning(false);
      setProgress(1, `Scan complete · ${data.items.length} items cataloged`);
      updateScanButtonAvailability();
      showToast(`Room scan complete. ${state.currentMatches.length || 'No'} matching item${state.currentMatches.length === 1 ? '' : 's'} found.`);
      if (state.currentMatches[0]) focusBestResult(false);
    }

    requestAnimationFrame(frame);
  }

  function startLiveScan() {
    const criteria = currentCriteria();
    if (engine.isAny(criteria.color)) {
      showToast('Choose a target color before scanning live video.');
      elements.colorSelect.focus();
      return;
    }
    if (elements.cameraVideo.readyState < 2) {
      showToast(state.mode === 'camera' ? 'Start the camera first.' : 'Choose a video first.');
      return;
    }

    cancelActiveScan();
    const token = ++state.scanToken;
    state.liveDetections = [];
    setScanning(true);
    setProgress(0, `Scanning for ${formatTarget(criteria)}…`);
    updateLiveResult([]);
    const duration = 5200;
    const startedAt = performance.now();
    state.lastAnalysisAt = 0;

    elements.cameraVideo.play().catch(() => {});

    function frame(now) {
      if (token !== state.scanToken) return;
      const progress = clamp((now - startedAt) / duration, 0, 1);
      const sweep = (progress * 3) % 1;
      elements.scannerStage.style.setProperty('--scan-position', `${sweep * 100}%`);
      setProgress(progress, `Analyzing ${criteria.color.toLowerCase()} regions · ${Math.round(progress * 100)}%`);

      if (now - state.lastAnalysisAt > 420) {
        state.lastAnalysisAt = now;
        state.liveDetections = analyzeVideoFrame();
        renderCurrentOverlay();
        updateLiveResult(state.liveDetections);
      }

      if (progress < 1) {
        requestAnimationFrame(frame);
        return;
      }

      setScanning(false);
      setProgress(1, state.liveDetections.length ? `${state.liveDetections.length} live candidate${state.liveDetections.length === 1 ? '' : 's'} found` : 'Scan complete · no strong color region found');
      updateLiveResult(state.liveDetections);
      updateScanButtonAvailability();
      showToast(state.liveDetections.length ? 'Candidate highlighted. Move closer for a more precise box.' : 'No strong candidate found. Improve lighting or loosen the filters.');
    }

    requestAnimationFrame(frame);
  }

  function startPanoramaScan() {
    if (!state.panoramaAssembled) {
      showToast('Assemble a panorama before scanning it.');
      return;
    }
    const criteria = currentCriteria();
    if (engine.isAny(criteria.color)) {
      showToast('Choose a target color before scanning the panorama.');
      elements.colorSelect.focus();
      return;
    }

    cancelActiveScan();
    const token = ++state.scanToken;
    setPan(0);
    state.panoramaDetections = [];
    setScanning(true);
    setProgress(0, `Scanning panorama for ${formatTarget(criteria)}…`);
    updateLiveResult([]);
    const duration = 3600;
    const startedAt = performance.now();

    function frame(now) {
      if (token !== state.scanToken) return;
      const progress = clamp((now - startedAt) / duration, 0, 1);
      elements.scannerStage.style.setProperty('--scan-position', `${progress * 100}%`);
      setProgress(progress, `Scanning panorama · ${Math.round(progress * 100)}%`);
      if (elements.autoPanToggle.checked) setPan(progress);

      if (progress < 1) {
        requestAnimationFrame(frame);
        return;
      }

      analyzePanorama();
      setScanning(false);
      setProgress(1, state.panoramaDetections.length ? `${state.panoramaDetections.length} panorama candidate${state.panoramaDetections.length === 1 ? '' : 's'} found` : 'Panorama scan complete · no candidate found');
      updateScanButtonAvailability();
      showToast(state.panoramaDetections.length ? 'Panorama scan complete. Strongest candidate highlighted.' : 'No candidate found in the panorama. Try another color or shape.');
    }

    requestAnimationFrame(frame);
  }

  function startScan() {
    if (state.scanning) {
      cancelActiveScan('Scan stopped');
      return;
    }

    if (state.mode === 'demo' || (state.mode === 'video' && state.videoUsesDemo)) {
      startDemoScan();
    } else if (state.mode === 'camera' || state.mode === 'video') {
      startLiveScan();
    } else {
      startPanoramaScan();
    }
  }

  function resetSearch() {
    elements.searchInput.value = 'phone';
    elements.colorSelect.value = 'Purple';
    elements.shapeSelect.value = 'Rectangular';
    elements.categorySelect.value = 'Any category';
    elements.confidenceRange.value = '70';
    elements.confidenceOutput.textContent = '70%';
    applySearch({ focus: state.mode === 'demo' || state.videoUsesDemo });
  }

  function selectInventoryItem(itemId) {
    const item = data.items.find((candidate) => candidate.id === itemId);
    if (!item) return;
    if (state.mode !== 'demo' && !(state.mode === 'video' && state.videoUsesDemo)) {
      switchMode('demo');
    }
    elements.searchInput.value = item.genericName;
    elements.colorSelect.value = item.color;
    elements.shapeSelect.value = item.shape;
    elements.categorySelect.value = item.category;
    elements.confidenceRange.value = String(Math.max(50, Math.floor(item.confidence * 100) - 10));
    elements.confidenceOutput.textContent = `${elements.confidenceRange.value}%`;
    applySearch({ focus: true });
  }

  function handleModeAction(action) {
    switch (action) {
      case 'focus-target':
        focusBestResult();
        break;
      case 'reset-pan':
        setPan(0);
        break;
      case 'start-camera':
        startCamera();
        break;
      case 'stop-camera':
        stopCamera();
        break;
      case 'choose-video':
        elements.videoFileInput.click();
        break;
      case 'sample-video':
        useSampleVideo();
        break;
      case 'toggle-video':
        toggleVideoPlayback();
        break;
      case 'capture-frame':
        captureCurrentFrame();
        break;
      case 'sample-captures':
        loadSampleCaptures();
        break;
      case 'assemble-panorama':
        assemblePanorama();
        break;
      case 'clear-captures':
        clearPanoramaFrames();
        break;
      default:
        break;
    }
  }

  function bindEvents() {
    elements.modeTabs.forEach((tab) => {
      tab.addEventListener('click', () => switchMode(tab.dataset.mode));
      tab.addEventListener('keydown', (event) => {
        if (!['ArrowLeft', 'ArrowRight'].includes(event.key)) return;
        event.preventDefault();
        const current = elements.modeTabs.indexOf(tab);
        const direction = event.key === 'ArrowRight' ? 1 : -1;
        const next = (current + direction + elements.modeTabs.length) % elements.modeTabs.length;
        elements.modeTabs[next].focus();
        switchMode(elements.modeTabs[next].dataset.mode);
      });
    });

    elements.scanButton.addEventListener('click', startScan);
    elements.searchForm.addEventListener('submit', (event) => {
      event.preventDefault();
      const runLive = state.mode !== 'demo' && !(state.mode === 'video' && state.videoUsesDemo) && !(state.mode === 'panorama' && state.panoramaAssembled);
      applySearch({ focus: state.mode === 'demo' || state.videoUsesDemo, runLiveScan: runLive });
    });

    elements.searchInput.addEventListener('input', updateTargetChip);
    elements.colorSelect.addEventListener('change', () => applySearch());
    elements.shapeSelect.addEventListener('change', () => applySearch());
    elements.categorySelect.addEventListener('change', () => applySearch());
    elements.confidenceRange.addEventListener('input', () => {
      elements.confidenceOutput.textContent = `${elements.confidenceRange.value}%`;
      applySearch();
    });
    elements.clearSearchButton.addEventListener('click', resetSearch);

    elements.quickSearches.addEventListener('click', (event) => {
      const button = event.target.closest('button[data-search]');
      if (!button) return;
      elements.searchInput.value = button.dataset.search;
      elements.colorSelect.value = button.dataset.color;
      elements.shapeSelect.value = button.dataset.shape;
      elements.categorySelect.value = 'Any category';
      applySearch({ focus: state.mode === 'demo' || state.videoUsesDemo });
    });

    [elements.labelsToggle, elements.confidenceToggle, elements.allBoxesToggle].forEach((toggle) => {
      toggle.addEventListener('change', renderCurrentOverlay);
    });

    elements.panRange.addEventListener('input', () => setPan(Number(elements.panRange.value) / 100, false));
    elements.focusResultButton.addEventListener('click', () => focusBestResult());

    elements.inventoryGrid.addEventListener('click', (event) => {
      const button = event.target.closest('[data-item-id]');
      if (button) selectInventoryItem(button.dataset.itemId);
    });

    elements.modeActionBar.addEventListener('click', (event) => {
      const button = event.target.closest('[data-action]');
      if (button) handleModeAction(button.dataset.action);
    });

    elements.videoFileInput.addEventListener('change', () => {
      const [file] = elements.videoFileInput.files;
      loadVideoFile(file);
      elements.videoFileInput.value = '';
    });

    elements.helpButton.addEventListener('click', () => {
      if (typeof elements.helpDialog.showModal === 'function') {
        elements.helpDialog.showModal();
      } else {
        elements.helpDialog.setAttribute('open', '');
      }
    });

    window.addEventListener('beforeunload', () => {
      stopMediaStream();
      revokeVideoObjectUrl();
    });
  }

  function initialize() {
    populateSelect(elements.colorSelect, data.colorOptions, 'Purple');
    populateSelect(elements.shapeSelect, data.shapeOptions, 'Rectangular');
    populateSelect(elements.categorySelect, data.categoryOptions, 'Any category');
    elements.confidenceOutput.textContent = `${elements.confidenceRange.value}%`;
    renderZoneStrip();
    renderInventory();
    bindEvents();
    updateModeTabs();
    showMedia('demo');
    configureContentScale(1.5);
    setProgress(1, `Scan complete · ${data.items.length} items cataloged`);
    setStageMessage('', '', false);
    computeDemoMatches();
    renderModeActions();
    updateTargetChip();
  }

  initialize();
})();
