(function attachVisionEngine(root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) {
    module.exports = api;
  } else {
    root.VisionEngine = api;
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function createVisionEngine() {
  'use strict';

  const ANY_VALUES = new Set(['', 'any', 'any color', 'any shape', 'any category', 'all']);

  const COLOR_RULES = {
    purple: (h, s, v) => h >= 255 && h <= 315 && s >= 22 && v >= 18,
    blue: (h, s, v) => h >= 190 && h <= 255 && s >= 28 && v >= 20,
    navy: (h, s, v) => h >= 190 && h <= 255 && s >= 28 && v >= 12 && v <= 52,
    silver: (_h, s, v) => s <= 18 && v >= 48 && v <= 91,
    gray: (_h, s, v) => s <= 20 && v >= 24 && v <= 72,
    red: (h, s, v) => (h <= 18 || h >= 342) && s >= 34 && v >= 25,
    white: (_h, s, v) => s <= 18 && v >= 80,
    green: (h, s, v) => h >= 78 && h <= 168 && s >= 24 && v >= 20,
    yellow: (h, s, v) => h >= 42 && h <= 72 && s >= 35 && v >= 48,
    black: (_h, _s, v) => v <= 24,
    pink: (h, s, v) => h >= 316 && h <= 350 && s >= 20 && v >= 48,
    orange: (h, s, v) => h >= 19 && h <= 43 && s >= 38 && v >= 42,
    brown: (h, s, v) => h >= 16 && h <= 48 && s >= 25 && v >= 18 && v <= 68
  };

  function clamp(value, minimum, maximum) {
    return Math.min(maximum, Math.max(minimum, value));
  }

  function normalizeText(value) {
    return String(value || '')
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, ' ')
      .trim()
      .replace(/\s+/g, ' ');
  }

  function isAny(value) {
    return ANY_VALUES.has(normalizeText(value));
  }

  function tokenize(value) {
    const normalized = normalizeText(value);
    return normalized ? normalized.split(' ') : [];
  }

  function includesPhrase(haystack, phrase) {
    const normalizedHaystack = normalizeText(haystack);
    const normalizedPhrase = normalizeText(phrase);
    return normalizedPhrase.length > 0 && normalizedHaystack.includes(normalizedPhrase);
  }

  function buildItemText(item) {
    return [
      item.name,
      item.genericName,
      item.category,
      item.color,
      item.shape,
      item.location,
      ...(item.aliases || [])
    ].map(normalizeText).join(' ');
  }

  function calculateItemScore(item, criteria) {
    const query = normalizeText(criteria.query);
    const selectedColor = normalizeText(criteria.color);
    const selectedShape = normalizeText(criteria.shape);
    const selectedCategory = normalizeText(criteria.category);
    const minimumConfidence = Number(criteria.minConfidence ?? 0);

    if (Number(item.confidence) < minimumConfidence) {
      return { score: 0, reasons: [], rejectedBy: 'confidence' };
    }

    if (!isAny(selectedColor) && normalizeText(item.color) !== selectedColor) {
      return { score: 0, reasons: [], rejectedBy: 'color' };
    }

    if (!isAny(selectedShape) && normalizeText(item.shape) !== selectedShape) {
      return { score: 0, reasons: [], rejectedBy: 'shape' };
    }

    if (!isAny(selectedCategory) && normalizeText(item.category) !== selectedCategory) {
      return { score: 0, reasons: [], rejectedBy: 'category' };
    }

    const reasons = [];
    let score = 0.52;

    if (query) {
      const itemText = buildItemText(item);
      const exactName = normalizeText(item.name) === query || normalizeText(item.genericName) === query;
      const aliasMatch = (item.aliases || []).some((alias) => normalizeText(alias) === query);
      const queryTokens = tokenize(query);
      const tokenMatches = queryTokens.filter((token) => itemText.includes(token));

      if (exactName) {
        score = 1;
        reasons.push('exact name');
      } else if (aliasMatch) {
        score = 0.96;
        reasons.push('known alias');
      } else if (includesPhrase(itemText, query)) {
        score = 0.9;
        reasons.push('description match');
      } else if (queryTokens.length && tokenMatches.length === queryTokens.length) {
        score = 0.84 + Math.min(0.08, queryTokens.length * 0.02);
        reasons.push('all search words');
      } else if (tokenMatches.length) {
        score = 0.45 + (tokenMatches.length / queryTokens.length) * 0.28;
        reasons.push('partial search match');
      } else {
        return { score: 0, reasons: [], rejectedBy: 'query' };
      }
    } else {
      reasons.push('attribute filters');
    }

    if (!isAny(selectedColor)) {
      score += 0.04;
      reasons.push('color');
    }
    if (!isAny(selectedShape)) {
      score += 0.04;
      reasons.push('shape');
    }
    if (!isAny(selectedCategory)) {
      score += 0.025;
      reasons.push('category');
    }

    score += clamp((Number(item.confidence) - 0.75) * 0.16, 0, 0.04);

    return {
      score: clamp(score, 0, 1),
      reasons,
      rejectedBy: null
    };
  }

  function matchItems(items, criteria) {
    return items
      .map((item) => {
        const result = calculateItemScore(item, criteria);
        return {
          ...item,
          matchScore: result.score,
          matchReasons: result.reasons,
          rejectedBy: result.rejectedBy
        };
      })
      .filter((item) => item.matchScore > 0)
      .sort((a, b) => b.matchScore - a.matchScore || b.confidence - a.confidence || a.name.localeCompare(b.name));
  }

  function rgbToHsv(red, green, blue) {
    const r = clamp(Number(red), 0, 255) / 255;
    const g = clamp(Number(green), 0, 255) / 255;
    const b = clamp(Number(blue), 0, 255) / 255;
    const maximum = Math.max(r, g, b);
    const minimum = Math.min(r, g, b);
    const difference = maximum - minimum;

    let hue = 0;
    if (difference !== 0) {
      if (maximum === r) {
        hue = 60 * (((g - b) / difference) % 6);
      } else if (maximum === g) {
        hue = 60 * ((b - r) / difference + 2);
      } else {
        hue = 60 * ((r - g) / difference + 4);
      }
    }
    if (hue < 0) hue += 360;

    const saturation = maximum === 0 ? 0 : (difference / maximum) * 100;
    const value = maximum * 100;
    return { h: hue, s: saturation, v: value };
  }

  function pixelMatchesColor(red, green, blue, colorName) {
    const key = normalizeText(colorName);
    if (isAny(key) || !COLOR_RULES[key]) return false;
    const { h, s, v } = rgbToHsv(red, green, blue);
    return COLOR_RULES[key](h, s, v);
  }

  function classifyShape(width, height, fillRatio) {
    const safeWidth = Math.max(1, Number(width));
    const safeHeight = Math.max(1, Number(height));
    const fill = clamp(Number(fillRatio), 0, 1);
    const aspect = safeWidth / safeHeight;

    if (fill < 0.28) return 'Irregular';
    if (aspect <= 0.67 && fill >= 0.38) return 'Cylindrical';
    if (aspect >= 0.84 && aspect <= 1.18) {
      return fill >= 0.72 ? 'Square' : 'Round';
    }
    if (aspect >= 1.18 && aspect <= 2.25 && fill < 0.66) return 'Oval';
    if (fill >= 0.32) return 'Rectangular';
    return 'Irregular';
  }

  function shapesAreCompatible(detectedShape, requestedShape) {
    const detected = normalizeText(detectedShape);
    const requested = normalizeText(requestedShape);
    if (isAny(requested)) return true;
    if (detected === requested) return true;
    const compatibilityGroups = [
      new Set(['round', 'oval']),
      new Set(['rectangular', 'square']),
      new Set(['rectangular', 'cylindrical'])
    ];
    return compatibilityGroups.some((group) => group.has(detected) && group.has(requested));
  }

  function boxesOverlapOrNear(a, b, margin) {
    return !(
      a.maxX + margin < b.minX ||
      b.maxX + margin < a.minX ||
      a.maxY + margin < b.minY ||
      b.maxY + margin < a.minY
    );
  }

  function mergeNearbyRegions(regions, margin) {
    const output = [];
    regions.forEach((region) => {
      const existing = output.find((candidate) => boxesOverlapOrNear(candidate, region, margin));
      if (!existing) {
        output.push({ ...region });
        return;
      }
      existing.minX = Math.min(existing.minX, region.minX);
      existing.minY = Math.min(existing.minY, region.minY);
      existing.maxX = Math.max(existing.maxX, region.maxX);
      existing.maxY = Math.max(existing.maxY, region.maxY);
      existing.count += region.count;
    });
    return output;
  }

  function findColorRegions(canvas, colorName, requestedShape, options) {
    const settings = {
      minimumPixelRatio: 0.0012,
      maximumPixelRatio: 0.62,
      mergeMargin: 4,
      maximumResults: 6,
      ...options
    };

    const normalizedColor = normalizeText(colorName);
    if (isAny(normalizedColor) || !COLOR_RULES[normalizedColor]) {
      return [];
    }

    if (!canvas || typeof canvas.getContext !== 'function') {
      throw new TypeError('findColorRegions expects a canvas-like object.');
    }

    const context = canvas.getContext('2d', { willReadFrequently: true });
    if (!context) return [];

    const width = canvas.width;
    const height = canvas.height;
    if (!width || !height) return [];

    const image = context.getImageData(0, 0, width, height);
    const totalPixels = width * height;
    const mask = new Uint8Array(totalPixels);
    const visited = new Uint8Array(totalPixels);

    for (let index = 0, pixel = 0; pixel < totalPixels; pixel += 1, index += 4) {
      const alpha = image.data[index + 3];
      if (alpha < 96) continue;
      if (pixelMatchesColor(image.data[index], image.data[index + 1], image.data[index + 2], normalizedColor)) {
        mask[pixel] = 1;
      }
    }

    const queue = new Int32Array(totalPixels);
    const rawRegions = [];
    const minimumPixels = Math.max(10, Math.round(totalPixels * settings.minimumPixelRatio));
    const maximumPixels = Math.round(totalPixels * settings.maximumPixelRatio);

    for (let start = 0; start < totalPixels; start += 1) {
      if (!mask[start] || visited[start]) continue;

      let head = 0;
      let tail = 0;
      queue[tail++] = start;
      visited[start] = 1;

      let count = 0;
      let minX = width;
      let minY = height;
      let maxX = 0;
      let maxY = 0;

      while (head < tail) {
        const current = queue[head++];
        const x = current % width;
        const y = Math.floor(current / width);
        count += 1;
        minX = Math.min(minX, x);
        maxX = Math.max(maxX, x);
        minY = Math.min(minY, y);
        maxY = Math.max(maxY, y);

        const left = current - 1;
        const right = current + 1;
        const up = current - width;
        const down = current + width;

        if (x > 0 && mask[left] && !visited[left]) {
          visited[left] = 1;
          queue[tail++] = left;
        }
        if (x < width - 1 && mask[right] && !visited[right]) {
          visited[right] = 1;
          queue[tail++] = right;
        }
        if (y > 0 && mask[up] && !visited[up]) {
          visited[up] = 1;
          queue[tail++] = up;
        }
        if (y < height - 1 && mask[down] && !visited[down]) {
          visited[down] = 1;
          queue[tail++] = down;
        }
      }

      if (count >= minimumPixels && count <= maximumPixels) {
        rawRegions.push({ minX, minY, maxX, maxY, count });
      }
    }

    const merged = mergeNearbyRegions(rawRegions, settings.mergeMargin);

    return merged
      .map((region, index) => {
        const boxWidth = region.maxX - region.minX + 1;
        const boxHeight = region.maxY - region.minY + 1;
        const area = boxWidth * boxHeight;
        const fillRatio = region.count / Math.max(1, area);
        const shape = classifyShape(boxWidth, boxHeight, fillRatio);
        const compatible = shapesAreCompatible(shape, requestedShape);
        const sizeSignal = clamp(region.count / (totalPixels * 0.055), 0, 1);
        const fillSignal = clamp(fillRatio / 0.7, 0, 1);
        const shapeSignal = compatible ? 1 : 0.35;
        const confidence = clamp(0.49 + sizeSignal * 0.18 + fillSignal * 0.2 + shapeSignal * 0.1, 0.5, 0.98);

        return {
          id: `live-region-${index + 1}`,
          x: region.minX,
          y: region.minY,
          width: boxWidth,
          height: boxHeight,
          pixelCount: region.count,
          fillRatio,
          shape,
          compatible,
          confidence
        };
      })
      .filter((region) => isAny(requestedShape) || region.compatible || region.confidence >= 0.9)
      .sort((a, b) => b.confidence - a.confidence || b.pixelCount - a.pixelCount)
      .slice(0, settings.maximumResults);
  }

  return Object.freeze({
    normalizeText,
    tokenize,
    isAny,
    calculateItemScore,
    matchItems,
    rgbToHsv,
    pixelMatchesColor,
    classifyShape,
    shapesAreCompatible,
    findColorRegions
  });
});
