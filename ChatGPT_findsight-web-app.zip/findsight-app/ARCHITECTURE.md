# FindSight Architecture

## High-level architecture

FindSight is a zero-dependency, client-only application. There is no backend, build pipeline, package manager, service worker, or remote model.

```text
index.html
   │
   ├── data.js ─────────────── sample room, zones, items, filters
   ├── vision-engine.js ────── pure matching and image-analysis functions
   ├── app.js ──────────────── state, events, media modes, rendering
   ├── styles.css ──────────── responsive UI and overlay presentation
   └── assets/demo-room.svg ── local panoramic test scene
```

### `index.html`

Defines the semantic UI: header, scanner stage, mode tabs, target form, display toggles, result card, inventory grid, help dialog, hidden media input, and analysis canvas. It intentionally contains no inline application state so structure remains easy to inspect and edit.

### `data.js`

Exports one immutable `FindSightData` object in the browser and via CommonJS for Node tests. It contains:

- Panorama dimensions and asset path
- Four horizontal room zones
- Twelve item records
- Search aliases
- Detection confidence
- Scene-relative bounding boxes
- Color, shape, category, and location metadata
- Filter option lists

Bounding boxes use the source panorama’s 2400 × 900 coordinate system. The UI converts them to percentages, so overlays stay aligned at every responsive size.

### `vision-engine.js`

Exports a dependency-free `VisionEngine` object. Its functions are pure where possible and can be tested without a browser.

It has two responsibilities:

1. **Catalog matching**
   - Normalizes text
   - Tokenizes descriptions
   - Scores exact names, aliases, phrases, and partial token matches
   - Applies hard color, shape, category, and confidence filters
   - Returns results in best-match order

2. **Lightweight live detection**
   - Converts RGB pixels to HSV
   - Applies named-color rules
   - Builds a binary color mask
   - Finds connected components with an iterative queue
   - Merges nearby regions
   - Estimates shape from aspect ratio and pixel fill
   - Produces candidate boxes and confidence values

The live detector never attempts semantic object classification. Its interface is deliberately isolated so it can be replaced later.

### `app.js`

Uses one private state object inside an immediately invoked function expression. The controller coordinates:

- Current mode: demo, camera, video, or panorama
- Scan progress and cancellation tokens
- Panorama position and scale
- Discovered sample items
- Current search matches
- Camera stream lifecycle
- Uploaded-video object URLs
- Live detector results
- Captured panorama frames
- UI rendering and accessibility state

No app state is placed on `window`. Only the data and engine modules expose globals, which keeps the UI controller private while allowing the pure logic to be reused and tested.

## Data flow

### Demo panorama search

```text
Target form
   ↓
currentCriteria()
   ↓
VisionEngine.matchItems(sample items, criteria)
   ↓
Sorted matches
   ├── result card
   ├── inventory active state
   ├── target chip
   └── percentage-positioned overlay boxes
```

During a rescan, `scannedItemIds` starts empty. Animation progress is converted to an X coordinate in the source panorama. Items become searchable and visible after the scanner reaches their center point.

### Camera or uploaded-video scan

```text
Video frame
   ↓ drawImage
240 × 135 analysis canvas
   ↓
HSV color segmentation
   ↓
Connected components
   ↓
Shape estimate + confidence
   ↓
Video-relative percentage boxes
```

Frame analysis is throttled to roughly one pass every 420 milliseconds during a scan. The reduced canvas size keeps the CPU cost reasonable on phones and older laptops.

### Camera panorama scan

Captured frames are stored as in-memory canvases. Assembly draws each frame into a wider output canvas. Each original frame is analyzed separately and its candidate coordinates are translated into the assembled canvas coordinate system. This avoids quality loss from repeatedly reading and resizing the entire wide panorama.

## Key design decisions

### Separate realistic demo data from live heuristics

A fully offline semantic detector accurate enough to recognize many household objects would require a substantial bundled model and inference runtime. Those assets would conflict with the requirement to avoid external packages and would make this prototype much larger.

The app therefore provides two honest layers:

- A complete, realistic, immediately usable panoramic product demo with mapped test detections
- A genuine local camera/video color-and-shape detector that demonstrates the real media and overlay pipeline

The UI and architecture are ready for a stronger model without pretending the heuristic detector can identify arbitrary objects by name.

### Percentage-based overlays

All displayed boxes are percentages of their media surface. This avoids device-specific coordinates and keeps the same data aligned on desktop, tablet, and mobile.

### Media lifecycle is explicit

Changing away from camera modes stops media tracks. Uploaded-video object URLs are revoked when replaced or when the page unloads. Frames are never serialized to storage or transmitted.

### Cancellation tokens instead of complex async orchestration

Every new scan increments a numeric token. Animation frames exit when their token is no longer current. This prevents an old scan from updating the interface after the user changes modes or starts another scan.

### No persistence by default

Searches, captures, and preferences reset on refresh. This protects privacy and keeps the prototype deterministic. Persistence can be added later with explicit user controls.

### Accessible, responsive controls

The mode selector uses tab semantics and keyboard arrow navigation. Form controls have visible labels, focus states, and output values. The UI becomes one column below tablet widths and keeps all primary actions touch-sized.

## Extending or modifying features

### Add or edit sample items

1. Add the item visually to `assets/demo-room.svg`.
2. Add a record to `items` in `data.js`.
3. Use the SVG’s 2400 × 900 coordinate system for `box.x`, `box.y`, `box.width`, and `box.height`.
4. Add useful search aliases.
5. Re-run `node tests/run-tests.js` and verify the box visually.

The filter lists derive categories from the item records. New colors or shapes must also be added to the corresponding option array, and a live color rule should be added to `COLOR_RULES` when camera detection is expected.

### Replace the heuristic detector with a bundled model

Create a detector adapter with an asynchronous interface such as:

```js
async function detectFrame(source, target) {
  return [
    {
      id: 'candidate-1',
      label: 'phone',
      confidence: 0.97,
      x: 120,
      y: 64,
      width: 88,
      height: 152,
      color: 'Purple',
      shape: 'Rectangular'
    }
  ];
}
```

Then replace calls to `VisionEngine.findColorRegions` in `analyzeVideoFrame()` and `analyzePanorama()`.

For an offline production build, bundle the model weights and inference runtime inside the project rather than loading them from a CDN. Keep the returned box format stable so the existing overlay and result UI can remain unchanged. Run model inference in a Web Worker to avoid blocking the interface, and consider WebGPU with a WebAssembly fallback.

### Add true panorama stitching

The current panorama is a side-by-side strip. A future stitcher can:

1. Detect local features in adjacent frames.
2. Match feature descriptors.
3. Estimate a homography with outlier rejection.
4. Warp frames to a shared canvas.
5. Blend overlap seams.
6. Map detector boxes through the same transforms.

This is a good candidate for a Worker because feature matching and warping are CPU intensive.

### Add saved rooms or item history

Introduce a storage module rather than writing directly from UI handlers. A minimal local-only design could use IndexedDB for room snapshots and item metadata. Provide explicit save/delete actions and show storage use because images can consume significant space.

### Add more precise search parameters

The criteria object can be extended with material, size, brand, room zone, or last-seen date. Add the field to the form, item data, `currentCriteria()`, and `calculateItemScore()`. Keep optional filters neutral when set to “Any.”

### Add localization

Move UI strings and data-facing labels into locale dictionaries. Item aliases can be stored per locale. Avoid using translated display strings as internal IDs; keep IDs stable and language-independent.

### Change visual styling

Most colors, radii, and shadows are CSS custom properties at the top of `styles.css`. Scanner geometry and overlay rendering are separate from the visual theme, so colors can be changed without touching JavaScript.

## Assumptions

- The user runs a current desktop or mobile browser.
- The app is served as static files; no server-side routes are required.
- Camera mode is used from `localhost` or another secure context.
- One target is searched at a time.
- The sample panorama is the authoritative source for demo bounding boxes.
- Live color rules work best with a well-lit, visually distinct target and a background that is not the same color.
- The requested item name is a label in heuristic live mode, not a semantically verified class.
- Panorama captures are temporary and limited to six frames to control memory use.
- No user data should leave the browser unless a future feature explicitly introduces and documents that behavior.
