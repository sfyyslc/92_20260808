# FindSight

FindSight is a responsive, offline-friendly web app prototype for locating misplaced belongings in a room, suitcase, desk, or other cluttered space. Users can search by item name or description and narrow the target by color, shape, category, and minimum confidence. Matching items are highlighted directly over a panoramic scene.

The app is written entirely in plain HTML, CSS, and vanilla JavaScript. It has no libraries, frameworks, CDNs, build tools, accounts, analytics, or network APIs.

## Run the app

Serve the folder with any basic static-file server. From the project directory:

```bash
python3 -m http.server 8080
```

Then open:

```text
http://localhost:8080
```

No installation or build step is required. All runtime files are local, so the app continues to work without an internet connection once the folder is available to the browser.

Camera access normally requires a secure browser context. `localhost` is treated as secure by current browsers; a plain remote HTTP address may not be. Grant camera permission only when using Live camera or Camera panorama mode.

## Main features

### Full-room panorama demo

The bundled room illustration is wider than the viewport and can be panned manually or automatically during a scan. Selecting **Rescan room** animates a room-wide sweep, progressively discovers items, updates coverage by zone, and follows the scan when auto-pan is enabled.

### Search with extra parameters

The target form supports:

- Item name or free-text description
- Color
- Shape
- Category
- Minimum confidence

The default test case is **phone + purple + rectangular**, which highlights the purple phone on the desk. Names are matched against aliases as well, so searches such as `mobile`, `cell phone`, `keyring`, `airpods`, or `luggage` work in the sample catalog.

### Detection highlights and display toggles

Every mapped item can have a bounding box, label, and confidence percentage. Users can independently turn labels and percentages on or off, hide non-matching boxes, and keep only the target highlight visible.

### Live camera mode

Live camera mode uses the browser’s `getUserMedia` API. Because the project intentionally contains no external machine-learning library or large bundled model, its included live detector is a lightweight local heuristic:

1. The current video frame is downsampled to an analysis canvas.
2. Pixels are segmented by the selected named color in HSV space.
3. Connected regions are measured.
4. Approximate shape and confidence are inferred from aspect ratio and fill density.
5. Candidate regions are highlighted over the video.

The search name becomes the candidate label, while color and shape guide the actual live detection. This is useful for testing the complete offline workflow, but it is not a replacement for a trained object-recognition model.

### Local video mode

Users can select a video stored on their device and scan its frames with the same local color-and-shape detector. A bundled **Use sample sweep** option makes the mode immediately testable without supplying a file.

### Camera panorama mode

Users can capture two to six overlapping camera frames, assemble them into a wide local strip, pan across the result, and scan the assembled panorama. Three generated sample captures are included so the workflow can be tested without camera hardware.

The included stitcher places frames side by side with a soft seam. It deliberately avoids external computer-vision dependencies; feature-based alignment is documented as a future extension in `ARCHITECTURE.md`.

### Privacy and offline behavior

Camera frames, video frames, search terms, and panorama captures remain in the current browser tab. The app contains no upload code and makes no network requests.

## Sample data and feature mapping

The sample room contains 12 detections across four scan zones. Each item exercises a different combination of filters, aliases, placement, confidence, and overlay behavior.

| Sample item | Color | Shape | Confidence | Zone | Features exercised |
|---|---|---:|---:|---|---|
| Purple phone | Purple | Rectangular | 98% | Desk | Default name/color/shape search; aliases such as mobile and cell phone; best-match highlight |
| Blue headphones | Blue | Round | 94% | Desk | Quick-search chip; round-shape filter; electronics category |
| Silver keys | Silver | Irregular | 91% | Desk | Quick-search chip; everyday-carry category; aliases such as keyring |
| Red notebook | Red | Rectangular | 96% | Bed | School-supplies category; journal/notepad aliases |
| Gray socks | Gray | Irregular | 84% | Bed | Lower-confidence filtering; clothing category |
| White earbuds case | White | Oval | 88% | Bed | Oval filter; AirPods and charging-case aliases |
| Green water bottle | Green | Cylindrical | 95% | Bed | Cylindrical filter; personal-items category |
| Yellow pencil case | Yellow | Rectangular | 93% | Floor | School-supplies filtering; pencil-pouch aliases |
| Navy wallet | Navy | Rectangular | 90% | Floor | Navy color rule; everyday-carry filtering |
| Black charger | Black | Irregular | 86% | Floor | Quick-search chip; dark-color segmentation; charger/cable aliases |
| Pink glasses | Pink | Irregular | 87% | Suitcase | Personal-items category; eyeglasses/spectacles aliases |
| Orange suitcase | Orange | Rectangular | 99% | Suitcase | Travel category; far-right panorama panning; luggage aliases |

The four scan zones are Desk area, Bed area, Floor & side table, and Suitcase area. Their status pills update as the animated scan reaches each section.

## File structure

```text
findsight-app/
├── index.html                  Main application markup and accessible controls
├── styles.css                 Responsive layout, scanner overlays, and component styling
├── app.js                     UI controller, media modes, scanning workflows, and rendering
├── data.js                    Sample scene metadata, zones, item catalog, and filter options
├── vision-engine.js           Pure search-matching and local color/shape detection functions
├── assets/
│   └── demo-room.svg          Self-contained panoramic room illustration
├── tests/
│   ├── run-tests.js           Dependency-free Node logic tests
│   ├── TEST-RESULTS.md        Recorded logic and browser smoke-test results
│   └── screenshots/
│       ├── desktop.png        Desktop reference render
│       └── mobile.png         Mobile reference render
├── README.md                  Setup, features, sample-data mapping, and usage
└── ARCHITECTURE.md            Architecture, decisions, extension guidance, and assumptions
```

## Test the app

Run the dependency-free logic suite:

```bash
node tests/run-tests.js
```

A completed browser smoke-test report is included in `tests/TEST-RESULTS.md`. For a manual pass, verify the default phone search, toggle labels and percentages, switch to matched-only boxes, run a room rescan, load the sample video sweep, and assemble the sample panorama.

## Browser support

Use a current version of Chrome, Edge, Firefox, or Safari. The core demo and search experience work without camera permission. Live camera support depends on the browser implementing `navigator.mediaDevices.getUserMedia` and on the page being served in a secure context.
