(function attachFindSightData(root, factory) {
  const data = factory();
  if (typeof module === 'object' && module.exports) {
    module.exports = data;
  } else {
    root.FindSightData = data;
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function createData() {
  'use strict';

  const scene = {
    width: 2400,
    height: 900,
    asset: 'assets/demo-room.svg',
    title: 'Messy bedroom panorama',
    description: 'A full-room sweep from the desk to an open suitcase.'
  };

  const zones = [
    { id: 'desk', name: 'Desk area', startX: 0, endX: 760 },
    { id: 'bed', name: 'Bed area', startX: 760, endX: 1360 },
    { id: 'floor', name: 'Floor & side table', startX: 1360, endX: 1850 },
    { id: 'suitcase', name: 'Suitcase area', startX: 1850, endX: 2400 }
  ];

  const items = [
    {
      id: 'purple-phone',
      name: 'Purple phone',
      genericName: 'Phone',
      aliases: ['smartphone', 'mobile', 'cell phone', 'iphone', 'android'],
      category: 'Electronics',
      color: 'Purple',
      shape: 'Rectangular',
      location: 'On the left side of the desk, beside the laptop',
      zone: 'desk',
      confidence: 0.98,
      box: { x: 340, y: 414, width: 154, height: 94 }
    },
    {
      id: 'blue-headphones',
      name: 'Blue headphones',
      genericName: 'Headphones',
      aliases: ['headset', 'earphones', 'over-ear headphones'],
      category: 'Electronics',
      color: 'Blue',
      shape: 'Round',
      location: 'Hanging above the left edge of the desk',
      zone: 'desk',
      confidence: 0.94,
      box: { x: 136, y: 140, width: 276, height: 236 }
    },
    {
      id: 'silver-keys',
      name: 'Silver keys',
      genericName: 'Keys',
      aliases: ['keyring', 'house keys', 'car keys'],
      category: 'Everyday carry',
      color: 'Silver',
      shape: 'Irregular',
      location: 'Near the right edge of the desk',
      zone: 'desk',
      confidence: 0.91,
      box: { x: 580, y: 482, width: 190, height: 94 }
    },
    {
      id: 'red-notebook',
      name: 'Red notebook',
      genericName: 'Notebook',
      aliases: ['journal', 'notepad', 'school book'],
      category: 'School supplies',
      color: 'Red',
      shape: 'Rectangular',
      location: 'Openly visible on the middle-left of the bed',
      zone: 'bed',
      confidence: 0.96,
      box: { x: 780, y: 490, width: 250, height: 170 }
    },
    {
      id: 'gray-socks',
      name: 'Gray socks',
      genericName: 'Socks',
      aliases: ['sock', 'pair of socks', 'clothing'],
      category: 'Clothing',
      color: 'Gray',
      shape: 'Irregular',
      location: 'Against the wall above the center of the bed',
      zone: 'bed',
      confidence: 0.84,
      box: { x: 997, y: 225, width: 205, height: 190 }
    },
    {
      id: 'white-earbuds-case',
      name: 'White earbuds case',
      genericName: 'Earbuds case',
      aliases: ['airpods', 'earbuds', 'charging case', 'wireless earbuds'],
      category: 'Electronics',
      color: 'White',
      shape: 'Oval',
      location: 'Near the lower-right corner of the bedspread',
      zone: 'bed',
      confidence: 0.88,
      box: { x: 1072, y: 604, width: 122, height: 94 }
    },
    {
      id: 'green-water-bottle',
      name: 'Green water bottle',
      genericName: 'Water bottle',
      aliases: ['bottle', 'drink bottle', 'flask'],
      category: 'Personal items',
      color: 'Green',
      shape: 'Cylindrical',
      location: 'Standing on the side table beside the bed',
      zone: 'bed',
      confidence: 0.95,
      box: { x: 1254, y: 318, width: 152, height: 266 }
    },
    {
      id: 'yellow-pencil-case',
      name: 'Yellow pencil case',
      genericName: 'Pencil case',
      aliases: ['pencil pouch', 'pen case', 'school pouch'],
      category: 'School supplies',
      color: 'Yellow',
      shape: 'Rectangular',
      location: 'On the rug, just right of the side table',
      zone: 'floor',
      confidence: 0.93,
      box: { x: 1425, y: 454, width: 226, height: 120 }
    },
    {
      id: 'navy-wallet',
      name: 'Navy wallet',
      genericName: 'Wallet',
      aliases: ['card holder', 'billfold', 'purse'],
      category: 'Everyday carry',
      color: 'Navy',
      shape: 'Rectangular',
      location: 'On the lower-middle section of the rug',
      zone: 'floor',
      confidence: 0.90,
      box: { x: 1538, y: 626, width: 173, height: 119 }
    },
    {
      id: 'black-charger',
      name: 'Black charger',
      genericName: 'Charger',
      aliases: ['power adapter', 'charging cable', 'phone charger', 'cord'],
      category: 'Electronics',
      color: 'Black',
      shape: 'Irregular',
      location: 'On the right side of the rug, with its cable curled outward',
      zone: 'floor',
      confidence: 0.86,
      box: { x: 1700, y: 575, width: 230, height: 245 }
    },
    {
      id: 'pink-glasses',
      name: 'Pink glasses',
      genericName: 'Glasses',
      aliases: ['eyeglasses', 'spectacles', 'frames'],
      category: 'Personal items',
      color: 'Pink',
      shape: 'Irregular',
      location: 'On the upper shelf above the suitcase',
      zone: 'suitcase',
      confidence: 0.87,
      box: { x: 1970, y: 165, width: 300, height: 98 }
    },
    {
      id: 'orange-suitcase',
      name: 'Orange suitcase',
      genericName: 'Suitcase',
      aliases: ['luggage', 'travel bag', 'case'],
      category: 'Travel',
      color: 'Orange',
      shape: 'Rectangular',
      location: 'Open on the far-right side of the room',
      zone: 'suitcase',
      confidence: 0.99,
      box: { x: 1832, y: 286, width: 548, height: 553 }
    }
  ];

  const colorOptions = ['Any color', 'Purple', 'Blue', 'Silver', 'Red', 'Gray', 'White', 'Green', 'Yellow', 'Navy', 'Black', 'Pink', 'Orange', 'Brown'];
  const shapeOptions = ['Any shape', 'Rectangular', 'Round', 'Square', 'Oval', 'Cylindrical', 'Irregular'];
  const categoryOptions = ['Any category', ...Array.from(new Set(items.map((item) => item.category))).sort()];

  return Object.freeze({
    scene: Object.freeze(scene),
    zones: Object.freeze(zones.map((zone) => Object.freeze(zone))),
    items: Object.freeze(items.map((item) => Object.freeze({
      ...item,
      aliases: Object.freeze([...item.aliases]),
      box: Object.freeze({ ...item.box })
    }))),
    colorOptions: Object.freeze(colorOptions),
    shapeOptions: Object.freeze(shapeOptions),
    categoryOptions: Object.freeze(categoryOptions)
  });
});
